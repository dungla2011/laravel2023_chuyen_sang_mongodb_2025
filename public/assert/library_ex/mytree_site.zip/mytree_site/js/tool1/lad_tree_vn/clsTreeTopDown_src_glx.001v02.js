class clsTreeInfo {
    name
    title
    created_at
    updated_at
    deleted_at
    user_id
    tree_id
    status
    image_list
    color_name
    color_title
    fontsize_name
    fontsize_title
    banner_name_margin_top
    banner_name_margin_bottom
    banner_title_margin_top
    banner_title_margin_bottom
    member_background_img
    member_background_img2
    banner_width
    banner_height
    banner_name_bold
    banner_name_italic
    banner_title_bold
    banner_title_italic
    banner_title_curver
    banner_name_curver
    banner_text_shadow_name
    banner_text_shadow_title
    banner_margin_top
    title_before_or_after_name
    tree_nodes_xy
    minX
    minY
    show_node_name_one
    show_node_title
    show_node_birthday_one
    show_node_date_of_death
    show_node_image
    node_width
    node_height
    space_node_y
    space_node_x
    font_size_node

}



class actionTimeOut {
    lastTimeAct = 0
    countAct = 0
    lastId = 0

    static instance = null

    /**
     *
     * @returns actionTimeOut
     */
    static getInstance(){
        if(!actionTimeOut.instance)
            actionTimeOut.instance = new actionTimeOut()
        return actionTimeOut.instance
    }

    reset(){
        this.lastTimeAct = 0
        this.countAct = 0
        this.lastId = 0
    }
}

class clsTreeTopDownCtrl {
    //static _data
    // static mRectangle = null

    /**
     * @public clsTreeInfo
     */
    objBannerTop


    idSvgSelector

    //Sẽ bỏ cái này
    spaceBetweenCellX = 30
    //Khoảng cách giữa cá phần tử sẽ là tương đối, chiềều rộng chia cho N (1,2,3,4...)
    spaceXBetweenCellDevidedBy = 5;

    spaceBetweenCellY = 10
    widthCell = 81
    heightCell = 106
    bannerWidth = 1200
    bannerHeight = 250
    optPadYToPrint = 250
    startX = 100
    startY = 50 //Khoảng cách tính từ banner đến phần tử đầu tiên

    zoomAble = 1
    maxZoom = 15
    minZoom = 0.1
    dataPart

    setPid = 0

    optShowMarried = 1

    //Chỉ hiển thị đàn ông
    optShowOnlyMan = 0

    //Tô đậm các đàn ông Đinh của dòng họ
    optBorderMainMan = 0

    optShowDebugGrid = 0

    optShowDebugIdAndOrders = 0

    optDebugOpt = 0

    optMaxRowLevelLimitShow = 0

    optFitWindowId = null

    //fit viewport vừa cửa sổ window Hoặc fit theo svg content
    //khi download, cần Fit ViewPort với Full size svg để tải đúng size
    optFitViewPortToWindow = 1

    optColorLineParent = 'gray'
    optColorLineMarried = 'hotpink'
    optRemoveImage = 0

    optDisableApiForTestLocalOnly = 0

    optEnableGrandParentToCenter = 1

    optUseBannerCicleTypeJs = 0

    optDisableMenuNode = ''

    optDisableApiTreeText

    optEnableMoveBtn = 0

    tmp_banner_title_curver
    tmp_banner_name_curver

    tmp_mouse_enter_node_id

    tmp_mouse_clicking_node_id

    //Kiểm tra mouse down/up co = nha khong, neu = nhau, thi la Check Select node, ko phai move
    tmp_mouse_down_up_node_check

    tmp_mouse_up_xy

    tmp_id_of_obj_list

    //Dùng để đặt cờ ko cần tính lại hàng cột, mà vẽ lại luôn
    static tmpDisableCountingRowCol = 0


    //1 là man, 2 là woman
    static selectingManWomanBackGround

    /**
     * @public clsTreeNode
     */
    static doingNodeObj

    /**
     * @public clsTreeTopDownCtrl
     */
    static doingSvgObj

    static doingCmd

    //All instance tree
    /**

     * @public {[clsTreeTopDownCtrl]}
     */

    static allInstance = [];


    apiIndex
    apiAdd
    apiDelete
    apiUpdate
    apiUploadImage

    apiBearToken

    /**
     *
     * @private SvgPanZoom
     */
    _panZoomTiger

    // mmRec = []

    constructor() {
        this.initTopBannerEmpty();
        clsTreeTopDownCtrl.allInstance.push(this);
        console.log("clsTreeTopDownCtrl.constructor: ", clsTreeTopDownCtrl.allInstance);
    }



//Tinh nx ny, tu vi tri x y nhap vao
    static getNxNyFromXY(treObj, x, minX){
        let sttX = (x) - (minX);
        let sttXOK = Math.round(sttX / (treObj.widthCell / treObj.spaceXBetweenCellDevidedBy));
        // console.log(" getNxNyFromXY... ");
        return sttXOK
    }
    static setNXNyWhenMove(nodeToMove, treObj){
        let x1_3 = treObj.widthCell / treObj.spaceXBetweenCellDevidedBy;
        let yTopElm = treObj.startY + treObj.bannerHeight;
        let hOneElmAndSpaceY = treObj.heightCell + treObj.spaceBetweenCellY
        let id = nodeToMove.id.replace('svg_cont_node_', '');

        let objData= treObj.getObjFromId(id);

        let haveUpdateXy = 0;
        let x0 = parseFloat(nodeToMove.getAttribute('x'));
        let y0 = parseFloat(nodeToMove.getAttribute('y'));

        let old_x = parseFloat(nodeToMove.getAttribute('old_x'))

        // console.log(" db old_x /  x0 ", old_x, x0 );

        let x = (Math.round(x0 / x1_3) * x1_3);

        x =  old_x + Math.round((x0 - old_x) / x1_3) * x1_3

        let y = (Math.round((y0 - yTopElm) / hOneElmAndSpaceY) * hOneElmAndSpaceY + yTopElm);

        // console.log("db setNXNy x0 / x1_3 ", x , x0, x1_3);
        // console.log("db setNXNy ...", x, y);

        if(x !== x0 || y !== y0) {
            nodeToMove.setAttribute('x', x);
            nodeToMove.setAttribute('y', y);
            haveUpdateXy = 1;
            let minX = clsTreeTopDownCtrl.getMinX()
            let sttXOK =  clsTreeTopDownCtrl.getNxNyFromXY(treObj, x, minX)
            nodeToMove.setAttribute('ny', objData._row);
            nodeToMove.setAttribute('nx', sttXOK);
            // console.log("db minX, sttXOK, x = ", minX, sttXOK, x);
        }
        return haveUpdateXy;
    }

    reDrawTree(forTester = 0) {

        if (this.optDisableApiForTestLocalOnly) {
            $("#info_svg").show()
            $("#info_svg").html("<div style='position: fixed; right: 1px; top: 1px; padding: 2px 5px; background-color: orangered; color: white'> Disable API test local </div>")
        }

        let time1 = (Date.now());

        console.log("--- Data Before Make", this.dataPart);
        console.log(" dtime time1 = ", time1);

        //Nếu disable hàng cột không cần tính lại
        if(0)
            if(clsTreeTopDownCtrl.tmpDisableCountingRowCol){
                clsTreeTopDownCtrl.showLoader();
                console.log(" --- redraw only, not couting row col");
                this.removeAllConnectLineParentAndMarried()
                this.removeAllObjectSvgDrawed()
                this.createTreeSvg()
                this.setBannerTree();

                for (let tmp of this.dataPart) {
                    this.drawLineMarried(tmp)
                    this.drawLineToParent(tmp)
                }

                // this.moveUpTrungLapDuongNoiParent()

                if(this.tmp_mouse_enter_node_id)
                    if(this.optEnableMoveBtn) {
                        $("#id_node_move_right_" + this.tmp_mouse_enter_node_id).show()
                        $("#id_node_move_left_" + this.tmp_mouse_enter_node_id).show()
                    }
                clsTreeTopDownCtrl.hideLoader()
                return;
            }

        this.clearResetAllSvgToReDraw()

        if(this.dataPart.length == 0)
            return;

        //sắp xếp theo thứ tự giảm dần
        this.dataPart.sort((a, b) => (a.orders > b.orders) ? -1 : (b.orders > a.orders) ? 1 : 0);
        console.log("After sort", this.dataPart);

        //Nếu có setPID, thì tìm obj đó và lấy ra pid của obj
        let pidToListFirst = 0 //Mặc định = 0
        if (this.setPid) {
            for (let tmp of this.dataPart) {
                if (tmp.id == this.setPid) {
                    if (!pidToListFirst)
                        pidToListFirst = tmp.parent_id //Có thể = 0
                    if (pidToListFirst > 0)
                        break
                }
            }
        }
        // for (let tmp of this.dataPart) {
        //     // console.log(" Obj Pos1 = ", tmp.name, tmp);
        // }
        //Remove các anh em  nếu có (giữ lại vợ chồng)
        if (this.setPid) {
            for (let tmp of this.dataPart)
                if (tmp.parent_id == pidToListFirst && tmp.id != this.setPid && tmp.married_with != this.setPid) {
                    this.deleteObj(tmp)
                }
        }
        clsTreeTopDownCtrl.showLoader();

        let obj = new clsTreeNode();

        for (let tmp of this.dataPart) {
            obj = tmp
            //Duyệt qua các node đầu tiên TOP:
            if (!obj.married_with && obj.parent_id == pidToListFirst) {
                // console.log(" xxx2 ", obj, obj.id);
                this.countColRowForObjData(obj, 0)
            }
        }


        let tmp1 = this.optMaxRowLevelLimitShow;

        let maxRow = this.getMaxRow()

        // if(0)
        if (this.optMaxRowLevelLimitShow > 0 && maxRow >= this.optMaxRowLevelLimitShow) {
            console.log(" --- 0000-000", tmp1);
            for (var i = this.dataPart.length - 1; i >= 0; i--) {
                if (this.dataPart[i]._row >= tmp1) {
                    this.dataPart.splice(i, 1);
                }
            }
            console.log(" --- 0000-0", this.dataPart);
            this.resetAllColRowToDefault()
            console.log(" --- 0000-1", this.dataPart);
            //Tính lại hàng cột
            for (let tmp of this.dataPart) {
                obj = tmp
                //Duyệt qua các node đầu tiên TOP:
                if (!obj.married_with && obj.parent_id == pidToListFirst) {
                    // console.log(" xxx2 ", obj, obj.id);
                    this.countColRowForObjData(obj, 0)
                }
            }
        }

        console.log(" --- 001", this.dataPart);


        //Trường hợp tu dong sap xep:
        //Di chuyển gốc hàng đầu về trung tâm col
        if(!this.objBannerTop.tree_nodes_xy){
            let topNode = this.getObjByColRow(0,0);
             console.log(" topNode = ", topNode);
            let maxCol = this.getMaxCol();
            if(topNode && maxCol){
                let tmp1 = topNode._col = maxCol / 2;
                let mm = this.findGetMariedOfObj(topNode);
                if(mm){
                    mm.forEach(function (elm){
                        tmp1 ++
                        elm._col = tmp1
                    })
                }
            }
        }
        // if(maxX && minX && topNodeId && centerX)
        //     document.getElementById('svg_cont_node_' + topNodeId.id).setAttribute('x', centerX);


        this.createTreeSvg()
        this.setBannerTree();

        // this.moveObjToCenterOfViewPort(this.getTopNodeFirst())
        // this.moveCenterSvgFirstLoad()


        for (let tmp of this.dataPart) {
            this.drawLineMarried(tmp)
            this.drawLineToParent(tmp)
        }

        this.checkValidDataAndUI()

        clsTreeTopDownCtrl.hideLoader();


        let time2 = (Date.now());
        console.log(" dtime time2 = ", time2);
        console.log(" *** DTIME reDrawTree = ", time2 - time1);
        let dtime = time2 - time1
        $("#debug_svg").text("DTIME = " + dtime.toFixed(2))

        clsTreeTopDownCtrl.enableSelectElementByCtrlAndMouse();

        this.checkValidDataAndUI()


        // this.moveParentsToCenterOfChildren()

        return;


        console.log(" --- 002 ");


        this.optimizeMoveLeftSpace()
        //
        console.log(" --- 0021 ");
        this.optimizeMoveRightSpace()
        console.log(" --- 003");
        // //






        console.log(" --- 0031");
        //
        // if(this.optDebugOpt != 33333)

        {
            //24.4.23: gọi lần 2, có bị lỗi mất thành viên, ví dụ  cây: https://mytree.vn/my-tree?pid=kh687482
            this.moveParentsToCenterOfChildren()

            this.moveGrandParentToCenterLeft()
            console.log(" --- 004");
            // // //

            this.moveGrandParentToCenterRight()
            console.log(" --- 0051");
            //
            // this.drawAllNodeDebug()

            if(this.optDebugOpt != 111)
                this.moveToFixCol();

            this.moveUpTrungLapDuongNoiParent();

            // return;

            console.log("--- DataAfterMake", this.dataPart);
            if (forTester == 1)
                return
        }

        // if(this.optDebugOpt!=10)
        this.createTreeSvg()

        this.setBannerTree();




        //Bỏ qua:
        if(0)
            if(this.optUseBannerCicleTypeJs) {
                if (this.objBannerTop.banner_name_curver) {
                    if (this.optUseBannerCicleTypeJs) {
                        this.tmp_banner_name_curver = new CircleType(document.getElementById('banner_name_id'))
                            .radius(1800 - Math.abs(this.objBannerTop.banner_name_curver));
                        if (this.objBannerTop.banner_name_curver > 0)
                            this.tmp_banner_name_curver.dir(1);
                        else
                            this.tmp_banner_name_curver.dir(-1);
                    }
                }
                if (this.objBannerTop.banner_title_curver) {
                    if (this.optUseBannerCicleTypeJs) {
                        this.tmp_banner_title_curver = new CircleType(document.getElementById('banner_title_id'))
                            .radius(1800 - Math.abs(this.objBannerTop.banner_title_curver));
                        if (this.objBannerTop.banner_title_curver > 0)
                            this.tmp_banner_title_curver.dir(1);
                        else
                            this.tmp_banner_title_curver.dir(-1);
                    }
                }
            }


        for (let tmp of this.dataPart) {
            this.drawLineMarried(tmp)
            this.drawLineToParent(tmp)
        }

        this.checkValidDataAndUI()

        clsTreeTopDownCtrl.hideLoader();

        // let time2 = (Date.now());
        // console.log(" dtime time2 = ", time2);
        // console.log(" *** DTIME reDrawTree = ", time2 - time1);
        // let dtime = time2 - time1
        // $("#debug_svg").text("DTIME = " + dtime.toFixed(2))
    }
    initTopBannerEmpty() {


        if (!this.objBannerTop)
            this.objBannerTop = {}
        if (!this.objBannerTop.fontsize_name)
            this.objBannerTop.fontsize_name = 30;
        if (!this.objBannerTop.fontsize_title)
            this.objBannerTop.fontsize_title = 20;
        if (!this.objBannerTop.color_title)
            this.objBannerTop.color_title = '';
        if (!this.objBannerTop.color_name)
            this.objBannerTop.color_name = 'red';

        this.objBannerTop.banner_name_margin_top = 20;
        this.objBannerTop.banner_name_margin_bottom = 0;
        this.objBannerTop.banner_title_margin_top = 0;
        this.objBannerTop.banner_title_margin_bottom = 0;
        this.objBannerTop.banner_width = 700;
        this.objBannerTop.banner_height = 150;

        this.objBannerTop.banner_margin_top = 0;

        this.objBannerTop.banner_name_curver = 0;
        this.objBannerTop.banner_title_curver = 0;

        this.objBannerTop.banner_name_bold = 0;
        this.objBannerTop.banner_title_bold = 0;
        this.objBannerTop.banner_name_italic = 0;
        this.objBannerTop.banner_title_italic = 0;

    }

    static countSelectingNodeAndFill(){
        let cc =
        document.querySelectorAll(".svg_cont_node_cls[data-selecting='1']").length
        if(cc){
            $("#selecting_nodes").html("<span>" +  cc + "  <i class='fa fa-times-circle'></i> </span>");
                $("#selecting_nodes").show();
        }
        else{
            $("#selecting_nodes").hide();
        }
    }

    static setSelectingNodeAttribute(nodeId, isSet){


        //id_node_div_cont_sn792546
        let idNode = nodeId.replace("svg_cont_node_", '')

        let node = document.getElementById(nodeId);
        let divNode = document.getElementById('id_node_div_cont_' + idNode);

        // console.log("setSelectingNodeAttribute  ", idNode, nodeId, divNode.style.backgroundImage);

        if(isSet){

            node.setAttribute('old_x', node.getAttribute('x'));
            //Lưu lại bg image, để set lại khi Unset
            if(divNode.style.backgroundImage)
                divNode.setAttribute('data-bg', divNode.style.backgroundImage);
            divNode.style.backgroundImage = '';
            node.style.backgroundColor = 'yellow';
            node.setAttribute('data-selecting', 1);
        }else{

            node.setAttribute('old_x', null);

            if(divNode.getAttribute('data-bg')){
                divNode.style.backgroundImage = divNode.getAttribute('data-bg');
            }
            node.style.backgroundColor = 'white';
            node.setAttribute('data-selecting', 0);
        }
        clsTreeTopDownCtrl.countSelectingNodeAndFill();
    }

    /**
     *
     * @param idSvg
     * @returns clsTreeTopDownCtrl
     */
    static getInstanceSvgById(idSvg) {

        for (let obj of clsTreeTopDownCtrl.allInstance)
            if (obj.idSvgSelector == idSvg)
                return obj

        //Nếu ko có thì return first
        return clsTreeTopDownCtrl.allInstance[0]
        // return null
    }

    static movingOffset = null
    static movingNode = null

    //Kiểm tra nếu có move mouse:
    static isMovingMouseAfterDown = null

    //chế độ cho phép select các node bằng ctrl và chuột
    static enableSelectElementByCtrlAndMouse(){

        let treObj = clsTreeTopDownCtrl.getInstanceSvgById('svg_grid');
        var domToMove = document.getElementById('svg_grid');
        var selectionRect = null;
        var selectionStart = null;
        var offsetXY = domToMove.getBoundingClientRect();

        domToMove.addEventListener('mousedown', function(event) {

            treObj.isMovingMouseAfterDown = 0;

            let idNodeAtMouse = null;
            if(event.target.id.indexOf('id_node') === 0){
                let mtmp = event.target.id.split('_');
                idNodeAtMouse = mtmp[mtmp.length - 1];
                console.log("db mousedown Click idNode...", idNodeAtMouse);
                treObj.tmp_mouse_clicking_node_id = idNodeAtMouse;
                treObj.tmp_mouse_down_up_node_check = `${event.clientX}-${event.clientY}`
            }

            //Nếu là shift thì kiểm tra cả cây để check all
            if (event.shiftKey && idNodeAtMouse)
            {
                console.log(" IDNODE = ", idNodeAtMouse);
                let selected = document.getElementById('svg_cont_node_' + idNodeAtMouse).getAttribute('data-selecting');
                if(selected == 0)
                    selected = false;
                if(selected == 1)
                    selected = true;
                console.log("selected = " + selected + " / IDNODE1 = ", idNodeAtMouse, treObj.getObjFromId(idNodeAtMouse));
                clsTreeTopDownCtrl.setSelectingNodeAttribute("svg_cont_node_" + idNodeAtMouse, selected ? 0 : 1)
                let nodex = treObj.getObjFromId(idNodeAtMouse);
                if(nodex){
                    let mmObj = treObj.findGetAllChildsDeepOfObj(nodex);
                    if(mmObj){
                        console.log("mmObj = ", mmObj);
                        mmObj.forEach(function(obj){
                            clsTreeTopDownCtrl.setSelectingNodeAttribute("svg_cont_node_" + obj.id, selected ? 0 : 1)
                        })
                    }
                    if(mmObj = treObj.findGetMariedOfObj(nodex))
                    mmObj.forEach(function(obj){
                        clsTreeTopDownCtrl.setSelectingNodeAttribute("svg_cont_node_" + obj.id, selected ? 0 : 1)
                    })

                }

                return;
            }

            if (!(event.ctrlKey || event.metaKey))
                return;

            let domClicking = document.getElementById('svg_cont_node_' + idNodeAtMouse);
            if(domClicking)
                domClicking.setAttribute('old_x', domClicking.getAttribute('x'));

            //if(event.target.id.indexOf('id_node_div_cont_') === 0)
            if(idNodeAtMouse)
            {
                treObj.tmp_mouse_clicking_node_id = idNodeAtMouse //event.target.id.replace('id_node_div_cont_', '')
            }

            console.log("db event.target.id = ", event.target.id , treObj.tmp_mouse_clicking_node_id );
            //id_node_div_cont_

            //Nếu chuột đúng ở 1 pần tử, thì sẽ move nó chứ ko vẽ hình rect nữa
            //*** Nhưng phải là phần tử đang tô màu
            // if(treObj.tmp_mouse_enter_node_id && !selectionRect)
            if(treObj.tmp_mouse_clicking_node_id && !selectionRect)
            {
                let found = 0;
                domToMove.querySelectorAll(".svg_cont_node_cls[data-selecting='1']").forEach(function (nodeToMove) {
                    if(nodeToMove.getAttribute('id') == 'svg_cont_node_' + treObj.tmp_mouse_clicking_node_id){
                        // nodeToMove.setAttribute('old_x', nodeToMove.getAttribute('x'));
                        found = 1;
                    }
                })

                console.log("db mouse down");
                // if(found == 1)
                clsTreeTopDownCtrl.movingOffset = { x: event.clientX , y: event.clientY };

                return;
            }

            // Reset the color of all rectangles
            var rects = domToMove.querySelectorAll('.svg_cont_node_cls');
            rects.forEach(function(rect) {
                if(rect.id != 'selection_rect_id')
                    rect.setAttribute('fill', 'red');
                else
                    domToMove.removeChild(rect);
            });

            selectionStart = { x: event.clientX, y: event.clientY - offsetXY.top };
            selectionRect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
            selectionRect.setAttribute('x', selectionStart.x);
            selectionRect.setAttribute('y', selectionStart.y);
            selectionRect.setAttribute('width', 0);
            selectionRect.setAttribute('height', 0);
            selectionRect.setAttribute('fill', 'transparent');
            selectionRect.setAttribute('stroke', 'black');
            selectionRect.setAttribute('id', 'selection_rect_id');
            domToMove.appendChild(selectionRect);
        });

        domToMove.addEventListener('mousemove', function(event) {

            treObj.isMovingMouseAfterDown = 1;
            let idNodeAtMouse = null;
            if(event.target.id.indexOf('id_node') === 0){
                let mtmp = event.target.id.split('_');
                idNodeAtMouse = mtmp[mtmp.length - 1];
            }

            if(event.ctrlKey || event.metaKey) {
                //Di chuyen cac node da duoc Select
                if (!selectionRect) {

                    if (clsTreeTopDownCtrl.movingOffset) {
                        var dx = event.clientX - clsTreeTopDownCtrl.movingOffset.x;
                        var dy = event.clientY - clsTreeTopDownCtrl.movingOffset.y;

                        let zoom1 = treObj._panZoomTiger.getSizes().realZoom;

                        dx = dx / zoom1;
                        dy = dy / zoom1;

                        //Biến này cho biếết đang select RECT nhiềều phử tô không
                        let bSelectOneInMulti = 0;

                        let selectingRects = domToMove.querySelectorAll(".svg_cont_node_cls[data-selecting='1']");
                        selectingRects.forEach(function (nodeToMove) {
                            //Nếu chuột ở 1 node đang trong đống multi select
                            if('svg_cont_node_' + treObj.tmp_mouse_clicking_node_id == nodeToMove.getAttribute('id'))
                                bSelectOneInMulti = 1;
                        });

                        console.log(" bSelectOneInMulti = ", bSelectOneInMulti);
                        if(bSelectOneInMulti) {
                            selectingRects.forEach(function (nodeToMove) {
                                // console.log("mousemove move...");
                                var xMove = parseFloat(nodeToMove.getAttribute('x')) + dx;
                                var yMove = parseFloat(nodeToMove.getAttribute('y')) + dy;
                                // x = Math.round(x / 100) * 100;
                                //                          y = Math.round(y / 182) * 182;
                                nodeToMove.setAttribute('x', xMove);
                                nodeToMove.setAttribute('y', yMove);
                            });
                        }
                        else
                        //Neeus ko phai nhieu phan tu, thi di chuyen phan tu o Chuot
                        if(treObj.tmp_mouse_clicking_node_id){
                            console.log(" treObj.tmp_mouse_clicking_node_id = ", treObj.tmp_mouse_clicking_node_id);
                            let nodeToMove = document.getElementById('svg_cont_node_' + treObj.tmp_mouse_clicking_node_id);
                            var xMove = parseFloat(nodeToMove.getAttribute('x')) + dx;
                            var yMove = parseFloat(nodeToMove.getAttribute('y')) + dy;

                            nodeToMove.setAttribute('x', xMove);
                            nodeToMove.setAttribute('y', yMove);
                        }
                        clsTreeTopDownCtrl.movingOffset = { x: event.clientX, y: event.clientY };

                        return;
                    }
                }
                if (selectionRect) {
                    var width = Math.min(event.clientX, domToMove.clientWidth) - selectionStart.x;
                    var height = Math.min(event.clientY - offsetXY.top, domToMove.clientHeight) - selectionStart.y;
                    selectionRect.setAttribute('width', Math.abs(width));
                    selectionRect.setAttribute('height', Math.abs(height));
                    selectionRect.setAttribute('x', width > 0 ? selectionStart.x : Math.max(event.clientX, 0));
                    selectionRect.setAttribute('y', height > 0 ? selectionStart.y : Math.max(event.clientY - offsetXY.top, 0));
                }
            }
        });

        domToMove.addEventListener('mouseup', function(event) {

            clsTreeTopDownCtrl.movingOffset = null;

            let yTopElm = treObj.startY + treObj.bannerHeight;
            let hOneElmAndSpaceY = treObj.heightCell + treObj.spaceBetweenCellY

            //let minX = clsTreeTopDownCtrl.getMinXNotIncludeSeleting()
            // let minX = clsTreeTopDownCtrl.getMinX()
            ///Tìm minx,y để lấy vị trí STT của từng elm
            // let minX = 1000000000000;             let minY = 1000000000000;
            // document.querySelectorAll(".svg_cont_node_cls").forEach(function (one) {
            //     // console.log("MinXY one.x " , one.getAttribute('x'));
            //     let x = parseInt(one.getAttribute('x'));
            //     let y = parseInt(one.getAttribute('y'));
            //     if(x < minX)
            //         minX = x;
            //     if(y < minY)
            //         minY = y;
            // })
            //
            // console.log("MinXY = ", minX, minY);
            //END Show Grid ///////////////////

            // console.log(" yTopElm ", yTopElm);
            // console.log(" hOneElmAndSpaceY ", hOneElmAndSpaceY);

            //Làm tròn vị trí
            var haveSelectMulti = 0;
            let haveUpdateXy = 0;
            let x1_3 = treObj.widthCell / treObj.spaceXBetweenCellDevidedBy;
            domToMove.querySelectorAll(".svg_cont_node_cls[data-selecting='1']").forEach(function (nodeToMove) {
                // console.log("mouseup move...");
                if(clsTreeTopDownCtrl.setNXNyWhenMove(nodeToMove, treObj))
                    haveUpdateXy = 1;
                haveSelectMulti = 1;
            })

            if(treObj.isMovingMouseAfterDown && (event.ctrlKey || event.metaKey))
            {
                if (treObj.tmp_mouse_clicking_node_id) {
                    console.log("db update one node...", treObj.tmp_mouse_clicking_node_id);
                    let nodeToMove = document.getElementById('svg_cont_node_' + treObj.tmp_mouse_clicking_node_id);
                    if (clsTreeTopDownCtrl.setNXNyWhenMove(nodeToMove, treObj))
                        haveUpdateXy = 1;
                }
            }

            if(haveUpdateXy){
                treObj.removeAllConnectLineParentAndMarried()
                for (let tmp of treObj.dataPart) {
                    treObj.drawLineMarried(tmp)
                    treObj.drawLineToParent(tmp)
                }
            }


//Nếu có ctrl thì mouseup sẽ là chọn phần tử hay không:
            if (event.ctrlKey || event.metaKey){
                console.log("db Mouse up... + Ctrl" , event.target.id);
                // treObj.tmp_mouse_clicking_node_id = 0;
                //Neu mouse KHÔNG (xy giữ nguyên với mouse down) di chuyen, thi node nao duoc click se them vao list selecting
                if(treObj.tmp_mouse_down_up_node_check === `${event.clientX}-${event.clientY}`){
                    if(event.target.id.indexOf('id_node') === 0)
                    {
                        let mtmp = event.target.id.split('_');
                        let idNodeAtMouse = mtmp[mtmp.length - 1];
                        console.log("db Move Click idNode...", idNodeAtMouse);
                        let elmClick = document.getElementById("svg_cont_node_" + idNodeAtMouse);
                        // treObj.tmp_mouse_down_up_node_check = 'thesamexy';
                        if(elmClick)
                            if(elmClick.getAttribute('data-selecting') == 1)
                                clsTreeTopDownCtrl.setSelectingNodeAttribute(elmClick.id, 0);
                            else
                                clsTreeTopDownCtrl.setSelectingNodeAttribute(elmClick.id, 1);
                    }
                }
            }


            if (selectionRect && (event.ctrlKey || event.metaKey)) {
                var selectBox = selectionRect.getBBox();
                console.log(" selectBox = ", selectBox);
                console.log(" this._panZoomTiger.getSizes().realZoom = ", treObj._panZoomTiger.getSizes(), treObj._panZoomTiger.getPan());
                var rects = domToMove.querySelectorAll('.svg_cont_node_cls');

                rects.forEach(function(rect) {
                    var rectBox = rect.getBBox();

                    //Xác định zoom, pan để định vị lại giao nhau
                    let panx = treObj._panZoomTiger.getPan().x;
                    let pany = treObj._panZoomTiger.getPan().y;
                    let zoom1 = treObj._panZoomTiger.getSizes().realZoom;

                    //Nếu hai hình giao nhau, công thức gồm zoompan tương ứng:
                    if (
                        zoom1 * (rectBox.x ) + panx <  selectBox.x + selectBox.width&&
                        zoom1 * (rectBox.x + rectBox.width) + panx > selectBox.x &&
                        zoom1 * (rectBox.y) + pany < selectBox.y + selectBox.height &&
                        zoom1 * (rectBox.y + rectBox.height) + pany > selectBox.y
                    )
                    {
                        console.log("Foiund One...", rect, rect.id );
                        clsTreeTopDownCtrl.setSelectingNodeAttribute(rect.id, 1);
                        // rect.setAttribute('style', 'background-color: yellow');
                        // rect.setAttribute('data-selecting', '1');
                    }
                });

                clsTreeTopDownCtrl.countSelectingNodeAndFill();

                domToMove.removeChild(selectionRect);
                selectionRect = null;

            }

            if(haveUpdateXy) {
                let minX = clsTreeTopDownCtrl.getMinX()
                console.log(" have updatexy ");
                let nodeXy = [];

                let minY = 10000;
                var nodes = domToMove.querySelectorAll('.svg_cont_node_cls');
                nodes.forEach(function (one) {

                    let x = one.getAttribute('x');
                    let y = one.getAttribute('y');

                    //Cap nhat lai all nx
                    let nx = clsTreeTopDownCtrl.getNxNyFromXY(treObj , x , minX);
                    one.setAttribute('nx', nx);

                    let ny = one.getAttribute('ny');
                    let id = one.getAttribute('id').replace('svg_cont_node_', '');
                    // console.log(" x y id ", x, y, id);
                    nodeXy.push({id: id, x: x, y: y, nx:nx, ny:ny, spx: treObj.spaceXBetweenCellDevidedBy})
                    if(parseInt(y) < minY)
                        minY = parseInt(y);

                })
                if(!nodeXy || nodeXy.length == 0){
                    alert("Error: empty nodeXY List?");
                }
                else {
                    //Sau khi da move thi moi lay lai MinX
                    let minX = clsTreeTopDownCtrl.getMinX()
                    treObj.updateSyncXyNodesToTree(nodeXy, minX, minY);
                }
            }
            else{
                console.log(" not updatexy ");
            }

            treObj.tmp_mouse_clicking_node_id = 0;

        });

        $(document).keydown(function(event) {
            if (event.ctrlKey || event.metaKey){


                console.log("ctrlKey down....");

                $(".spanRowColInfo").show();


                // svg1._panZoomTiger.disableZoom()
                treObj._panZoomTiger.disablePan()
            }
        });

        $(document).keyup(function(event) {
            if (event.ctrlKey || event.metaKey){



            }


        });

        window.addEventListener('keyup', function(event) {

            if(event.key == "Control" || event.key == "Meta"){
                console.log("ctrlKey / Metaup up....");


                $(".spanRowColInfo").hide();

                treObj._panZoomTiger.enablePan()

                // svg1._panZoomTiger
            }

            treObj._panZoomTiger.enablePan();

            if (event.ctrlKey || event.metaKey) {
                console.log("ctrlKey up....");
                //remove het rectangle
                let elm = document.getElementById('selection_rect_id')
                if(elm)
                    elm.parentNode.removeChild(elm);

                console.log('The Ctrl key was released.');
                // svg1._panZoomTiger.enableZoom()
                treObj._panZoomTiger.enablePan()
            }

            //Phim esc bỏ hết
            if (event.key === 'Escape' || event.key === 'Esc') {
                console.log("Esc press...");
                domToMove.querySelectorAll(".svg_cont_node_cls[data-selecting='1']").forEach(function (nodeToMove) {
                    clsTreeTopDownCtrl.setSelectingNodeAttribute(nodeToMove.id, 0);
                    // nodeToMove.setAttribute('data-selecting', '0');
                    // nodeToMove.setAttribute('style', 'background-color: transparent');
                })
            }

        });

        //disable Zoom Broswer với ctrl + wheel mouse
        window.addEventListener('wheel', function(event) {
            if (event.ctrlKey || event.metaKey) {
                event.preventDefault();
            }
        }, { passive: false });
    }


    static unSelectNodes(svgId = 'svg_grid') {
        console.log("Unselect node...");

        document.querySelectorAll('.svg_cont_node_cls[data-selecting="1"]').forEach(function(elm){
            clsTreeTopDownCtrl.setSelectingNodeAttribute(elm.id, 0);
            // elm.setAttribute("data-selecting", 0);
            // elm.style.backgroundColor = "transparent";
            $("#selecting_nodes").hide();
        });
    }

    checkValidDataAndUI() {


        if(this.optShowOnlyMan)
            return;

        let notFoundArrayObj = []
        let that = this

        for (let obj of that.dataPart) {
            let idsvg = obj.id
            let found = 0
            $(".svg_cont_node_cls").each(function () {
                if ($(this).attr('data-svg-id') == idsvg) {

                    found = 1
                    return;
                }
            })
            if (!found)
                notFoundArrayObj.push(obj)
        }

        let strError = ''

        //Tìm xem có phần tử nào bị trùng rowCol không:
        for (let obj of this.dataPart)
            for (let obj1 of this.dataPart)
                if (!this.checkIgnoreObj(obj) && !this.checkIgnoreObj(obj1))
                    if (obj.id != obj1.id && obj._row == obj1._row && obj._col == obj1._col)
                        strError += ` (Trùng cột Id= ${obj1.id} | Hàng ${obj1._row}, Cột=${obj1._col} |Tên: ${obj1.name} ) `

        if (notFoundArrayObj.length > 0) {
            for (let obj of notFoundArrayObj) {
                if (this.checkIgnoreObj(obj))
                    continue
                if (this.optShowOnlyMan && !this.checkNodeIsMainMan(obj))
                    continue
                strError += " (Không thấy: " + obj.name + "(" + obj.id + ") ) "
            }
            if (strError) {
                $("#check_error_node").text("Có lỗi: " + strError)
                $("#check_error_node").show()
            }
        }
        console.log(" Notfound array = ", notFoundArrayObj, strError);
    }

    drawTreeSvg() {
        if (!this.idSvgSelector) {
            throw new Error("Not define idSvgSelector!");
            return;
        }
        if (!this.optShowMarried) {
            console.log(" dataPart Not optShowMarried", this.dataPart);
        }
        this.optBorderMainMan = 0
        if (this.optShowOnlyMan) {
        } else
            this.optBorderMainMan = 1

        console.log(" === AllNodeBeforeDraw = ", this.dataPart);
        this.reDrawTree()


        window.scrollTo((document.body.scrollWidth - document.body.clientWidth) / 2 + 200, 0);

        console.log("Scrool center...", document.body.scrollLeft);

        console.log(" ===  AllNodeAfterDraw1 = ", this.dataPart);
        // console.log(" ===  AllNodeAfterDraw2 = ", JSON.parse(this.objBannerTop.tree_nodes_xy));
        // console.log(" AllNodeAfterDraw = ");
        // console.log(JSON.stringify(this.dataPart));

    }

    /**
     * Để gửi delete all id lên api
     * @param mm
     * @returns {string}
     */
    static getStringIdOfNodeArraySeparateByComma(mm, ignoreNotBelongAcc = 0) {
        let str = ''
        if (mm)
            for (let obj of mm) {

                if(ignoreNotBelongAcc && obj.belong_other)
                    continue;
                str += obj.id + ' '
            }
        str = str.trim()
        str = str.replaceAll(" ", ',')
        return str
    }

    /**
     * Theo thứ tự order, vợ chồng Cả sẽ có order lớn nhất
     * @param obj
     * @param objMarried
     */
    isFirstMarriedObObj(obj, objMarried) {

        if (!objMarried)
            return false;

        let mm = this.findGetMariedOfObj(obj)
        //Nếu chỉ có 1 vợ thì ok
        if (mm && mm.length == 1)
            return true

        if (!mm || mm.length == 0)
            return false

        //Vì đã sắp theo thứ tự lấy về, nên mm0 chính là vợ chồng cả

        // let maxOrders = -1
        // for(let vc of mm)
        //     if(vc.orders && vc.orders > maxOrders)
        //         maxOrders = vc.orders
        //
        // if(maxOrders > 0)
        //     if(objMarried.orders == maxOrders)
        //         return true

        if (objMarried.id == mm[0].id)
            return true
        return false
    }

    getMaxMinColOfChild(obj) {
        let minColChild = 1000000000
        let maxColChild = -1
        let haveChild = 0
        for (let con of this.dataPart) {
            if (con.parent_id == obj.id) {

                if (this.checkIgnoreObj(con))
                    continue

                if (minColChild < 0)
                    minColChild = con._col

                haveChild++
                if (con._col > maxColChild)
                    maxColChild = con._col
                if (con._col < minColChild)
                    minColChild = con._col
            }
        }
        if (!haveChild)
            return null
        return [minColChild, maxColChild]
    }

    //Xét thêm cả vc hasChild
    hasChild(obj) {
        let pid = obj.id
        if (obj.married_with)
            pid = obj.married_with
        for (let any of this.dataPart) {
            if (this.checkIgnoreObj(any))
                continue
            if (any.parent_id == pid)
                return 1
        }
        return 0
    }

    hasChild_DEL(obj) {
        for (let any of this.dataPart) {
            if (this.checkIgnoreObj(any))
                continue

            if (any.parent_id == obj.id)
                return 1
        }
        return 0
    }

    hasBrotherSister(obj) {
        for (let any of this.dataPart) {
            if (this.checkIgnoreObj(any))
                continue
            if (any.id != obj.id)
                if (any.parent_id == obj.parent_id) {
                    // console.log("xxx5, anh em cua ", obj, any);
                    return 1
                }
        }
        return 0
    }

    getNodeInRow(row) {
        let mm = []
        for (let any of this.dataPart) {
            if (any._row == row)
                mm.push(any)
        }
        return mm
    }


    //Di chuyển đến cạnh phần tử gần nhất bên phải
    pushToEmptyPositionRight(obj) {

        if (obj.id == 'vx486203' || obj.id == 'ma394293') {
            console.log("pushToEmptyPositionRight obj.idx == ", obj.id);
            return;
        }

        let minColEmptyRight1 = -1
        for (let any of this.dataPart) {
            if (any.parent_id == obj.parent_id && any._row == obj._row && any.id != obj.id && any._col > obj._col) {
                //Tìm ra anh em gần nhất bên phải
                if (minColEmptyRight1 < 0)
                    minColEmptyRight1 = any._col
                //Tìm thằng nhỏ nhất bên phải
                if (minColEmptyRight1 > any._col)
                    minColEmptyRight1 = any._col
            }
        }

        if (minColEmptyRight1 > 0 && obj._col != minColEmptyRight1 - 1)
            obj._col = minColEmptyRight1 - 1
    }

    //Di chuyển đến cạnh phần tử gần nhất bên trái
    pushToEmptyPositionLeft(obj, withMarried = 0) {

        if (obj.id == 'vx486203' || obj.id == 'ma394293') {
            console.log("pushToEmptyPositionLeft obj.idx == ", obj.id);
            return;
        }

        let maxColEmptyLeft1 = -1
        for (let any of this.dataPart) {
            if (any.parent_id == obj.parent_id && any._row == obj._row && any.id != obj.id && any._col < obj._col) {
                //Tìm ra anh em gần nhất bên phải
                if (maxColEmptyLeft1 < 0)
                    maxColEmptyLeft1 = any._col
                //Tìm thằng lớn nhất bên phải
                if (maxColEmptyLeft1 < any._col)
                    maxColEmptyLeft1 = any._col
            }
        }
        if (maxColEmptyLeft1 > 0 && maxColEmptyLeft1 + 1 != obj._col){
            let delta = maxColEmptyLeft1 + 1 - obj._col;
            obj._col = maxColEmptyLeft1 + 1

            //Xem có vợ chồng xa thì kéo về:
            if(withMarried){
                let mm = this.findGetMariedOfObj(obj);
                if(mm && mm.length){
                    for(let tmp of mm){
                        // if(this.optDebugOpt == 111)
                        tmp._col += delta
                    }
                }
            }
        }
    }

    getMaxCol() {
        let max = 0
        for (let any of this.dataPart)
            if(!this.checkIgnoreObj(any))
            if (any._col > max)
                max = any._col
        return max
    }

    getMaxRow() {
        let max = 0
        for (let any of this.dataPart)
            if(!this.checkIgnoreObj(any))
            if (any._row > max)
                max = any._row
        return max
    }

    deleteEmptyCol() {
        // for(let i = 0; i < 5; i++)
        {
            let maxCol = this.getMaxCol()
            for (let i = 0; i < maxCol; i++) {
                let foundCol = 0
                for (let any of this.dataPart) {
                    if (this.checkIgnoreObj(any))
                        continue
                    if (any._col == i)
                        foundCol = 1
                }

                //Tất cả các cột sau trừ đi 1
                if (!foundCol) {
                    for (let any of this.dataPart) {
                        if (any._col > i)
                            any._col--
                    }
                }
            }
        }
    }

    moveKhongCoConThiMoveSatAnhEm(r) {
        // if(r != 4)
        //     return
        for (let any of this.dataPart) {
            if (this.checkIgnoreObj(any))
                continue

            if (!any.married_with)
                if (any._row == r)
                    if (!this.hasChild(any) && this.hasBrotherSister(any)) {

                        this.pushToEmptyPositionRight(any)
                        //this.drawAllNodeDebug()
                    }
        }

        for (let any of this.dataPart) {
            if (this.checkIgnoreObj(any))
                continue
            if (!any.married_with)
                if (any._row == r)
                    if (!this.hasChild(any) && this.hasBrotherSister(any)) {

                        if(this.optDebugOpt != 33333){
                            console.log("any = " , any.id);
                        }
                            this.pushToEmptyPositionLeft(any, 1)
                        // this.drawAllNodeDebug()
                        // console.log("xxx5 move ", any, this.dataAll);
                    }
        }
    }

    //Bỏ qua obj nếu chỉ lấy con trai, hoặc ko show VC
    checkIgnoreObj(obj) {
        if (this.optShowOnlyMan && obj.gender == 2)
            return 1;
        if (this.optShowOnlyMan && obj.married_with)
            return 1;
        if (!this.optShowMarried && obj.married_with)
            return 1;
        if (this.optShowOnlyMan && !this.checkNodeIsMainMan(obj))
            return 1;
        return 0
    }

    checkIfObjCanMoveFromToCol(obj, toCol) {
        for (let any of this.dataPart) {
            if (!any.married_with)
                if (any._row == obj._row) {
                    if (obj._col > toCol) {
                        for (let i = toCol; i < obj._col; i++)
                            if (any._col == i)
                                return 0
                    } else {
                        for (let i = toCol; i > obj._col; i--)
                            if (any._col == i)
                                return 0
                    }
                }
        }
        return 1
    }

    //Di chuyen obj den trung tam con cua obj
    moveParentsToCenterOfChildren0(obj) {

        // if(obj.name == 'Le Van Suu')
        if (obj.id == 2) {

        }

        //Nếu là vc thì ko cần xử lý, vì đã bám vào vc gốc
        if (obj.married_with)
            return


        //Tìm các con của obj, lấy ra min+max col
        let maxMin = this.getMaxMinColOfChild(obj)
        if (!maxMin)
            return
        let [minColChild, maxColChild] = maxMin

        let mmVoChong = [obj]
        // console.log(" mmVoChong1 = " , mmVoChong);
        let lenVoChong = 1
        //Trường hợp cả bố mẹ hiện lên, thì tính lại lenParents
        //if(!this.optShowOnlyMan)
        if (!this.optShowOnlyMan && this.optShowMarried) {
            // console.log(" mmVoChong1333 = xxx");
            //Tính số vợ của obj
            let tmp = this.findGetMariedOfObj(obj)
            if (!tmp)
                mmVoChong = [obj]
            else {
                tmp.push(obj)
                mmVoChong = tmp
            }

            lenVoChong = mmVoChong.length
        }
        let nShiftRight = (maxColChild - minColChild - lenVoChong) / 2

        if (nShiftRight < 0) {
            nShiftRight = 0
        }
        nShiftRight = Math.ceil(nShiftRight)
        // nShiftRight = Math.floor(nShiftRight)

        //Lấy ra vị trí đầu tiên cần di chuyển Obj đến
        let needMoveTo = minColChild + nShiftRight
        let deltaMove = needMoveTo - obj._col

        if(obj.id == 'xx813248'){
            console.log(" xxx1 ", deltaMove, needMoveTo);
        }

        let lastMarried = this.getLastMarriedOfObj(obj);
        if(!lastMarried)
            lastMarried = obj;

        // console.log(" deltaMovexxx = " , obj , deltaMove);
        //Nếu cha ở bên trái, thì ko cần move nữa???
        // if(deltaMove < 0)
        //     return

        //Kiểm tra xem obj có thể move đến vị trí mới không, nghĩa là từ vị trí cũ đến mới phải trống?
        //nếu có phần tử thì ko thể move, return luôn
        // if (!this.checkIfObjCanMoveFromToCol(lastMarried, lastMarried._col + nShiftRight)) {
        //     console.log("moveParentsToCenterOfChildren0 Can not move to ", obj, needMoveTo);
        //     return
        // }

        if (!this.checkIfObjCanMoveFromToCol(obj, needMoveTo)) {
            console.log(" Can not move to ", obj, needMoveTo);
            return
        }


        let hasError = 0

        //Xem có nhầm lẫn chiếm mất chỗ của 1 obj nào đó ko:
        let maxColVC = 0
        if (mmVoChong)
            for (let tmp of mmVoChong)
                if (tmp._col > maxColVC)
                    maxColVC = tmp._col

        for (let any of this.dataPart) {
            if (any._row == obj._row) {
                if (this.checkIgnoreObj(any))
                    continue
                if(deltaMove > 0)
                if(any._col > maxColVC)
                if (maxColVC + deltaMove >= any._col) {
                    hasError = 1
                    break
                }
                //Không có deltaMove < 0?
                // if(deltaMove < 0)
                //     if (maxColVC + deltaMove >= any._col) {
                //         hasError = 1
                //         break
                //     }
            }
        }

        if (mmVoChong)
            if (!hasError)
                for (let tmp of mmVoChong) {
                    tmp._col += deltaMove

                }
    }

    getMinColInRow(r, data = null) {
        let x = -1
        if (data == null)
            data = this.dataAll
        if (data && data.length)
            for (let obj of data) {
                if(this.checkIgnoreObj(obj))
                    continue;
                if (obj._row == r) {
                    if (x < 0 && obj._col >= 0)
                        x = obj._col
                    if (obj._col >= 0 && obj._col < x)
                        x = obj._col
                }
            }
        return x
    }

    getMaxRowInData(data){
        let maxRow = 0;
        for (let obj of data) {
            if(maxRow < obj._row)
                maxRow = obj._row
        }
        return maxRow;
    }

    getMaxColInRow(r, data) {
        if (data == null)
            data = this.dataAll
        let x = -1
        if (data && data.length)
            for (let obj of data) {

                if(this.checkIgnoreObj(obj))
                    continue;

                if (obj._row == r) {
                    if (obj._col >= 0 && x < 0)
                        x = obj._col
                    if (obj._col > x)
                        x = obj._col
                }
            }
        return x
    }

    countNMarried(obj) {
        if (!this.findGetMariedOfObj(obj))
            return 0;
        return this.findGetMariedOfObj(obj).length
    }

    getLastMarriedOfObj(obj) {
        let mm = this.findGetMariedOfObj(obj)
        if (mm && mm.length)
            return mm.pop()
        return null
    }

    //Tính toán khoảng cách tối đa có thể move sang trái của một obj và các con
    //chính là khoảng cách nhỏ nhất của các lá cây bên trái (từ trên xuống), tới 1 phần tử của cây khác, hoặc mép svg
    countMaxCanMoveLeftOfObjToEmptySpace(obj, mmChild) {
        let [maxRow, maxCol] = clsTreeTopDownCtrl.getMaxColRow(this.dataPart)
        let minSpace = 100000
        let exit1 = 0
        if(!mmChild){
            return 0;
            // let mmChild = this.findGetAllChildsDeepOfObjAndMarried(obj)
            // mmChild.push(obj);
        }
        for (let r1 = 0; r1 <= maxRow; r1++) {
            let foundOneObjLeft = 0
            let minColInRow = this.getMinColInRow(r1, mmChild)
            if (minColInRow >= 0) {
                //Tìm từ col đó trở về 0, xem khoảng trống nhỏ nhất
                for (let c2 = minColInRow - 1; c2 >= 0; c2--) {
                    //Gặp 1 phần tử đầu tiên thì break vì đã tìm ra khoảng cách
                    if (this.getObjByColRow(c2, r1)) {
                        foundOneObjLeft = 1
                        let space = minColInRow - this.getObjByColRow(c2, r1)._col - 1
                        if (space < 1) {
                            exit1 = 1
                            break
                        }
                        if (space < minSpace) {
                            minSpace = space
                            break
                        }
                    }
                }
                //Nếu ko thấy 1 phần tử nào bên trái, thì bên trái là mép
                if (!foundOneObjLeft)
                    if (minColInRow < minSpace) {
                        minSpace = minColInRow
                        // break
                    }
            }
            if (exit1)
                break
        }
        if (exit1)
            return 0;
        if (minSpace >= 1000000 || minSpace <= 0)
            return 0
        return minSpace
    }

    //Tính toán khoảng cách tối đa có thể move sang phải của một obj và các con
    //chính là khoảng cách nhỏ nhất của các lá cây bên phải (từ trên xuống), tới 1 phần tử của cây khác, hoặc mép svg
    countMaxCanMoveRightOfObjToEmptySpace(obj, mmChild, ifHaveNotAnyInRightReturnMax = 0) {
        let [maxRow, maxCol] = clsTreeTopDownCtrl.getMaxColRow(this.dataPart)
        //Xét obj hiện tại
        //Bắt đầu duyệt từ trên xuống để tìm ra space trống nhỏ nhất bên phải của cây thuộc obj này
        //Nếu space trống hàng nào đó =0 thì dừng ko move cây sang phải
        if(!mmChild){
            return 0
            // let mmChild = this.findGetAllChildsDeepOfObjAndMarried(obj)
            // mmChild.push(obj);
        }

        if(obj.id == 'mc756020'){
            console.log(" xxxx");
        }

        let minSpace = 1000001
        let exit1 = 0
        for (let r1 = 0; r1 <= maxRow; r1++) {
            let maxColInRow = this.getMaxColInRow(r1, mmChild)
            if (maxColInRow >= 0) {

                //Tìm từ col maxCol đó đến hết hàng, xem khoảng trống nhỏ nhất
                for (let c2 = maxColInRow + 1; c2 <= maxCol; c2++) {
                    //Gặp 1 phần tử đầu tiên thì break
                    if (this.getObjByColRow(c2, r1)) {
                        let space = this.getObjByColRow(c2, r1)._col - maxColInRow - 1
                        //nếu không có khoảng trống nào thì exit
                        if (space < 1) {
                            exit1 = 1
                            break
                        }
                        //nếu có 1 khoảng trống, thì xem nó nhỏ nhất chưa
                        if (space < minSpace) {
                            minSpace = space
                            break
                        }
                    }
                }
            }
            if (exit1)
                break
        }

        if (exit1)
            return 0;

        if(ifHaveNotAnyInRightReturnMax && minSpace >= 1000000)
            return minSpace

        if (minSpace >= 1000000 || minSpace <= 0)
            return 0
        return minSpace
    }

    /**
     * cột lớn hơn cha, hoặc không có cha (pid = 0) trống bên trái, xem các hàng con ở dưới, trống bên trái
     tìm số trống bên trái nhỏ nhất, và move toàn bộ cây , - col nhỏ nhất
     */
    optimizeMoveLeftSpace() {

        // return

        //Lặp lại 1 số lần nếu cần, để quét đi quét lại,
        //vì bên dưới khi đã sort, có thể sẽ thừa ra space, bên trên sẽ sort lại lần nữa...
        for (let loop = 0; loop < 5; loop++) {
            let [maxRow, maxCol] = clsTreeTopDownCtrl.getMaxColRow(this.dataPart)
            //Duyệt từ trên xuống, từ trái qua phải
            for (let r = 0; r <= maxRow; r++) {
                for (let c = 0; c <= maxCol; c++) {

                    let obj = this.getObjByColRow(c, r)
                    if (!obj)
                        continue
                    if (obj.id == 91) {
                        // console.log(" xxx51 ", obj);
                    }

                    //Nếu có parent
                    if (obj.parent_id) {
                        let pr = this.getObjFromId(obj.parent_id)
                        //Nếu có cha, cột nằm bên trái cột cha, thì bỏ qua vì ko dịch chuyển nó bên trái cha làm gì
                        if (pr)
                            if (obj._col <= pr._col)
                                continue
                    }

                    //Xét obj hiện tại
                    //Bắt đầu duyệt từ trên xuống để tìm ra space trống nhỏ nhất bên trái của cây thuộc obj này
                    //Nếu space trống hàng nào đó =0 thì dừng ko move cây sang trái
                    let mmChild = this.findGetAllChildsDeepOfObjAndMarried(obj)
                    mmChild.push(obj);

                    let minSpace = 100000

                    minSpace = this.countMaxCanMoveLeftOfObjToEmptySpace(obj, mmChild)
                    if (minSpace < maxCol) {
                        for (let objx of mmChild) {
                            objx._col -= minSpace
                        }
                    }
                }
            }
        }

    }

    /**
     * Tương tự hàm Left trên
     */
    optimizeMoveRightSpace() {
        //Lặp lại 1 số lần nếu cần, để quét đi quét lại,
        //vì bên dưới khi đã sort, có thể sẽ thừa ra space, bên trên sẽ sort lại lần nữa...
        for (let loop = 0; loop < 5; loop++) {
            let [maxRow, maxCol] = clsTreeTopDownCtrl.getMaxColRow(this.dataPart)
            //Duyệt từ trên xuống, từ trái qua phải
            for (let r = 0; r <= maxRow; r++) {
                for (let c = 0; c <= maxCol; c++) {
                    let obj = this.getObjByColRow(c, r)
                    if (!obj)
                        continue
                    if (obj.id == 21766) {
                        console.log(" xxx51 ", obj);
                    }
                    if (obj.married_with)
                        continue;
                    //Nếu có parent
                    if (obj.parent_id) {
                        let pr = this.getObjFromId(obj.parent_id)
                        //Nếu có cha, cột nằm bên phải cột cha, thì bỏ qua vì ko dịch chuyển nữa
                        if (pr)
                            if (obj._col >= pr._col)
                                continue
                    } else
                        continue;

                    //Xét obj hiện tại
                    //Bắt đầu duyệt từ trên xuống để tìm ra space trống nhỏ nhất bên phải của cây thuộc obj này
                    //Nếu space trống hàng nào đó =0 thì dừng ko move cây sang phải
                    let mmChild = this.findGetAllChildsDeepOfObjAndMarried(obj)
                    mmChild.push(obj);

                    let minSpace = this.countMaxCanMoveRightOfObjToEmptySpace(obj, mmChild)
                    if (minSpace)
                        if (minSpace < maxCol) {
                            for (let objx of mmChild) {
                                objx._col += minSpace
                            }
                        }
                }
            }
        }
    }

    moveKhongCoConThiMoveSatAnhEmAll() {
        let [maxRow, maxCol] = clsTreeTopDownCtrl.getMaxColRow(this.dataPart)
        for (let r = 0; r <= maxRow; r++) {
            this.moveKhongCoConThiMoveSatAnhEm(r)
        }

    }


    //Di chuyển bố mẹ sang giữa các con
    moveParentsToCenterOfChildren() {
        // return

        console.log(" moveParentsToCenterOfChildren ... ");

        //Duyệt từ dưới lên trên, từ trái qua phải
        //Tính center của các con, chiều dài của bố mẹ
        //Tính vị trí đầu tiên có thể đặt bố mẹ, suy ra vị trí có thể shift ra
        let [maxRow, maxCol] = clsTreeTopDownCtrl.getMaxColRow(this.dataPart)

        console.log(" moveParentsToCenterOfChildren maxRow, maxCol  " , maxRow, maxCol);
        for (let r = maxRow; r >= 0; r--) {
            for (let c = maxCol; c >= 0; c--) {
                for (let obj of this.dataPart) {
                    if (obj._row == r && obj._col == c) {
                        if (this.checkIgnoreObj(obj))
                            continue;
                        this.moveParentsToCenterOfChildren0(obj)
                    }
                  }
            }
            //Phải thực hiện ngay sau khi move chaMe vào giữa các con
            //24.4.2023 bỏ hàm này vì ko hiểu sao bị trùng vào vị trí vợ của anh em, nếu ko có anh em
            // if(this.optDebugOpt != 33333)
//                this.moveKhongCoConThiMoveSatAnhEm(r)

            this.deleteEmptyCol()
        }
    }

    getObjByColRow(col, row) {
        for (let obj of this.dataPart) {
            if (obj._col == col && obj._row == row)
                return obj
        }
        return null
    }

    //Tìm tất cả con cháu của obj
    findGetAllChildsDeepOfObj(obj) {
        let mmChild = []
        for (let any of this.dataPart) {
            if (this.checkObjIsChildOfOther(any, obj))
                mmChild.push(any)
        }
        return mmChild
    }

    createDrawOneNode(obj, rectX, rectY){

        rectX = parseInt(rectX)
        rectY = parseInt(rectY)

        console.log(" createDrawOneNode obj = ", obj.id, obj.name, rectX, rectY);

        let padNewBorder = '';
        let padShow
        if (obj._mark_add_new) {
            padNewBorder = ';border-color: red;'
            padShow = ';display: block;'
            obj._mark_add_new = 0
        }
        let newDiv1 = document.createElement('div');
        let imgLink = '/images/icon/man.jpg'
        if (obj.gender == 2)
            imgLink = '/images/icon/woman.jpg'

        if (obj._image_list && obj._image_list.length && obj._image_list.indexOf("/") > -1)
            imgLink = obj._image_list
        else if (obj._image_list && obj._image_list.length && obj._image_list[0].thumb && obj._image_list[0].thumb.indexOf("/") > -1)
            imgLink = obj._image_list[0].thumb

        // console.log("Draw: " , obj, obj.name);
        let padColor = null

        if (this.optBorderMainMan)
            if (this.checkNodeIsMainMan(obj, this.dataPart)) {
                padNewBorder = ';border-color: green; border-width: 0px'
                padColor = '; color: brown ; '
                // rect.setAttribute("style", "fill:none;stroke:red;stroke-width:" +
                //     strokeWidth + ";fill-opacity:0.1;stroke-opacity:0.6");
            }

        //let rectHeight = this.heightCell
        let grid = this.getRootSvgIfHavePanZoom()
        let objContSvg = document.createElementNS('http://www.w3.org/2000/svg', "foreignObject");
//nếu ko tạo mới thì chỉ set lại thuộc tính:
        objContSvg.setAttribute('id', "svg_cont_node_" + obj.id);
        objContSvg.setAttribute('data-svg-id', obj.id);
        objContSvg.setAttribute('class', "svg_cont_node_cls");

        objContSvg.setAttribute('nx', obj.nx);
        objContSvg.setAttribute('ny', obj._row);

        objContSvg.setAttribute('x', rectX);
        objContSvg.setAttribute('y', rectY);


        objContSvg.setAttribute('width', this.widthCell);
        objContSvg.setAttribute('height', this.heightCell);



        if (obj.birthday == undefined)
            obj.birthday = ''
        if (obj.title == undefined || obj.title == 'null')
            obj.title = ''
        if (obj.date_of_death == undefined || obj.date_of_death == 'null')
            obj.date_of_death = ''



        let strName = '';
        let nameX = "<span class='node_name_one' id='id_node_name_" + obj.id + "' style='" + "'>" + obj.name;
        if (this.optShowDebugGrid)
            strName += " "
        nameX += "</span>"
        let titleX = "<span class='node_title' id='id_node_title_" + obj.id + "'>" + obj.title + "</span>";

        if(!this.objBannerTop.show_node_title){
            titleX = '';
        }

        if(this.objBannerTop.title_before_or_after_name)
            strName += titleX + nameX
        else
            strName += nameX + titleX


        let imgHeight = Math.round(this.heightCell / 3) - 2;

        let padHeight = ' ;xx1  ;height: '+ (this.heightCell - 8) +'px;'
        if (this.optRemoveImage)
            padHeight = ';xxx2 ;height: '+ (this.heightCell - 8) + 'px;';

        let bgImg = ';background-size: 100% 100%;background-image: url("/images/border-frame-img2/a013.png");';

        //if(obj.gender == 1)
        //{
        if (this.objBannerTop.member_background_img && this.objBannerTop.member_background_img.indexOf("/") >= 0)
            bgImg = ';background-size: 100% 100%;background-image: url("' + this.objBannerTop.member_background_img + '");';
        //}
        if(obj.gender == 2) {
            if (this.objBannerTop.member_background_img2 && this.objBannerTop.member_background_img2.indexOf("/") >= 0)
                bgImg = ';background-size: 100% 100%;background-image: url("' + this.objBannerTop.member_background_img2 + '");';
        }

        let htmlDiv = "<div style='" + bgImg + padNewBorder + padHeight + "' id='id_node_div_cont_" +
            obj.id + "' class='node_cont' data-id='"+ obj.id +"' data-gender='" + obj.gender + "' title='" + obj.name + " - " + obj.id + ` | Hàng ${obj._row}, Cột: ${obj._col} ` + "'>" +
            "<div style='position: relative'> <div class='img_new_node_blink blink_me' id='blink_new_node_" + obj.id +  "' style='" + padShow + "'> </div> </div>"

        // if (!this.optRemoveImage)
        //     htmlDiv += " <img id='id_node_image_" + obj.id + "' src='" + imgLink + "' style='" + "'>  <br>  "
        //
        if (!this.optRemoveImage) {
            let bgImgUser = '; height: '+ imgHeight + 'px ;background-size: auto 100%;  background-repeat: no-repeat; background-position: center;;background-image: url("' + imgLink + '");';
            htmlDiv += "<div class='node_img' id='id_node_image_" + obj.id + "' src='" + imgLink + "' style=' " + bgImgUser + "'></div>"
        }

        let showDebug = ''
        if (!this.optShowDebugIdAndOrders)
            showDebug = " ; display: none ;"

        htmlDiv += strName
        htmlDiv += " <div class='debug_id_orders' style='" + showDebug + "'> (ID:" + obj.id + ")" + " orders=" + obj.orders + '</div>'

        let leftBtn = ''
        let rightBtn = ''

        // if(0)
        if(this.optEnableMoveBtn)
            // if(this.setPid == 'sn792546')
        {
            leftBtn = "<div id='id_node_move_left_" + obj.id + "' data-id='" + obj.id +
                "' title='(Tinh chỉnh) Dịch trái - Có thể ấn phím trái chuột' class='node_move_left_btn btn btn-neutral'>" +
                " < </div>";
            rightBtn = "<div id='id_node_move_right_" + obj.id + "' data-id='" + obj.id +
                "' title='(Tinh chỉnh) Dịch phải - Có thể ấn phím phải chuột' class='node_move_right_btn btn btn-neutral'>" +
                " > </div>";
        }

        let spanRowColInfo = `<div id='spanRowColInfo_${obj.id}' data-id="${obj.id}"
             title='' class='spanRowColInfo'>
             ${obj._row} - ${obj._col}
            </div>`;

        let btnEdit = "<div id='id_node_menu_" + obj.id + "' data-id='" + obj.id +
            "' title='Edit member' class='node_edit_btn context-menu-one" + this.optDisableMenuNode + " btn btn-neutral'>" +
            " &#9776; </div>";

        let isLinkNode = "<div class='is_node_link fa' data-id='" + obj.id +
            "' title='Is Link node (Node liên kết tới Cây khác: " + obj.link_remote + ")'>" +
            " &#xf0d7; </div>";

        let birthday = '';
        if(this.objBannerTop.show_node_birthday_one){
            birthday = obj.birthday;
        }
        let date_of_death = '';
        if(this.objBannerTop.show_node_date_of_death){
            date_of_death = obj.date_of_death;
        }

        // htmlDiv += " <div class='node_birthday_one' id='id_node_birthday_" + obj.id + "' style=''>" + birthday + "</div>" +
        //     " <div class='node_date_of_death' id='id_node_date_of_death_" + obj.id + "' style=''>" + date_of_death + "</div>" +
        //     " " + " <div style='position: absolute'> " + leftBtn + rightBtn + spanRowColInfo + btnEdit + isLinkNode+  " </div>" +
        //     " </div> ";

        htmlDiv += `
    <div class='node_birthday_one' id='id_node_birthday_${obj.id}' style=''>${birthday}</div>
    <div class='node_date_of_death' id='id_node_date_of_death_${obj.id}' style=''>${date_of_death}</div>
    <div style='position: absolute'>
        ${leftBtn}
        ${rightBtn}

        ${btnEdit}
        ${isLinkNode}
    </div>
    ${spanRowColInfo}
</div>`;

        newDiv1.innerHTML = htmlDiv

        obj._divCont = objContSvg

        objContSvg.appendChild(newDiv1);
        grid.appendChild(objContSvg);

        // var circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        // circle.setAttribute('cx', rectX + this.widthCell /2);
        // circle.setAttribute('cy', rectX + this.widthCell /2 - 10);
        // circle.setAttribute('r', 20);
        // circle.setAttribute('fill', 'blue');
        //
        // grid.appendChild(circle);

    }

    findGetAllChildsOfPid(pid) {
        let mmChild = []
        for (let any of this.dataPart) {
            if (any.parent_id === pid)
                mmChild.push(any)
        }
        return mmChild
    }

    //Tìm tất cả con cháu của obj và vợ chồng
    findGetAllChildsDeepOfObjAndMarried(obj) {
        let m1 = this.findGetAllChildsDeepOfObj(obj)
        let allMaried = this.findGetMariedOfObj(obj)
        if (allMaried)
            m1.push(...allMaried)
        return m1;
    }

    //Nếu con xa bố mẹ, bên trái trống từ trên xuống, thì move cả cây của con sát vào
    //Có thể ko cần hàm này nữa, vì đã có hàm optimize left right...
    neuConXaBoMeVaBenTraiTrongThiMoveConSangTrai() {
        let maxRow = this.getMaxRow()
        let maxCol = this.getMaxCol()

        //Duyệt từ trên xuống, từ trái qua phải
        for (let r1 = 0; r1 <= maxRow; r1++) {
            for (let c1 = 0; c1 <= maxCol; c1++) {
                let obj = this.getObjByColRow(c1, r1)
                if (obj) {
                    let pr = this.getObjFromId(obj.parent_id)

                    for (let k = 1; k < 10; k++)
                        if (pr && obj._col >= pr._col + k) {
                            //kiểm tra cột bên cạnh con xem có trống hết từ hàng con trở xuống ko
                            let colNow = obj._col - k
                            let foundColRow = 0
                            for (let r = obj._row; r <= maxRow; r++) {
                                if (this.getObjByColRow(colNow, r)) {
                                    foundColRow = 1
                                    break
                                }
                            }
                            //Nếu ko thấy, thì nghĩa là move sang trái được
                            //Di chuyển tất cả các con cháu của obj sang trái
                            if (!foundColRow) {
                                let mmChilds = this.findGetAllChildsDeepOfObj(obj)
                                if (mmChilds.length)
                                    for (let o1 of mmChilds)
                                        o1._col--
                                obj._col--
                            }
                        }
                }
            }
        }
        //Xóa các cột trống nếu có
        this.deleteEmptyCol()
    }

    //Có phải là đinh của dòng họ không:
    checkNodeIsMainMan(obj) {
        let tmp = obj
        if ((tmp.gender == 2 && !tmp.set_nu_dinh) || tmp.married_with)
            return false
        let cc = 0
        //Kiểm tra tất cả các parent phải là MAN, thì sẽ là đinh
        while (tmp && tmp.parent_id > 0) {
            cc++
            if (cc > 10000)
                return false
            if ((tmp.gender == 2 && !tmp.set_nu_dinh) || tmp.married_with)
                return false
            tmp = this.getObjFromId(tmp.parent_id)
        }
        return true;
    }

    getRootSvgBase() {
        return document.getElementById(this.idSvgSelector);
    }

    getRootSvgIfHavePanZoom() {
        let tmp = document.querySelector("#" + this.idSvgSelector + ' .svg-pan-zoom_viewport')
        if (tmp)
            return tmp
        return document.getElementById(this.idSvgSelector);
    }

    getMaxIdNode() {
        let max = 0
        for (let any of this.dataPart) {
            if (any.id > max)
                max = any.id
        }
        return max
    }

    createTreeSvg() {


        let [maxRow, maxCol] = clsTreeTopDownCtrl.getMaxColRow(this.dataPart)
        console.log("maxR,C = ", maxRow, maxCol);
        maxRow++ //Thêm 1 cho rộng
        maxCol++
        let grid = this.getRootSvgIfHavePanZoom()
        let startX = this.startX;
        let startY = this.startY + this.bannerHeight;

        console.log(" startX, startY: " , startX , startY);

        let rectWidth = this.widthCell
        let rectHeight = this.heightCell

        if (this.optRemoveImage)
            rectHeight = this.heightCell - 30

        let nrOfColumns = maxCol;
        let nrOfRows = maxRow;

        let horizontalPadding = this.spaceBetweenCellX;
        let verticalPadding = this.spaceBetweenCellY;

        let strokeWidth = 0;

        let rectX;
        let rectY;
        //for (let colIdx = 0; colIdx < nrOfColumns; colIdx++)
        {

            //for (let rowIdx = 0; rowIdx < nrOfRows; rowIdx++)
            {

                //Tạo rect nếu cần
                // let rect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
                // rect.setAttribute("x", rectX);
                // rect.setAttribute("y", rectY);
                // rect.setAttribute("width", rectWidth);
                // rect.setAttribute("height", rectHeight);
                // rect.setAttribute("style", "fill:none;stroke:gray;stroke-width:" +
                //     strokeWidth + ";fill-opacity:0.1;stroke-opacity:0.6");
                // // Rounded corners
                // rect.setAttribute("rx", "10");
                // mmRec[rowIdx + "x" + colIdx] = rect;

                let mmTree_nodes_xy
                if(this.objBannerTop.tree_nodes_xy)
                    mmTree_nodes_xy = JSON.parse(this.objBannerTop.tree_nodes_xy);

                let foundRec = 0
                let haveXyInDb = 0;
                console.log(" this.dataPart , mmTree_nodes_xy ", this.dataPart, mmTree_nodes_xy);
                for (let obj of this.dataPart)
                {
                    // console.log(" objx = ", obj);
                    // console.log(" obj = ", obj);
                    //if (obj._row == rowIdx && obj._col == colIdx)
                    {

                        haveXyInDb = 0;
                        if(mmTree_nodes_xy){
                            for(let n1 of mmTree_nodes_xy){
                                if(n1.id === obj.id){
                                    haveXyInDb = 1;

                                    if(n1.x && n1.y) {
                                        rectX = n1.x;
                                        rectY = n1.y;
                                        obj.__x = rectX
                                        obj.__y = rectY
                                        continue;
                                    }


                                    if(n1.nx === 0 ||n1.nx !== undefined )
                                        obj.nx = n1.nx;
                                    if(n1.ny === 0 ||n1.ny !== undefined )
                                        obj.ny = n1.ny;

                                    //if(this.objBannerTop.minX || this.objBannerTop.minY)

                                    if(n1.nx || n1.ny){
                                        rectX = n1.nx * this.widthCell / this.spaceXBetweenCellDevidedBy + this.objBannerTop.minX
                                        rectY = n1.ny * (this.heightCell + this.spaceBetweenCellY)+ this.objBannerTop.minY
                                    }
                                    else{
                                        let nx= clsTreeTopDownCtrl.getNxNyFromXY(this ,rectX - startX, 0);
                                        obj.nx = nx;
                                    }



                                    break;
                                }
                            }
                        }

                        //Dựa vào col row cũ phieen ban 1?
                        //Hoawcj node moi:
                        if(!haveXyInDb){
                            console.log(" Not have in db ? ");
                            //Kieu moi , v2?, sau khi add da co nx
                            if(obj.nx){
                                rectX = obj.nx * this.widthCell / this.spaceXBetweenCellDevidedBy + this.objBannerTop.minX
                                rectY = obj._row * (this.heightCell + this.spaceBetweenCellY) + startY

                            }else{
                                //Kieu cu , v1
                                rectX = obj._col * (this.widthCell + this.spaceBetweenCellX) + startX
                                rectY = obj._row * (this.heightCell + this.spaceBetweenCellY) + startY
                                //Tinh lai Nx Ny:
                                let nx = clsTreeTopDownCtrl.getNxNyFromXY(this ,rectX - startX, 0);
                                obj.nx = nx;
                            }

                        }

                        // console.log(` --- RECxy (${obj._col} * (this.widthCell + this.spaceBetweenCellX) + startX) ` ,obj.name,  obj._col,  rectX, rectY);

                        if(isNaN(rectX)){
                            console.log("*** db Error  rectX" + obj.id);
                        }
                        if(isNaN(rectY)){
                            console.log("*** db Error  rectY", obj.id);
                        }

                        this.createDrawOneNode(obj, rectX, rectY );

                    }
                }

                console.log("After asign xy, ", this.dataPart);
                // if(foundRec)
                //     grid.appendChild(rect);
                // else
                //     if(this.optShowDebugGrid)
                //         grid.appendChild(rect);
                // rectY += rectHeight + verticalPadding;
            }
            // rectX += rectWidth + horizontalPadding;
        }


        let svgWidth = startX + nrOfColumns * (horizontalPadding + rectWidth + strokeWidth);
        let svgHeight = startY + nrOfRows * (verticalPadding + rectHeight + strokeWidth) + this.optPadYToPrint; //Thêm 200 để in

        //Giữ lại size nguyên bản cho svgRoot, để sang zoom sẽ dùng đến
        this._sizeOrgX = svgWidth
        this._sizeOrgY = svgHeight
        // console.log("xxx Zoom... _sizeOrgX set new: ", this._sizeOrgX);
        // console.log("xxx Zoom... _sizeOrgY set new: ", this._sizeOrgY);

        let gridBase = this.getRootSvgBase()

        let rateZoom = 1
        // rateZoom = jctool.getLocalStorage('last_zoom_gp')

        //Nếu có ratezoom thì size svg thay đổi
        if (this._panZoomTiger) {
            console.log("Đã có _panZoom");
            rateZoom = this._panZoomTiger.getSizes().realZoom
            horizontalPadding *= rateZoom
            verticalPadding *= rateZoom
            rectWidth *= rateZoom
            rectHeight *= rateZoom
            // Resize the grid to fit its containing rectangles
            svgWidth = startX + nrOfColumns * (horizontalPadding + rectWidth + strokeWidth);
            svgHeight = startY + nrOfRows * (verticalPadding + rectHeight + strokeWidth);
        } else {
            console.log("Have no _panZoom");
        }

        if (svgWidth < 300)
            svgWidth = 300
        if (svgHeight < 400)
            svgHeight = 400

        if (this.optFitViewPortToWindow) {
            console.log("Resize:  optFitViewPortToWindow ...");
            clsTreeTopDownCtrl.resizeByWindow(this.idSvgSelector, this.optFitWindowId)
        } else {
            console.log("rateZoom zoom = ", rateZoom);
            console.log(" Resize grid ...", svgWidth, svgHeight, 'nrOfColumns=', nrOfColumns, nrOfRows, 'horizontalPadding=', horizontalPadding, "rectWidth=", rectWidth);
            gridBase.setAttribute("width", svgWidth);
            gridBase.setAttribute("height", svgHeight);
        }


        //Và resize lại panzoom vừa với svgRoot
        if (this._panZoomTiger) {
            console.log(" Resize zoom");
            this._panZoomTiger.resize(); // update SVG cached size and controls positions
        }


    }

    //Tìm các cây link, để đổi kiểu đường nối:
    highlightLineToLinkRemote(objP){
        if(objP && objP.link_remote){
            // console.log("Show link remote " + objP.id);
            //Tìm các cây link, để đổi kiểu đường nối:
            let mIdLink = objP.link_remote.split(",")
            for (let idLink of mIdLink){
                let tmp1 = document.getElementById('line_to_parent_' + idLink)
                if(tmp1){
                    // tmp1.setAttribute('stroke-dasharray','4');
                    tmp1.setAttribute('stroke-width','6');
                }
            }
        }
    }

    toggleLineToChildWhenHoverParent(dataId, inOrOut = 0){
        // console.log(" toggleLineToChildWhenHoverParent ", dataId);
        let objP = this.getObjFromId(dataId)
        if(!objP)
            return;

        if(objP.married_with)
            objP = this.getObjFromId(objP.married_with)

        if(!objP)
            return;;

        //Đường đến cha
        if(objP.parent_id) {
            let anyHtml = document.getElementById('line_to_parent_' + objP.id)
            if(anyHtml){
                // console.log(" Set stroke: " + any.id);
                if(inOrOut){
                    anyHtml.setAttribute('stroke','red');
                    anyHtml.setAttribute('stroke-width','3');

                }
                else{
                    anyHtml.setAttribute('stroke',this.optColorLineParent);
                    anyHtml.setAttribute('stroke-width','1');
                }
            }
        }

        this.highlightLineToLinkRemote(objP)


        let mAll = this.findGetAllChildsDeepOfObjAndMarried(objP)

        // mAll.push(objP)

        if(mAll)
            for (let any of mAll){
                let anyHtml = document.getElementById('line_to_parent_' + any.id)
                if(anyHtml){
                    // console.log(" Set stroke: " + any.id);
                    if(inOrOut){
                        // console.log("In... " + any.id);
                        if(any.belong_other)
                            anyHtml.setAttribute('stroke','red');
                        else
                            anyHtml.setAttribute('stroke','blue');

                        if(any.belong_link) {
                            anyHtml.setAttribute('stroke', 'green');
                        }
                        anyHtml.setAttribute('stroke-width','3');

                        // anyHtml.setAttribute('stroke-width','2');

                        // let pr = this.getObjFromId(any.parent_id)
                        if(any.link_remote){
                            // console.log("Show link remote " + any.id);
                            // anyHtml.setAttribute('stroke-dasharray','4');
                            // anyHtml.setAttribute('stroke-width','6');

                            //Hiển thị nút đỏ đánh dấu link
                            $(".is_node_link[data-id="+ any.id +"]").show()

                            this.highlightLineToLinkRemote(any)

                        }
                    }
                    else{
                        // console.log("Out... " + any.id);
                        anyHtml.setAttribute('stroke',this.optColorLineParent);
                        anyHtml.setAttribute('stroke-width','1');

                        // anyHtml.setAttribute('stroke-dasharray', 'none');

                        if(any.link_remote) {
                            console.log("hide link remote " + any.id);
                            $(".is_node_link").hide()
                        }
                    }
                }
            }
    }
    setZoomAble() {

        if (!this.zoomAble)
            return

        //For mobile
        let eventsHandler;
        eventsHandler = {
            haltEventListeners: ['touchstart', 'touchend', 'touchmove', 'touchleave', 'touchcancel']
            , init: function (options) {
                var instance = options.instance
                    , initialScale = 1
                    , pannedX = 0
                    , pannedY = 0

                // Init Hammer
                // Listen only for pointer and touch events
                this.hammer = Hammer(options.svgElement, {
                    inputClass: Hammer.SUPPORT_POINTER_EVENTS ? Hammer.PointerEventInput : Hammer.TouchInput
                })

                // Enable pinch
                this.hammer.get('pinch').set({enable: true})

                // Handle double tap
                this.hammer.on('doubletap', function (ev) {
                    instance.zoomIn()
                })

                // Handle pan
                this.hammer.on('panstart panmove', function (ev) {
                    // On pan start reset panned variables
                    if (ev.type === 'panstart') {
                        pannedX = 0
                        pannedY = 0
                    }

                    // Pan only the difference
                    instance.panBy({x: ev.deltaX - pannedX, y: ev.deltaY - pannedY})
                    pannedX = ev.deltaX
                    pannedY = ev.deltaY
                })

                // Handle pinch
                this.hammer.on('pinchstart pinchmove', function (ev) {
                    // On pinch start remember initial zoom
                    if (ev.type === 'pinchstart') {
                        initialScale = instance.getZoom()
                        instance.zoomAtPoint(initialScale * ev.scale, {x: ev.center.x, y: ev.center.y})
                    }

                    instance.zoomAtPoint(initialScale * ev.scale, {x: ev.center.x, y: ev.center.y})
                })

                // Prevent moving the page on some devices when panning over SVG
                options.svgElement.addEventListener('touchmove', function (e) {
                    e.preventDefault();
                });
            }
            , destroy: function () {
                this.hammer.destroy()
            }
        }

        let beforePan = function (oldPan, newPan) {
            var stopHorizontal = false
                , stopVertical = false
                , gutterWidth = 100
                , gutterHeight = 100
                // Computed variables
                , sizes = this.getSizes()
                , leftLimit = -((sizes.viewBox.x + sizes.viewBox.width) * sizes.realZoom) + gutterWidth
                , rightLimit = sizes.width - gutterWidth - (sizes.viewBox.x * sizes.realZoom)
                , topLimit = -((sizes.viewBox.y + sizes.viewBox.height) * sizes.realZoom) + gutterHeight
                , bottomLimit = sizes.height - gutterHeight - (sizes.viewBox.y * sizes.realZoom)

            let customPan = {}
            customPan.x = Math.max(leftLimit, Math.min(rightLimit, newPan.x))
            customPan.y = Math.max(topLimit, Math.min(bottomLimit, newPan.y))

            return customPan
        }

        let that = this
        this._panZoomTiger = svgPanZoom("#" + this.idSvgSelector, {
            // zoomEnabled: true,
            // controlIconsEnabled: true,
            fit: false,
            center: true,
            beforePan: beforePan,
            minZoom: this.minZoom,
            maxZoom: this.maxZoom,
            customEventsHandler: eventsHandler,
            onPan: function () {
                console.log("Pan.....");
            },
            onZoom: function () {

                let gridRoot = that.getRootSvgBase()
                //Resize SVG to zoom view port
                //để đẹp fit đẹp hơn và download đúng view đó
                let zoomInfo = that._panZoomTiger.getSizes()
                //Trong mọi trường hợp, Khi zoom thay đổi, thì svgRoot sẽ resize theo tỷ lệ zoom, từ size gốc Base

                console.log(" ... zoom ..." , zoomInfo.realZoom);

                jctool.setLocalStorage('last_zoom_gp', zoomInfo.realZoom)

                if (!that.optFitViewPortToWindow) {
                    let newW = that._sizeOrgX * zoomInfo.realZoom
                    let newH = that._sizeOrgY * zoomInfo.realZoom
                    if (newW < 300)
                        newW = 300
                    if (newH < 400)
                        newH = 400
                    gridRoot.setAttribute("width", newW);
                    gridRoot.setAttribute("height", newH);
                }


                //Cần thiết khi zoom
                changeValueBanner('banner_name_curver', that.objBannerTop.banner_name_curver);
                changeValueBanner('banner_title_curver', that.objBannerTop.banner_title_curver);


                // newW = window.innerWidth - 10
                // newH = window.innerHeight - 80
                // clsTreeTopDownCtrl.resizeByWindow(that.idSvgSelector)
            }
        });

    }

    getRectOfObj(node) {
        if (!node)
            return null
        if (node._divCont)
            return node._divCont
        return null
    }

    drawLineToParent(obj) {

        if (!obj.parent_id)
            return
        //Con dâu rể ko nối đến cha
        if (obj.child_type || obj.married_with)
            return

        // console.log(" OBJx = ", obj, data);

        //Xoa like cu: line_to_parent_rk740350
        let elm = document.getElementById("line_to_parent_" + obj.id)
        if(elm)
            elm.parentNode.removeChild(elm);

        let pObj = this.getObjFromId(obj.parent_id)

        let recChild = this.getRectOfObj(obj)
        let recParent = this.getRectOfObj(pObj)

        if (!recChild) {
            console.log(" *** Error Not found child : ", obj.id, obj.name, obj);
            return null
        }

        if (!recParent) {
            console.log(" *** Error Not found parent: ", obj.id, obj.name, obj);
            return null
        }

        let xChild = parseFloat(recChild.getAttribute('x'));
        let yChild = parseFloat(recChild.getAttribute('y'));
        let wChild = parseFloat(recChild.getAttribute('width'));
        let hChild = parseFloat(recChild.getAttribute('height'));

        let xPar = parseFloat(recParent.getAttribute('x'));
        let yPar = parseFloat(recParent.getAttribute('y'));
        let wPar = parseFloat(recParent.getAttribute('width'));
        let hPar = parseFloat(recParent.getAttribute('height'));

        let grid = this.getRootSvgIfHavePanZoom()

        let px, py
        let polyLine = document.createElementNS('http://www.w3.org/2000/svg', 'polyline');
        polyLine.setAttribute("id", 'line_to_parent_' + obj.id)
        polyLine.setAttribute("class", 'link_line')
        let strLine = ''

        //Nếu có VC, Thì con sẽ nối vào điểm giữa vc (và có option showMarried)
        if (!this.optShowOnlyMan && this.optShowMarried && this.findGetMariedOfObj(pObj)) {

            let mySecondMother = null
            let xMother
            let yMother
            let wMother
            let hMother
            let nthMarried = 1

            //Nếu là con của mẹ 2,3...
            if (obj.child_of_second_married && obj.child_of_second_married != obj.parent_id) {

                mySecondMother = this.getObjFromId(obj.child_of_second_married)

                //kiểm tra xem thứ tự của bố me có phải vợ cả ko
                //Nếu không phải vợ chồng cả, thì mới coi là vợ chồng 2:
                if (this.isFirstMarriedObObj(pObj, mySecondMother)) {
                    // console.log("xxx1:  vợ chồng cả ", obj, pObj, mySecondMother);
                    // console.log("xxx1: các vợ ", this.findGetMariedOfObj(pObj));
                    mySecondMother = null
                }

                if (mySecondMother) {

                    //Vợ/C thứ mấy của obj
                    nthMarried = mySecondMother._col - pObj._col

                    let recMother = this.getRectOfObj(mySecondMother)
                    xMother = parseFloat(recMother.getAttribute('x'));
                    yMother = parseFloat(recMother.getAttribute('y'));
                    wMother = parseFloat(recMother.getAttribute('width'));
                    hMother = parseFloat(recMother.getAttribute('height'));

                    // mySecondMother.name = " abc "
                    // obj.name = '111';
                    // $('#id_node_name_' + mySecondMother.id).text(mySecondMother.name + " / " + nthMarried)
                }
            }

            //Giữa trên của con
            px = xChild + wChild / 2
            py = yChild
            strLine += px + "," + py

            //Dịch lên trên
            px = xChild + wChild / 2
            py = yChild - this.spaceBetweenCellY / 2
            if (mySecondMother)
                py = py + 4 * nthMarried

            strLine += " " + px + "," + py

            //Dịch sang điểm nối bố mẹ
            if (mySecondMother) {
                polyLine.setAttribute("stroke", this.optColorLineParent)
                polyLine.setAttribute("stroke-dasharray", "5,5")
                px = xMother - this.spaceBetweenCellX / 2
                py = yChild - this.spaceBetweenCellY / 2 + 4 * nthMarried
            } else {

                polyLine.setAttribute("stroke", this.optColorLineParent)
                px = xPar + wPar + this.spaceBetweenCellX / 2
                py = yChild - this.spaceBetweenCellY / 2
            }


            strLine += " " + px + "," + py

            //Dịch lên trên
            //px = xPar + wPar/2
            py = yPar + hPar / 2
            strLine += " " + px + "," + py

            // console.log(" drawLineMarried: StrLine = ", strLine);

            polyLine.setAttribute('points', strLine);

            polyLine.setAttribute("stroke-width", 1)
            polyLine.setAttribute("fill", "none")
            grid.insertBefore(polyLine, grid.firstChild)

        } else {

            //Nếu không có VC thì  nối vào đáy của cha
            px = xChild + wChild / 2
            py = yChild
            strLine += px + "," + py

            px = xChild + wChild / 2
            py = yChild - this.spaceBetweenCellY / 2
            strLine += " " + px + "," + py

            px = xPar + wPar / 2
            py = yChild - this.spaceBetweenCellY / 2
            strLine += " " + px + "," + py

            px = xPar + wPar / 2
            py = yPar + hPar
            strLine += " " + px + "," + py

            // console.log(" drawLineMarried: StrLine = ", strLine);

            polyLine.setAttribute('points', strLine);
            polyLine.setAttribute("stroke", this.optColorLineParent)
            polyLine.setAttribute("stroke-width", 1)
            polyLine.setAttribute("fill", "none")
            grid.insertBefore(polyLine, grid.firstChild)
        }
    }

    drawLineMarried(obj) {

        if (this.optShowOnlyMan)
            return
        if (!this.optShowMarried)
            return

        //Xoa like cu: line_to_married_
        let elm = document.getElementById("line_to_married_" + obj.id)
        if(elm)
            elm.parentNode.removeChild(elm);

        // console.log(" drawLineMarried ...");

        let mMarried = this.findGetMariedOfObj(obj)
        if (!mMarried)
            return null
        let grid = this.getRootSvgIfHavePanZoom()

        mMarried.push(obj);

        let that = this;

        var offsetY = this.getRootSvgBase().getBoundingClientRect().y

        //Xác định xem VC nào đứng đầu trên giao diện, để biết đó là vc cả/2
        //Sắp xếp lại vị trí, gần nhất bên trái là cả
        let mRec = []
        mMarried.forEach(function(one){
            let recMarried = document.getElementById('svg_cont_node_' + one.id);
            mRec.push(recMarried);

        });

        mRec.sort(function(a, b) {
            return a.getAttribute('x') - b.getAttribute('x');
        });




        for (var i = 0; i < mRec.length - 1; i++) {

            let yLine = parseInt(mRec[i].getAttribute('y')) + parseInt(mRec[i].getAttribute('height'))/2 ;

            var line = document.createElementNS('http://www.w3.org/2000/svg', 'polyline');
            line.setAttribute("id", 'line_to_married_' + obj.id)
            let strLine = (parseInt(mRec[i].getAttribute('x')) + parseInt(mRec[i].getAttribute('width'))) + "," + yLine + ',' + mRec[i+1].getAttribute('x') + ',' + yLine;
            line.setAttribute('points', strLine);
            line.setAttribute("stroke", this.optColorLineMarried)
            line.setAttribute("stroke-width", 2)
            // console.log("db1 add line ", i);
            grid.appendChild(line);
        }


    }


    drawLineMarried_olc(obj) {


        if (this.optShowOnlyMan)
            return
        if (!this.optShowMarried) {
            return
        }

        let mMarried = this.findGetMariedOfObj(obj)
        if (!mMarried)
            return null

        //Xác định xem VC nào đứng đầu trên giao diện, để biết đó là vc cả/2
        //Sắp xếp lại vị trí, gần nhất bên trái là cả
        mMarried.forEach(function(one){
            let obj1 = document.getElementById('svg_cont_node_' + one.id);
            let x = parseInt(obj1.getAttribute('x'));
            one.xOnUi = x;
        });

        mMarried.sort(function(a, b) {
            return a.xOnUi - b.xOnUi;
        });

        console.log("db1 obj  " , obj , mMarried);
        // console.log(" obj/married = ", obj, mMarried);

        let recMarried = document.getElementById('svg_cont_node_' + mMarried[0].id);
        let xMar = parseFloat(recMarried.getAttribute('x'));
        let yMar = parseFloat(recMarried.getAttribute('y'));
        let wMar = parseFloat(recMarried.getAttribute('width'));
        let hMar = parseFloat(recMarried.getAttribute('height'));


        let recObj
        recObj = document.getElementById('svg_cont_node_' + obj.id)
        if (!recObj) {

            return null
        }

        let x1 = parseFloat(recObj.getAttribute('x'));
        let y1 = parseFloat(recObj.getAttribute('y'));
        let w1 = parseFloat(recObj.getAttribute('width'));
        let h1 = parseFloat(recObj.getAttribute('height'));

        //Nếu VC nằm bên trái:
        if(x1 > xMar){

        }

        console.log("db1 x1, y1, w1, h1" , x1, y1, w1, h1);

        let lenToMar = xMar - (x1 + w1);
        console.log("db1 len with mar" , lenToMar );


        let grid = this.getRootSvgIfHavePanZoom()

        let px, py
        let polyLine = document.createElementNS('http://www.w3.org/2000/svg', 'polyline');
        polyLine.setAttribute("id", 'line_to_married_' + obj.id)
        polyLine.setAttribute("class", 'link_line')
        let strLine = ''

        let deltaCol = mMarried[0]._col - obj._col;

        px = x1 + w1
        if(x1 > xMar){
            px = x1
        }
        py = y1 + h1 / 2
        strLine += px + "," + py

        px = x1 + w1 + lenToMar
        if(x1 > xMar){
            px = xMar + this.widthCell
            // px = x1 + w1 + lenToMar
        }

        py = y1 + h1 / 2
        strLine += " " + px + "," + py

        // console.log(" drawLineMarried: StrLine = ", strLine);

        polyLine.setAttribute('points', strLine);
        polyLine.setAttribute("stroke", this.optColorLineMarried)
        polyLine.setAttribute("stroke-width", 1)
        polyLine.setAttribute("fill", "none")
        grid.insertBefore(polyLine, grid.firstChild)

        //////////////////////////////////////////////////////////////////////////////
        //Từ vợ chồng thứ 2 trở đi, vẽ kiểu đi vòng lên trên
        let cc1 = 0;
        if (mMarried.length > 1) {
            for (let mr of mMarried) {
                // if (cc1 > mMarried.length - 2)
                //     break
                if (mr.id == mMarried[0].id)
                     continue;

                recMarried = document.getElementById('svg_cont_node_' + mr.id);
                xMar = parseFloat(recMarried.getAttribute('x'));
                yMar = parseFloat(recMarried.getAttribute('y'));
                wMar = parseFloat(recMarried.getAttribute('width'));
                hMar = parseFloat(recMarried.getAttribute('height'));

                console.log("db1 xMar , x " , xMar, x1)
                let lenToMar = xMar - (x1 + w1)
                console.log("db1 lenma " , lenToMar)

                let cc = mr._col - obj._col;
                // console.log("CCx = " , cc , mr._col , obj._col);
                //cc = cc1;

                polyLine = document.createElementNS('http://www.w3.org/2000/svg', 'polyline');
                polyLine.setAttribute("id", 'line_to_married_' + obj.id)
                polyLine.setAttribute("class", 'link_line')


                let strLine = ''
                //Điểm đầu
                px = x1 + w1
                if(x1 > xMar){

                }

                py = y1 + h1 / 2
                strLine += px + "," + py

                //sang phải 1 tí
                px = x1 + w1 + this.spaceBetweenCellX / 2
                py = y1 + h1 / 2
                strLine += " " + px + "," + py

                //Lên trên, điểm ở trên cao
                px = x1 + w1 + this.spaceBetweenCellX / 2
                py = y1 - 10
                strLine += " " + px + "," + py

                //Đoạn nối bên trên dài
                //px = x1 + 2 * w1 + cc * w1 + this.spaceBetweenCellX * 1.5 + cc * this.spaceBetweenCellX
                px = x1 + cc * (this.spaceBetweenCellX + w1) - this.spaceBetweenCellX / 2
                px = x1 + w1 + lenToMar - this.spaceBetweenCellX / 2

                py = y1 - 10
                strLine += " " + px + "," + py

                //Xuống dưới
                py = yMar + hMar / 2
                strLine += " " + px + "," + py

                //px = x1 + 2 * w1 + cc * w1 + this.spaceBetweenCellX * 2 + cc * this.spaceBetweenCellX
                px += this.spaceBetweenCellX / 2
                if(x1 > xMar){
                    // px = xMar + this.widthCell
                }
                // py = y1 + h1 / 2
                strLine += " " + px + "," + py

                // console.log(" drawLineMarried: StrLine = ", strLine);

                polyLine.setAttribute('points', strLine);
                polyLine.setAttribute("stroke", this.optColorLineMarried)
                // polyLine.setAttribute("stroke", 'brown')

                polyLine.setAttribute("stroke-width", 1)
                // polyLine.setAttribute("stroke-dasharray", '2 4')
                polyLine.setAttribute("fill", "none")
                grid.insertBefore(polyLine, grid.firstChild)

                cc1++;
            }

        }

    }

    zoomIn(n) {
        this._panZoomTiger.zoomIn(n)
    }

    updateBBox() {
        this._panZoomTiger.updateBBox()
    }

    fit() {
        this._panZoomTiger.fit()
    }

    resize() {
        this._panZoomTiger.resize()
    }

    center() {
        this._panZoomTiger.center()
    }

    moveUpTrungLapDuongNoiParent() {
        // let svg = clsTreeTopDownCtrl.allInstance[0];
        let svg = this;
        let mPos = [];


        setTimeout(function () {
            for (let i = 0; i < 3; i++) {

                console.log("moveUpTrungLap...");

                $(document).find("[id^=line_to_parent_]").each(function () {

                    let idNode = this.id.replace('line_to_parent_', '');
                    // console.log(" ID = ", this.id, idNode, " - ", this.getAttribute('points'));

                    if (!idNode)
                        return;

                    let node = {...svg.getObjFromId(idNode)};
                    if (!node)
                        return;

                    let strPoint = this.getAttribute('points');
                    if (strPoint) {
                        let m1 = strPoint.split(" ");
                        // console.log(" M1 = ", m1);
                        if (m1[1] && m1[2]) {

                            let x1 = m1[1].split(',')[0];
                            let y1 = m1[1].split(',')[1];
                            let x2 = m1[2].split(',')[0];
                            let y2 = m1[2].split(',')[1];

                            node.x1 = parseInt(x1);
                            node.x2 = parseInt(x2);
                            node.y1 = parseInt(y1);
                            node.y2 = parseInt(y2);
                            // console.log("X1, X2 = ", x1, x2);
                            mPos.push(node)
                        }
                    }
                })
                // console.log(" mPos ", mPos);

                let maxRow = svg.getMaxRowInData(mPos);
                // console.log("Max Row = ", maxRow);
                // for(let r = 0;r <= 2; r++)
                for (let obj of mPos) {


                    // if (obj.name == 'c32')
                    //     console.log(" Xem xet C32 ");
                    for (let obj1 of mPos) {
                        if (obj1._row != obj._row)
                            continue
                        // console.log(" --- Xem xet0 ", obj1);
                        // if(obj1._row == r && obj1.id!= obj.id)
                        if (obj1.id != obj.id && obj1.parent_id != obj.parent_id && obj1._col > obj._col) {
                            // if (obj.name == 'c32')
                            //     console.log(" --- Xem xet ", obj1);
                            //Xem x có bị chèn nhau không:
                            if (obj1.y1 == obj.y1) {
                                // console.log(" Y bằng nhau ");
                                if (
                                    (obj1.x1 > obj.x1 && obj1.x2 > obj.x2 && obj1.x1 > obj.x2 && obj1.x2 > obj.x1)
                                    ||
                                    (obj1.x1 < obj.x1 && obj1.x2 < obj.x2 && obj1.x1 < obj.x2 && obj1.x2 < obj.x1)
                                ) {
                                } else {
                                    let objMoveUp
                                    if (obj1.x1 > obj.x1 && obj1.x1 > obj.x2) {
                                        //obj1 sẽ move lên
                                        objMoveUp = obj1
                                    }
                                    if (obj.x1 > obj1.x1 && obj.x1 > obj1.x2) {
                                        //obj1 sẽ move lên
                                        objMoveUp = obj
                                    }

                                    // console.log("*** Đã thấy trùng: ", obj1.name, obj.name);
                                    // console.log("*** Obj Move Up = ", objMoveUp.name);


                                    let oldPoint = $(document).find("#line_to_parent_" + objMoveUp.id).attr('points');

                                    let newPoint = oldPoint.replaceAll("," + obj1.y1 + ' ', "," + (obj1.y1 - 6) + ' ')

                                    // console.log("Old Point/ newPoint = ", oldPoint, newPoint);

                                    $(document).find("#line_to_parent_" + objMoveUp.id).attr('points', newPoint);
                                    // return;
                                }
                            }

                        }
                    }

                }
            }
        }, 500);

        //Kiểm tra trùng lặp các x:
    }

    static center_fit(idSvg) {
        let svg = clsTreeTopDownCtrl.getInstanceSvgById(idSvg)
        // svg._panZoomTiger.fit()
        svg._panZoomTiger.center()
        svg._panZoomTiger.fit()
    }


    static zoomIn(idSvg) {
        let svg = clsTreeTopDownCtrl.getInstanceSvgById(idSvg)
        // svg._panZoomTiger.fit()
        svg._panZoomTiger.zoomIn()
    }

    static updateBBox(idSvg) {
        let svg = clsTreeTopDownCtrl.getInstanceSvgById(idSvg)
        svg._panZoomTiger.updateBBox()
    }

    static fit(idSvg) {
        let svg = clsTreeTopDownCtrl.getInstanceSvgById(idSvg)
        svg._panZoomTiger.fit()
    }

    static resize(idSvg) {
        let svg = clsTreeTopDownCtrl.getInstanceSvgById(idSvg)
        svg._panZoomTiger.resize()
    }

    static center(idSvg) {
        let svg = clsTreeTopDownCtrl.getInstanceSvgById(idSvg)
        // svg._panZoomTiger.fit()
        svg._panZoomTiger.center()
    }

    //có thể dùng cho Download, khi click download, hàm này sẽ tự resize để fit content download
    //Vì mặc định chuyển sang chế độ Fix GridSize gần = window size
    resizeViewPortFitSvg() {
        let newW
        let newH

        //Resize SVG to zoom view port
        //để đẹp fit đẹp hơn và download đúng view đó
        let zoomInfo = this._panZoomTiger.getSizes()
        //Trong mọi trường hợp, Khi zoom thay đổi, thì svgRoot sẽ resize theo tỷ lệ zoom, từ size gốc Base
        newW = this._sizeOrgX * zoomInfo.realZoom
        newH = this._sizeOrgY * zoomInfo.realZoom


        if (newW < 300)
            newW = 300
        if (newH < 400)
            newH = 400

        let gridRoot = this.getRootSvgBase()
        gridRoot.setAttribute("width", newW);
        gridRoot.setAttribute("height", newH);
    }

    /**
     * Khi tải ảnh xuống, cần tải đúng kích thước đang chọn, nếu zoom<1 thì zoom về 1 để không bị quá  nhỏ
     * và ảnh phải về center căn giữa svg, không bị mất phần nào
     * @param idSvg
     * @param name
     */
    static downloadImagePng(idSvg, name = '') {

        jQuery('.loader1').show();

        showToastInfoBottom("Chú ý: nếu muốn in ảnh lớn, bạn hãy Phóng to trước khi ấn Tải xuống, phóng to đến đâu thì Bản tải xuống sẽ lớn đến mức đó!", '(Thông báo này tắt sau 15 giây)', 15000)

        let svg = clsTreeTopDownCtrl.getInstanceSvgById(idSvg)



        //Nếu zoom quá bé, thì reset về default 1?
        if (svg._panZoomTiger.getSizes().realZoom < 1)
            svg._panZoomTiger.zoom(1)

        svg.resizeViewPortFitSvg();

        let imgName = svg.getTopNodeRow0().name;


        //Đúng thứ tự này ok: user đang ở zoom hiện tại, updateBBox, resize, center : sẽ tải ảnh ok ở zoom hiện tại
        svg._panZoomTiger.updateBBox()
        svg._panZoomTiger.resize()
        svg._panZoomTiger.center()


        // return;
        setTimeout(function () {
            console.log("Start img download2");

            // saveSvgAsPng(document.getElementById("svg_grid"), "family-tree.png");
            // return;

            // domtoimage.toJpeg(document.getElementById(idSvg), {quality: 1, bgcolor: 'white'})
            //     //domtoimage.toJpeg(document.getElementsByClassName('svg-pan-zoom_viewport')[0], {quality: 1, bgcolor: 'white'})
            //     .then(function (dataUrl) {
            //         var link = document.createElement('a');
            //         link.download = imgName + '.jpg';
            //         link.href = dataUrl;
            //         link.click();
            //         jQuery('.loader1').hide();
            //         console.log("Done img");
            //     });
            // var scale = 2;
            // let domNode = document.getElementById('svg_grid')
            // domtoimage.toBlob(domNode, {
            //
            // }
            // ).then(function (blob) {
            //
            //         console.log(" lenx img: ", blob.size);
            //
            //         window.saveAs(blob, imgName + '.jpg');
            //
            //         jQuery('.loader1').hide();
            //     });

// Get the bounding box of the SVG content
            let svgElement = document.getElementById('svg_grid');
            let bbox = svgElement.getBBox();

// Adjust the viewBox and dimensions of the SVG element
            svgElement.setAttribute('viewBox', `${bbox.x} ${bbox.y} ${bbox.width} ${bbox.height}`);
            svgElement.setAttribute('width', bbox.width);
            svgElement.setAttribute('height', bbox.height);

// Convert the SVG to an image and download it
            domtoimage.toBlob(svgElement, {
                width: bbox.width  + 200,
                height: bbox.height  + 200
            }).then(function (blob) {
                // console.log("Blob size:", blob.size);

                try{
                    window.saveAs(blob, imgName + '.jpg');

                }catch (e) {
                    jQuery('.loader1').hide();
                    alert("Có lỗi, kích thước phóng quá giới han? : " + e);
                }

                jQuery('.loader1').hide();
            });

        }, 500)

    }

    static showLoader(){
        jQuery('.loader1').show();
    }
    static hideLoader(){
        jQuery('.loader1').hide();
    }

    static downloadImageSvg(idSvg = 'svg_grid', name = 'saveSvg') {

        let svg = clsTreeTopDownCtrl.getInstanceSvgById(idSvg)
        //Nếu zoom quá bé, thì reset về default 1?
        // if (svg._panZoomTiger.getSizes().realZoom < 1)
        //     svg._panZoomTiger.zoom(1)
        //
        // //Đúng thứ tự này ok: user đang ở zoom hiện tại, updateBBox, resize, center : sẽ tải ảnh ok ở zoom hiện tại
        // svg._panZoomTiger.updateBBox()
        // svg._panZoomTiger.resize()
        // svg._panZoomTiger.center()

        setTimeout(function () {

            function filter(node) {
                return (node.tagName !== 'i');
            }

            var elm = document.getElementsByTagName("g")[0];
            elm = document.getElementById(idSvg);

            domtoimage.toSvg(elm, {filter: filter})
                .then(function (dataUrl) {
                    //                console.log(" Datax: " + dataUrl);
                    /* do something */
                    window.saveAs(dataUrl, name);
                });
        }, 500)
    }

    // getMaxColInRow(row) {
    //     let con = new clsTreeNode()
    //     let max = -10
    //     for (let con0 of this.dataPart) {
    //         con = con0
    //         if (con._row == row)
    //             if (max < con._col)
    //                 max = con._col
    //     }
    //     return max
    // }

    checkLoopAndSetZeroParent(){

        //Nếu gốc lại bị là con của 1 nhánh, thì phải set root = 0, để tránh treo chương trình
        let rootObj = this.getObjFromId(this.setPid)
        if(!rootObj)
            return;
        for(let any of this.dataPart){
            if(rootObj.id != any.id)
            if(rootObj.parent_id ==  any.id){
                rootObj.parent_id = 0;
            }
        }
    }

    clearResetAllSvgToReDraw() {

        this.checkLoopAndSetZeroParent()
        this.resetAllColRowToDefault()
        this.removeAllConnectLineParentAndMarried()
        this.removeAllObjectSvgDrawed()

    }

    resetAllColRowToDefault() {
        for (let tmp of this.dataPart){
            tmp._col = tmp._row = -1
            tmp.orders = parseInt(tmp.orders);
        }
    }


    getObjFromId(id) {

        if(!this.tmp_id_of_obj_list)
            this.tmp_id_of_obj_list = []
        if(this.tmp_id_of_obj_list[id])
            return this.tmp_id_of_obj_list[id];

        for (let any of this.dataPart) {
            if (any.id == id) {
                if(!this.tmp_id_of_obj_list[id])
                    this.tmp_id_of_obj_list[id] = any;
                return any
            }
        }
        return null;
    }

    checkObjIsChildOfOther(obj, other) {
        let tmp = obj
        for (let i = 0; i < 10000; i++) {
            if (tmp.parent_id == other.id)
                return true
            tmp = this.getObjFromId(tmp.parent_id, this.dataPart)
            if (!tmp || !tmp.parent_id)
                return false
        }
        return false
    }

    //Tìm col cho một obj xét mới
    //Xét 1 obj
    //Duyệt tất cả các phần tử bên dưới hàng hiện tại
    //Nếu các phần tử không phải là con/cháu của obj, thì obj không thể đứng cùng cột tử đó, mà phải sau cột đó
    //và nếu nó là con đầu tiên của cha  nó, thì nó phải có col = cha nó
    findColForNewObj(obj) {
        // return 0
        let any = new clsTreeNode()
        let maxColValid = 0
        for (let any of this.dataPart) {
            //Xem các node ở hàng dưới
            if (any._row > obj._row) {
                //Nếu thấy node nào đó ko phải con cháu, thì col cần tìm sẽ + thêm 1
                //nếu ko có con cháu thì đứng yên là ok ?
                //if(this.hasChild(obj)) //đứng yên thì sẽ bị trường hợp Cha move ra giữa các con, thì đè lên chú
                if (!this.checkObjIsChildOfOther(any, obj, this.dataPart)) {
                    if (any._col >= maxColValid)
                        maxColValid = any._col + 1
                }

            }
        }
        //Chiếu lên trên, nếu nó là con đầu của cha, nghĩa là trước nó ko có anh em nào
        //thì col của nó bằng cha
        if (this.getObjFromId(obj.parent_id))
            // if (obj.parent_id > 0)
        {
            let isFirstChild = 1
            for (let any of this.dataPart)
                if (any._row == obj._row &&
                    any.parent_id == obj.parent_id &&
                    any._col < obj._col)
                    isFirstChild = 0

            //Nếu nó là con đầu của cha nó
            if (isFirstChild) {
                let colOfParent = this.getObjFromId(obj.parent_id)._col
                if (colOfParent > maxColValid)
                    return colOfParent
            }
        }
        return maxColValid
    }

    /**
     * Vẽ debug vào các ô hàng cột của 1 table
     * @param obj
     */
    drawNodeDebug(obj) {
        let span = $("#span-debug-" + obj._row + '-' + obj._col)
        span.html(obj.name)
    }

    /**
     * Vẽ debug vào các ô hàng cột của 1 table
     * @param data
     */
    drawAllNodeDebug() {
        //    return
        //Xóa hết các node:
        for (let i = 0; i < 100; i++)
            for (let j = 0; j < 100; j++) {
                let span = $("#span-debug-" + i + '-' + j)
                span.html('')
            }

        let con = new clsTreeNode()
        for (let con0 of this.dataPart) {
            // console.log(" Draw...", con0);
            con = con0
            let span = $("#span-debug-" + con._row + '-' + con._col)
            span.html(con.name)
        }
    }

    //Cập nhật thông tin thay đổi node lên UI
    updateNodeUI(node) {
        console.log(" Update node: ", node);
        let id = node.id
        $("#id_node_name_" + id).text(node.name)
        let imgLink
        if (node._image_list && node._image_list.length && node._image_list[0].thumb && node._image_list[0].thumb.indexOf("/") > -1)
            imgLink = node._image_list[0].thumb
        //$("#id_node_image_" + id).src(imgLink)
        //$("#id_node_image_" + id).css('background-image', imgLink)
        $("#id_node_image_" + id).css('background-image', 'url(' + node._image_list + ')' )
        $("#id_node_birthday_" + id).text(node.birthday)
        $("#id_node_title_" + id).text(node.title)
    }

    updateSyncXyNodesToTreeAll(newSpaceIfhave = 0) {

        console.log(" updateSyncXyNodesToTreeAll ...");
        let nodeXy = [];
        var nodes = document.querySelectorAll('.svg_cont_node_cls');
        let minX = 1000000000000;             let minY = 1000000000000;
        nodes.forEach(function (one) {
            let x = one.getAttribute('x');
            let y = one.getAttribute('y');
            if(parseInt(x) < minX)
                minX = parseInt(x);
            if(parseInt(y) < minY)
                minY = parseInt(y);
        })
        //Lay old new spaceDeivde de tinh toan lai xy
        let oldSpaceXDevide = parseInt(this.objBannerTop.space_node_x);
        if(newSpaceIfhave)
        if(newSpaceIfhave > 10 || newSpaceIfhave < 1)
        {
            alert("Space không hợp lệ!")
            return;
        }
        let that = this
        let maxNy = -1000;
        nodes.forEach(function (one) {
            let x = one.getAttribute('x');
            let y = one.getAttribute('y');
            let nx = one.getAttribute('nx');
            let ny = one.getAttribute('ny');
            //Fix lai truong hop Add neu sai Nxy
            if(!nx || !ny){
                // setNXNyWhenMove(one, this, minX, minY)
            }
            let id = one.getAttribute('id').replace('svg_cont_node_', '');
            // console.log(" x y id ", x, y, id);
            nodeXy.push({id: id, x: x, y: y, nx:nx, ny:ny, spx: that.objBannerTop.space_node_x})
            if(parseInt(ny) > maxNy)
                maxNy = parseInt(ny);
        })


        //Tính toán lại new Nx
        if(newSpaceIfhave)
        if(oldSpaceXDevide != newSpaceIfhave){
            console.log(" newSpaceIfhave / oldSpaceXDevide", newSpaceIfhave, oldSpaceXDevide);

            let mmSortNx = [];
            //Tính lại từng  hàng
            for(let i = 0; i<= maxNy; i++){
                // let cc = 0;
                nodeXy.forEach(function(one){
                    //xét trên 1 hàng đó
                    if(one.ny == i){
                        if(!mmSortNx[i])
                            mmSortNx[i] = [];
                        mmSortNx[i].push(one);
                        // let soCellFreeTruocNx =  one.nx - (cc * oldSpaceXDevide);
                        // let nx2 = soCellFreeTruocNx + cc * newSpaceIfhave ;
                        // one.nx = nx2;
                        // cc++;
                    }
                })
                if(mmSortNx[i]){
                    mmSortNx[i].sort((a, b) => a.nx - b.nx);
                }
            }
            mmSortNx.forEach(function(oneM){
                let cc = 0;
                oneM.forEach(function(one){
                    let soCellFreeTruocNx = one.nx - (cc * oldSpaceXDevide);
                    let nx2 = soCellFreeTruocNx + cc * newSpaceIfhave ;

                    console.log(" soCellFreeTruocNx + cc * newSpaceIfhave = nx2 = ", nx2 , ' = ', soCellFreeTruocNx , ' + ', cc , " * " , newSpaceIfhave);
                    cc++;
                    let oldnx = one.nx
                    console.log("one ny/nx1/nx2 = ",one.ny, oldnx, nx2);
                    one.nx = nx2;
                })
            })
            console.log(" mmSortNx = ", mmSortNx);
        }

        if(!nodeXy || nodeXy.length == 0){
        }
        else
            this.updateSyncXyNodesToTree(nodeXy, minX, minY);
    }

    updateSyncXyNodesToTree(dataPost0, minX, minY){

        console.log(" updateSyncXyNodesToTree...." , dataPost0);
        // console.log(" updateSyncXyNodesToTree = ", this, 'data=' , dataPost);
        let dataPost = JSON.stringify(dataPost0);
        let tokenU = jctool.getCookie('_tglx863516839')
        let datax = {'tree_nodes_xy' : dataPost , minX: minX, minY: minY}
        let urlAct = "/api/member-my-tree-info/update/" + this.objBannerTop.id;
        $.ajax({
            url: urlAct,
            async: false,
            type: "POST",
            beforeSend: function (xhr) {
                xhr.setRequestHeader('Authorization', 'Bearer ' + tokenU);
            },
            data: datax,
            success: function (data, status) {
                jQuery('.loader1').hide();
                console.log("Data: ", data, " \nStatus: ", status);
            },
            error: function (jqXHR, exception) {
                jQuery('.loader1').hide();
                clsTreeTopDownCtrl.showError(jqXHR)
                console.log(" Error jqXHR....", jqXHR);
                console.log(" Error exception....", exception);
            },
        });
    }

    removeAllConnectLineParentAndMarried() {

        console.log(" Remove all line ....");
        $("#" + this.idSvgSelector).find("[id^=line_to_parent_]").remove()
        $("#" + this.idSvgSelector).find("[id^=line_to_married_]").remove()

        /*
        $("#svg_path_banner_name").remove();
        $("#svg_text_cont_banner_name").remove();
        $("#svg_text_path_banner_name").remove();
        $("#svg_text_banner_name").remove();

        $("#svg_path_banner_title").remove();
        $("#svg_text_cont_banner_title").remove();
        $("#svg_text_path_banner_title").remove();
        $("#svg_text_banner_title").remove();

         */
    }

    removeAllObjectSvgDrawed() {
        for (let any of this.dataPart)
            any._divCont = null
        $(".svg_cont_node_cls").remove()

        $("#svg_cont_node_banner_id").remove()
        $(".banner_tree_div").remove()
    }

    countColRowForObjData(obj, row) {

        // console.log(" start countColRowForObjData this.dataPart ", this.dataPart);
        if (this.optShowOnlyMan && obj.gender == 2 && !obj.set_nu_dinh)
            return;
        if (this.optShowOnlyMan && obj.married_with)
            return;

        // console.log("*** xxx2 --- OBJ = Level = " + row + " : ", obj);

        //Mặc định cột của obj sẽ là cột tiếp theo sau phần tử đang có
        //Nếu chưa có phần tử n ào trong hàng thì col =0
        let maxColThisRow = this.getMaxColInRow(row, this.dataPart)
        //Tăng col lên 1 vì cho vào cuối hàng
        if (maxColThisRow < 0)
            obj._col = 0;
        else
            obj._col = maxColThisRow + 1
        obj._row = row

        let goodCol = this.findColForNewObj(obj)
        if (goodCol > obj._col)
            obj._col = goodCol

        // let tmp1 = {... obj}
        //
        // console.log("xxx22, col/row = ", obj, obj.id, obj._col, obj._row);
        // console.log("xxx22, tmp1 = ", tmp1);


        this.drawNodeDebug(obj)

        //VC chỉ cần thêm chỗ này, nếu bỏ vc đi thì bỏ ở đây là xong
        //Khi đó trở thành cây 1 gốc (như là phả hệ chỉ trong dòng họ), hoặc cây tổ chức
        //Tìm vc để đặt bên cạnh
        let countNextMarried = 1
        //Nếu không show Man, thì cũng ko show married
        if (!this.optShowOnlyMan)
            if (this.optShowMarried)
                for (let any of this.dataPart) {
                    if (any.married_with == obj.id) {
                        any._col = obj._col + countNextMarried
                        any._row = row
                        countNextMarried++
                        this.drawNodeDebug(any)
                    }
                }

        row++
        let con = new clsTreeNode()
        for (let con of this.dataPart) {
            if (con.married_with) {
                continue
            }
            if (con.parent_id == obj.id) {

                // console.log("xxx21, col/row = ", con, con.id, con._col, con._row);
                this.countColRowForObjData(con, row)
            }
        }

        // console.log(" after countColRowForObjData this.dataPart ", this.dataPart);
    }

    static getMaxColRow(payload) {
        let nCol = [];
        let maxCol = 0
        let maxRow = 0
        for (let obj of payload) {
            if (obj._row > maxRow)
                maxRow = obj._row
            if (obj._col > maxCol)
                maxCol = obj._col
        }
        return [maxRow, maxCol]
    }

    findMyChilds(obj) {
        let mret = []
        for (let any of this.dataPart) {
            if (any.parent_id == obj.id)
                mret.push(any)
        }

        if (mret.length == 0)
            return null
        return mret
    }

    getTopNodeRow0() {

        // return this.dataPart[0] ?? null;

        let minY = 1000000;
        let idGet = 0;
        document.querySelectorAll(".svg_cont_node_cls").forEach(function (one) {
            if(minY > parseInt(one.getAttribute('y'))){
                minY = parseInt(one.getAttribute('y'))
                idGet = one.id.replace('svg_cont_node_', '');
                console.log("db One Id = ", idGet, minY);
            }
        });

        for (let any of this.dataPart) {
            if(any.id == idGet)
                return any;
        }

        return null;

        for (let any of this.dataPart) {
            if (any._row == 0) {
                if(any.married_with)
                    return this.getObjFromId(any.married_with)
                return any;
            }
        }
        return null;
    }

    getCenterObjRow0() {
        let maxC = this.getMaxColInRow(0);
        let minC = this.getMinColInRow(0);
        console.log(" Max, Min C = ", maxC, minC);
        if (maxC == minC)
            return this.getObjByColRow(maxC, 0);
        let centerCol = Math.floor(maxC - minC) / 2
        let obj = this.getObjByColRow(centerCol, 0)
        if (!obj)
            return this.getTopNodeRow0();
        return obj;
    }

    getTopNodeFirst() {
        let countTopNode
        let foundOne
        let minCol = -1
        let maxCol = -1
        for (let any of this.dataPart)
            if (any.id == this.setPid)
                return any;
        for (let any of this.dataPart)
            if (any.parent_id == 0)
                return any;
        return null
    }

    getAllIdRow0() {

        console.log("this.setPid ", this.setPid);

        let mm = [];
        let pidTop = null
        //Tìm ra objTop, ểìm tìm ra pid
        if(this.setPid) {
            for (let any of this.dataPart)
                if (any.id == this.setPid){
                    pidTop = any.parent_id;
                    break
                }
        }
        else
        for (let any of this.dataPart)
            if (any.parent_id == 0){
                pidTop = any.parent_id;
                break
            }

        console.log(" PIDTOP = ", pidTop);
        for (let any of this.dataPart){
            if (any.parent_id == pidTop){
                mm.push(any)
            }
        }

        return mm;

    }


    getLastObjInRow(r, data) {
        if (!data)
            data = this.dataPart
        let minCol = -1
        let ret = null
        for (let any of data) {
            if (any._row == r) {
                if (minCol < 0 || any._col > minCol) {
                    minCol = any._col
                    ret = any
                }
            }
        }

        return ret
    }

    getFirstObjInRow(r, data) {
        if (!data)
            data = this.dataPart
        let minCol = -1
        let ret = null
        for (let any of data) {
            if (any._row == r) {
                if (minCol < 0 || any._col < minCol) {
                    minCol = any._col
                    ret = any
                }
            }
        }

        return ret
    }

    getLastChildOfObj(obj) {
        let mmChild = this.findMyChilds(obj)
        if (!mmChild)
            return null
        return this.getLastObjInRow(mmChild[0]._row, mmChild)
    }

    getFirstChildOfObj(obj) {
        let mmChild = this.findMyChilds(obj)
        if (!mmChild)
            return null
        return this.getFirstObjInRow(mmChild[0]._row, mmChild)
    }

    getMaxCanMoveLeftOfTop() {
        let topNode = this.getFirstObjInRow(0)

        if(!topNode)
            return 0;

        let maxRow = this.getMaxRow()

        let firstChild = null
        let obj = topNode
        let maxMoveLeft = 0
        //Tối đa maxRow lần là xong
        for (let r = 0; r <= maxRow; r++) {
            firstChild = this.getFirstChildOfObj(obj)
            if (!firstChild)
                break
            maxMoveLeft += obj._col - firstChild._col
            console.log(" firstChild = ", firstChild, obj._col - firstChild._col, maxMoveLeft);
            obj = firstChild
        }

        // console.log("xxx topnode = ", topNode);

        // //Tìm các child đầu của node
        // let mmChild = this.findMyChilds(topNode)
        // console.log("xxx mChild = ", mmChild);
        // if(mmChild){
        //     let firstCh = this.getFirstObjInRow(mmChild[0]._row, mmChild)
        //     if(firstCh){
        //         maxMoveLeft = firstCh._col
        //         // //= topNode._col
        //     }
        // }
        // return maxMoveLeft
    }


    //Hàm này có thể cần xem lại để giống hàm left
    //ví dụ cây jv097556, chưa right đúng giữa vẫn bị lệch trái nhiều
    moveGrandParentToCenterRight() {

        if (!this.optEnableGrandParentToCenter)
            return
        // return;
        //Kiểm tra xem top node có cân đối khoảng giữa tree
        //Ví dụ nếu lệch PHẢI quá thì chỉnh sang phía Phải
        //Bằng cách chỉnh dần các hàng phía dưới sang Phải, xem khả năng tối đa sang Phải được bao nhiêu
        //Rồi chỉnh dần từng hàng, tất nhiên là không nên sang tối đa
        let topNode = this.getFirstObjInRow(0)
        if(!topNode)
            return;
        let maxColHalfOfAll = Math.floor(this.getMaxCol() / 2)
        let maxRow = this.getMaxRow()

        //Nếu topnode lệch phải nhiều, thì chỉnh nó sang trái
        if (topNode._col < maxColHalfOfAll - 0) {
            let maxNeedMove = -1 * (topNode._col - maxColHalfOfAll)
            let lastChild = null
            let obj = topNode
            let maxCanMoveRight = 0
            //Tối đa maxRow lần là xong
            let mRowCanMoveRightMax = []
            let mObjNeedMove = [topNode]
            for (let r = 0; r <= maxRow; r++) {

                lastChild = this.getLastChildOfObj(obj)
                if (!lastChild)
                    break
                mObjNeedMove.push(lastChild)
                let canMoveRight = -1 * (obj._col - lastChild._col)
                mRowCanMoveRightMax[r] = canMoveRight
                maxCanMoveRight += canMoveRight
                console.log(" firstChild = ", lastChild, obj._col - lastChild._col);
                obj = lastChild
            }

            console.log("mRowCanMoveMax0 = ", mRowCanMoveRightMax, maxCanMoveRight, maxNeedMove, mObjNeedMove);

            let mRowMoveRightReal = []
            //Nếu có thể move thoải mái, thì TopNode có thể move max
            if (maxCanMoveRight >= maxNeedMove)
                //this.moveObjAndMarried(mRowMoveRightReal[0], maxNeedMove)
                mRowMoveRightReal[0] = maxNeedMove
            else
                //this.moveObjAndMarried(mRowMoveRightReal[0], mRowCanMoveRightMax[0])
                mRowMoveRightReal[0] = mRowCanMoveRightMax[0]

            //Sau đó các node sau move dần
            let stillNeedMoveFromRow1 = maxNeedMove - mRowCanMoveRightMax[0]
            console.log("mRowCanMoveMax , stillNeedMoveFromRow1 = ", stillNeedMoveFromRow1)
            //Lấp đầy stillNeedMoveFromRow1 vào mảng mRowCanMoveRightMax
            let tmp = stillNeedMoveFromRow1
            if (tmp > 0)
                for (let r = 1; r <= maxRow; r++) {
                    let tmp0 = tmp
                    tmp -= mRowCanMoveRightMax[r]
                    if (tmp <= 0) {
                        mRowMoveRightReal[r] = tmp0
                        break
                    }
                    mRowMoveRightReal[r] = mRowCanMoveRightMax[r]
                }
            console.log("mRowCanMoveMax. mRowMoveRightReal = ", mRowMoveRightReal);

            if (mRowMoveRightReal && mRowMoveRightReal.length) {
                for (let r in mObjNeedMove) {
                    if (mRowMoveRightReal[r]) {
                        this.moveObjAndMarried(mObjNeedMove[r], mRowMoveRightReal[r] - 1)
                    }
                }
            }

        }
        this.optimizeMoveRightSpace()
    }

    //Tạo ra vùng cache để truy cập nhanh
    //Chỉ nên có giá trị trong 1 hàm, vì RC sẽ thay đổi
    getCacheRowCol(){

    }

    checkBetweenObjToColHasOne(obj, toCol){
        if(!obj)
            return 0;
        if(this.dataPart.length <=1)
            return 0;

        for(let any of this.dataPart){
            if(any._row == obj._row) {
                if (any._col > obj._col && any._col < toCol)
                    return 1
                if (any._col > toCol && any._col < obj._col)
                    return 1
            }
        }
        return 0;
    }

    //Todo : cần kiểm tra vị trí phải trái có khoảng trống anh em, vợ chồng..., không thể nhảy quãng qua node khác
    //Hàm này thực hiện cuối cùng, khi còn vị trí trống có thể move đến thì sẽ thực hiện move
    moveToFixCol(){

        if(this.dataPart.length <=1)
            return;

        //Không move vị trí khi không level khác đi
        if(this.optMaxRowLevelLimitShow)
            return;

        //Nếu ko có option manOnly, ... thì sẽ move ColFix:
        if(!this.optShowMarried || this.optShowOnlyMan) {
        }else{
            let [maxRow, maxCol] = clsTreeTopDownCtrl.getMaxColRow(this.dataPart)
            //Duyệt từ trên xuống, từ trái qua phải
            for (let r = 0; r <= maxRow; r++) {
                for (let c = 0; c <= maxCol; c++) {
                    let any = this.getObjByColRow(c, r)
                    if(!any || any.col_fix === null || any.col_fix < 0 || any.col_fix === undefined)
                        continue

                    //Kiểm tra xem giữa 2 cái có phần tử nào không:
                    if(this.checkBetweenObjToColHasOne(any, any.col_fix))
                        continue;

                    if(!this.getObjByColRow(any.col_fix, any._row ))
                        any._col = any.col_fix;
                }
                for (let c = maxCol; c >= 0; c--) {
                    let any = this.getObjByColRow(c, r)
                    if(!any || any.col_fix === null || any.col_fix < 0 || any.col_fix === undefined)
                        continue
                    //Kiểm tra xem giữa 2 cái có phần tử nào không:
                    if(this.checkBetweenObjToColHasOne(any, any.col_fix))
                        continue;
                    if(!this.getObjByColRow(any.col_fix, any._row ))
                        any._col = any.col_fix;
                }
            }

        }
    }

    moveGrandParentToCenterLeft() {

        if (!this.optEnableGrandParentToCenter)
            return
        // return;
        //Kiểm tra xem top node có cân đối khoảng giữa tree
        //Ví dụ nếu lệch PHẢI quá thì chỉnh sang phía TRÁI
        //Bằng cách chỉnh dần các hàng phía dưới sang TRÁI, xem khả năng tối đa sang TRÁI được bao nhiêu
        //Rồi chỉnh dần từng hàng, tất nhiên là không nên sang tối đa
        let topNode = this.getFirstObjInRow(0)
        if(!topNode)
            return;
        let maxColHalfOfAll = Math.floor(this.getMaxCol() / 2)
        let maxRow = this.getMaxRow()

        //Nếu topnode lệch phải nhiều, thì chỉnh nó sang trái
        if (topNode._col > maxColHalfOfAll + 2) {
            let maxNeedMove = topNode._col - maxColHalfOfAll
            let firstChild = null
            let obj = topNode
            let maxCanMoveLeft = 0
            //Tối đa maxRow lần là xong
            let mRowCanMoveLeftMax = []
            let mObjNeedMove = [topNode]

            // Tính mảng mRowCanMoveLeftMax: di chuyển bên trái tối đa được bao nhiêu từ TopNode đến các con cháu đầu tiên bên trái
            for (let r = 0; r <= maxRow; r++)
                //for(let r=maxRow; r >= 0; r--)
            {
                firstChild = this.getFirstChildOfObj(obj)
                if (!firstChild)
                    break
                mObjNeedMove.push(firstChild)
                let canMoveLeft = obj._col - firstChild._col
                mRowCanMoveLeftMax[r] = canMoveLeft
                maxCanMoveLeft += canMoveLeft
                console.log(" firstChild = ", firstChild, obj._col - firstChild._col);
                obj = firstChild
            }

            //Tính lại cộng dồn max từ dưới lên trên hàng 0
            for (let i = mRowCanMoveLeftMax.length - 2; i >= 0; i--)
                mRowCanMoveLeftMax[i] += mRowCanMoveLeftMax[i + 1]


            let mRowMoveLeftReal = []
            //Nếu có thể move thoải mái, thì TopNode có thể move max
            if (maxCanMoveLeft >= maxNeedMove)
                // mObjNeedMove[0]._col -= maxNeedMove
                this.moveObjAndMarried(mObjNeedMove[0], -1 * maxNeedMove)
            else
                this.moveObjAndMarried(mObjNeedMove[0], mRowCanMoveLeftMax[0])
            // mObjNeedMove[0]._col -= mRowCanMoveLeftMax[0]
            //Duyệt từ trên xuống
            for (let r = 1; r <= maxRow; r++) {
                //Nếu con đầu ở phía sau cha, thì con đầu phải move lên bằng cha, nếu không thì ko cần move gì cả
                if (mObjNeedMove[r] && mObjNeedMove[r]._col > mObjNeedMove[r - 1]._col)
                    this.moveObjAndMarried(mObjNeedMove[r], -1 * (mObjNeedMove[r]._col - mObjNeedMove[r - 1]._col))
            }
            this.optimizeMoveLeftSpace()
        }
    }

    moveObjAndMarried(obj, nCol) {
        let mm = this.findGetMariedOfObj(obj)
        if (mm && mm.length) {
            for (let any of mm) {
                if(any._col + nCol >= 0)
                    any._col += nCol
            }
        }
        if(obj._col + nCol >= 0)
            obj._col += nCol
    }


    deleteObjAndAllChildAndMarried(obj) {
        this.deleteObjAndAllChild(obj, 1)
    }

    deleteObjAndAllChild(obj, withMarried = 0) {
        let mmDel = this.findGetAllChildsDeepOfObj(obj)
        mmDel.push(obj)

        if (withMarried)
            if (this.findGetMariedOfObj(obj))
                mmDel.push(...this.findGetMariedOfObj(obj))

        console.log(" mmDel = ", mmDel);
        console.log(" Array1  before del: ", this.dataPart);
        for (let del of mmDel) {
            this.dataPart.splice(this.dataPart.findIndex(function (i) {
                return i.id == del.id;
            }), 1);
        }
    }

    deleteArrayIdObj(mmId) {

        this.dataPart = this.dataPart.filter(item => !mmId.includes(item.id));

        // this.dataPart.splice(this.dataPart.findIndex(function(i){
        //     console.log("xxx1 ", i.id, mmId);
        //     return mmId.includes(i.id);
        // }), 1);
    }

    deleteObj(obj) {
        if(!obj)
            return null;
        this.dataPart = this.dataPart.filter(item => item.id !== obj.id);
    }

    getNextOnLeft(objOrId) {
        if(typeof objOrId !== "object")
            objOrId = this.getObjFromId(objOrId)
        let ret = null
        for(let any of this.dataPart){
            if(any._row == objOrId._row && any._col < objOrId._col){
                if(!ret)
                    ret = any;
                if(any._col > ret._col){
                    ret = any
                }
            }
        }
        return ret
    }

    getNextOnRight(objOrId) {

        if(typeof objOrId !== "object")
            objOrId = this.getObjFromId(objOrId)

        let ret = null
        for(let any of this.dataPart){
            if(any._row == objOrId._row && any._col > objOrId._col){
                if(!ret)
                    ret = any;
                if(any._col < ret._col){
                    ret = any
                }
            }
        }
        return ret
    }

    findGetParentOfObj(obj) {
        if(!obj)
            return null;
        // let idx
        // if(typeof objOrNum === 'object')
        //     idx = objOrNum.id
        // else
        //     idx = objOrNum

        for (let any of this.dataPart) {
            if (any.id === obj.parent_id) {
                return any;
            }
        }

        return null;
    }
    //Đầu vào là obj hoặc số
    findGetMariedOfObj(objOrNum) {
        if(!objOrNum)
            return null;
        let idx
        if(typeof objOrNum === 'object')
            idx = objOrNum.id
        else
            idx = objOrNum

        // let obj1 = this.getObjFromId(idx)
        // if(obj1.married_with2){
        //     // return obj1.married_with2;
        // }

        let mret = []
        for (let any of this.dataPart) {
            if (any.married_with == idx) {
                mret.push(any)
                // if(!obj1.married_with2){
                //     obj1.married_with2 = []
                // }
                // obj1.married_with2.push(any);
            }
        }

        if (mret.length == 0) {
            // obj1.married_with2 = null;
            return null
        }
        return mret
    }

    static getMinX(){
        ///Tìm minx,y để lấy vị trí STT của từng elm
        let tmp = 1000000000000
        let minX = tmp;
        document.querySelectorAll(".svg_cont_node_cls").forEach(function (one) {
            let x = parseInt(one.getAttribute('x'));
            if(x < minX)
                minX = x;

        })
        if(minX === tmp)
            minX = 0;
        return minX
    }

    static getMaxX(){
        ///Tìm minx,y để lấy vị trí STT của từng elm
        let tmp = -1000000000
        let maxX = tmp;
        document.querySelectorAll(".svg_cont_node_cls").forEach(function (one) {
            let x = parseInt(one.getAttribute('x'));
            if(x > maxX)
                maxX = x;
        })
        if(maxX === tmp)
            maxX = 0;
        return maxX
    }

    static getMinXNotIncludeSeleting(){
        ///Tìm minx,y để lấy vị trí STT của từng elm
        let tmp = 1000000000000
        let minX = tmp;
        document.querySelectorAll(".svg_cont_node_cls").forEach(function (one) {
            if(one.getAttribute('data-selecting'))
                return;
            let idx = one.id.replace('svg_cont_node_', '');
            if(clsTreeTopDownCtrl.getInstanceSvgById().tmp_mouse_clicking_node_id == idx)
                return;

            let x = parseInt(one.getAttribute('x'));
            if(x < minX)
                minX = x;
        })
        if(minX === tmp)
            minX = 0;

        return minX
    }

    getXYForNewNodeChildAndMoveAfterOneStepIfNeed(newObj) {

        let minXRec = clsTreeTopDownCtrl.getMinX();

        //Xem parent ở đâu, tìm child cuối chèn vào sau đó, dịch tất cả phía sau sang phải
        // NHưng nếu cha chưa có con, thì con moi sẽ ở đâu
        let mChild = this.findGetAllChildsOfPid(newObj.parent_id);

        let prObj = document.getElementById("svg_cont_node_" + newObj.parent_id);
        let idOfMaXx = 0
        //Vị trí maxX gần nhất để newNode thêm vào sau đó:, ban đầu sẽ là vị trí x của parent, lùi về 1 node
        let maxX = parseInt(prObj.getAttribute('x')) - parseInt(this.spaceBetweenCellX) - this.widthCell;
        let yOfmaxX = parseInt(prObj.getAttribute('y')) + this.heightCell + this.spaceBetweenCellY;
        let newX = 0;

        let foundOneChildOther = 0;

        //Tìm ra x lớn nhất, và tim all phần tự X ở sau, có y bằng Item này êể dịch sang phải
        if (mChild && mChild.length) {
            console.log("mChild, check add child ", mChild);

            //Lay vi tri phần tử cuối trên hang nay de them vao sau do
            mChild.forEach(function (oneC) {
                if (oneC.id !== newObj.id) {
                    foundOneChildOther = 1;
                    document.querySelectorAll(".svg_cont_node_cls[data-svg-id='" + oneC.id + "']").forEach(function (oneChild) {
                        let x = oneChild.getAttribute("x");
                        let y = oneChild.getAttribute("y");
                        console.log("db2 x1 = ", x);
                        if (parseInt(x) > maxX) {
                            maxX = parseInt(x);
                            idOfMaXx = oneC.id;
                        }
                    })
                }
            })

            if(foundOneChildOther) {


                console.log("db2 1 add child idOfMaXx: ", maxX, yOfmaxX, idOfMaXx);

                newX = maxX + parseInt(this.spaceBetweenCellX) + this.widthCell;



                let needMoveRight = 0;
                let that = this
                //Ktr Nếu còn khoảng trống bên phải thì move sang luôn
                document.querySelectorAll(".svg_cont_node_cls[y='" + yOfmaxX + "']").forEach(function (oneChild) {
                    let x = parseInt(oneChild.getAttribute("x"));
                    if (Math.abs(x - newX) < that.widthCell) {
                        needMoveRight = 1;
                    }
                })

                //Tìm all Y cùng dòng, để đẩy sang phải 1 ô
                if (needMoveRight)
                    document.querySelectorAll(".svg_cont_node_cls[y='" + yOfmaxX + "']").forEach(function (oneChild) {
                        let x = parseInt(oneChild.getAttribute("x"));
                        if (x > maxX)
                            if (oneChild.getAttribute("y") == yOfmaxX) {
                                oneChild.setAttribute('x', x + that.spaceBetweenCellX + that.widthCell)
                            }
                    })
            }

        }
        if(!foundOneChildOther){

            console.log(" Không co anh em ", newObj);
            newX = parseInt(prObj.getAttribute('x'));

            /*
            //Gán lại xy vao dataAll
            this.dataAll.forEach(function (oneC) {
                let elements = document.querySelectorAll(".svg_cont_node_cls");
                elements.forEach(function (oneChild) {
                    if(oneChild.getAttribute('data-svg-id') == oneC.id){
                        oneC.__x = parseInt(oneChild.getAttribute('x'));
                        oneC.__y = parseInt(oneChild.getAttribute('y'));
                    }
                });
            })

            //Tim ben trai va ben phai cua cha
            console.log("dataAll = : ", this.dataAll);
            let { pOfKLeft, pOfKRight, maxXLeftChild, minXRightChild } = this.findElementsX(this.dataAll, newObj);
            console.log("pOfKLeft ", pOfKLeft);
            console.log("pOfKRight ", pOfKRight);
            console.log("maxXLeftChild ", maxXLeftChild);
            console.log("minXRightChild ", minXRightChild);

            //Nếu cha không có anh em, thì con thẳng cha
            if(!pOfKLeft && !pOfKRight){
                newX = parseInt(prObj.getAttribute('x'));
                console.log(" Not left right pId");
            }
            else//Neu co 1 cai left
            if(maxXLeftChild){
                    newX = maxXLeftChild.__x + this.widthCell + this.spaceBetweenCellX;
                    console.log(" Have maxXLeftChild " , newX, maxXLeftChild.__x, this.spaceBetweenCellX);
            }
            else
                if(minXRightChild){
                    console.log(" Have minXRightChild");
                    newX = minXRightChild.__x - this.widthCell - this.spaceBetweenCellX;
                }
             */
        }

        console.log(" New x = " , newX);

        let nX = clsTreeTopDownCtrl.getNxNyFromXY(clsTreeTopDownCtrl.getInstanceSvgById(), newX, minXRec)
        console.log(" nX x = " , nX);
        return [newX, yOfmaxX, nX]
    }



    findElementsX(dataAll, K) {
        // Tìm phần tử cha của K
        const pOfK = dataAll.find(item => item.id === K.parent_id);

        if (!pOfK) {
            return null; // Không tìm thấy phần tử cha
        }

        // Tìm phần tử pOfKLeft có con
        let pOfKLeft = null;
        let minXLeft = Infinity;
        for (const item of dataAll) {
            if (
                item.id !== pOfK.id &&
                item.__y === pOfK.__y &&
                item.__x < pOfK.__x &&
                item.__x < minXLeft &&
                dataAll.some(child => child.parent_id === item.id) // Kiểm tra có con
            ) {
                pOfKLeft = item;
                minXLeft = item.__x;
            }
        }

        // Tìm phần tử pOfKRight có con
        let pOfKRight = null;
        let maxXRight = -Infinity;
        for (const item of dataAll) {
            if (
                item.id !== pOfK.id &&
                item.__y === pOfK.__y &&
                item.__x > pOfK.__x &&
                item.__x > maxXRight &&
                dataAll.some(child => child.parent_id === item.id) // Kiểm tra có con
            ) {
                pOfKRight = item;
                maxXRight = item.__x;
            }
        }

        // Tìm maxXLeftChild
        let maxXLeftChild = null;
        let maxXLeft = -Infinity;
        if (pOfKLeft) {
            for (const item of dataAll) {
                if (item.parent_id === pOfKLeft.id && item.__x > maxXLeft) {
                    maxXLeftChild = item;
                    maxXLeft = item.__x;
                }
            }
        }

        // Tìm minXRightChild
        let minXRightChild = null;
        let minXRight = Infinity;
        if (pOfKRight) {
            for (const item of dataAll) {
                if (item.parent_id === pOfKRight.id && item.__x < minXRight) {
                    minXRightChild = item;
                    minXRight = item.__x;
                }
            }
        }

        return { pOfKLeft, pOfKRight, maxXLeftChild, minXRightChild };
    }

    /**
     *
     * Thay đổi với Node, vẽ lại SVG
     * @param treeIns clsTreeTopDownCtrl
     * @param objNode
     * @param action
     * @param newName
     * @param imgLink
     */
    static nodeAction(action, objNodeAction, doingNode) {

        let treeIns = clsTreeTopDownCtrl.doingSvgObj
        if (treeIns instanceof clsTreeTopDownCtrl) ;

        // let objNode = clsTreeTopDownCtrl.doingNodeObj
        // let newName = objNodeNew.name
        // let imgLink  = objNodeNew.thumb
        // let newId  = objNodeNew.id
        //let idSvgRoot = this1.closest('.root_svg').attr('id')

        console.log(" ID Root = ", treeIns.idSvgSelector, doingNode);

        // let treeIns = new clsTreeTopDownCtrl()
        // treeIns = clsTreeTopDownCtrl.getInstanceSvgById(idSvgRoot)

        console.log("treeIns.data = ", treeIns.dataPart);

        if (action == 'edit_node') {
            // objNode.name = $("#new_name").val()
            // objNode.birthday = $("#new_birthday").val()
            // objNode.orders = $("#new_orders").val()
            // objNode.gender = $("input[name=new_gender]:checked").val(),
            console.log("Edit node: ", doingNode, treeIns.dataPart);

            treeIns.updateNodeUI(doingNode)

            // if(objNodeAction.orders == $("#new_orders").val()){
            //     console.log(" Không đổi order");
            // }
            // else{
            //     console.log(" Có đổi order");
            // }

            treeIns.drawLineToParent(doingNode);
            let m1 = treeIns.findGetMariedOfObj(doingNode)
            console.log("M1x = ", doingNode, m1);
            if(m1)
                m1.forEach(function(obj){
                treeIns.drawLineToParent(obj);
            })

            //Todo: Nếu đổi tên mà cũng redraw thì  mất công, chỉ có đổi thứ tự mới phải vẽ lại
            // treeIns.reDrawTree()
            return;
        }

        let newObj = new clsTreeNode();

        console.log(" objNodeAction= ", objNodeAction);

        //nếu là các add_child, add_married
        if (action == 'add_child' || action == 'add_married' || action == 'add_parent') {
            if (treeIns.optDisableApiForTestLocalOnly)
                newObj.id = treeIns.getMaxIdNode() + 1
            else
                newObj.id = objNodeAction.id
            // newObj.id = {...objNodeAction}
        }


        newObj.name = objNodeAction.name
        newObj.gender = objNodeAction.gender
        newObj.birthday = objNodeAction.birthday
        newObj.title = objNodeAction.title
        newObj.orders = objNodeAction.orders
        if (!newObj.orders)
            newObj.orders = 0;
        newObj.phone_number = objNodeAction.phone_number
        newObj.email_address = objNodeAction.email_address
        newObj.date_of_death = objNodeAction.date_of_death
        newObj.home_address = objNodeAction.home_address
        newObj.place_heaven = objNodeAction.place_heaven

        newObj.link_remote = objNodeAction.link_remote
        newObj.set_nu_dinh = objNodeAction.set_nu_dinh


        newObj._image_list = objNodeAction._image_list

        newObj._col = -1
        newObj._row = doingNode._row + 1
        newObj._mark_add_new = 1

        //Tinh Nx, NY tu obj nay?

        // newObj._image_list = objNodeAction._image_list
        // newObj.gender = $("input[name=new_gender]:checked").val()

        if (!newObj.orders)
            newObj.orders = 0

        if (action == 'add_parent') {
            if (doingNode.parent_id > 0) {
                alert("Không thể thêm cha, vì Thành viên đã có cha! ID Cha = " + doingNode.parent_id)
                return;
            }

            if (doingNode.married_with) {
                alert("Không thể thêm cha/mẹ cho vợ/chồng!")
                return;
            }


            newObj.parent_id = 0
            doingNode.parent_id = newObj.id
            let mMaried = treeIns.findGetMariedOfObj(doingNode)
            if (mMaried && mMaried.length)
                for (let tmp of mMaried)
                    tmp.parent_id = newObj.id
        }

        if (action == 'add_child') {
            newObj.parent_id = doingNode.id
            //Nếu là thêm con cho vợ/chồng, thì phải gán parent về gốc
            if (doingNode.married_with) {
                console.log(" xxxxx 111");
                let pObj = treeIns.getObjFromId(doingNode.married_with)
                newObj.parent_id = pObj.id
                newObj._row = doingNode._row + 1

                //Nếu như là vợ chồng 2 của bố mẹ, thì sẽ cần gán child_of_second_married
                if (doingNode._col > pObj._col + 1) {
                    console.log(" xxxxx 112");
                    newObj.child_of_second_married = doingNode.id
                }
            }
        }

        if (action == 'add_married') {
            //newObj.name = 'Vo ' + obj.id
            newObj.parent_id = doingNode.parent_id
            newObj.married_with = doingNode.id
            newObj.child_type = 2
            newObj._row = doingNode._row

        }

        // treeIns.removeAllConnectLineParentAndMarried()
        treeIns.dataPart.push(newObj)

        //xxxxx
        //25.4.2024 nếu theo cách usẻ tự vẽ
        //cần bỏ redraw ở đây, và thêm theo 1 cách mới:
        //Nếu còn chỗ trống thì thêm vào, ko thì dịch hết các phần tử phía sau sang 1 bước để thêm
        //treeIns.reDrawTree()

        //if (action == 'add_child' || action == 'add_married')


        if (action == 'add_child') {

            let [newX, yOfmaxX, nx] = treeIns.getXYForNewNodeChildAndMoveAfterOneStepIfNeed(newObj);
            newObj.nx = nx
            //TInh NxNy tu newX, yOfmaxX:
            treeIns.createDrawOneNode(newObj, newX, yOfmaxX);

            for (let tmp of treeIns.dataPart)
            {
                treeIns.drawLineMarried(tmp)
                treeIns.drawLineToParent(tmp)
            }
            treeIns.updateSyncXyNodesToTreeAll();
        }

        if (action == 'add_married') {

            let mSpouse  = treeIns.findGetMariedOfObj(doingNode.id);

            let thisObj =  document.getElementById('svg_cont_node_' + doingNode.id);

            console.log("db2 thisObj " , thisObj, ' mSpouse = ' , mSpouse);

            //Tìm all x xem cái nào xa nhất
            //Ban đầu gán bằng chính obj này
            let maxX = parseInt(thisObj.getAttribute('x'));
            let yOfmaxX = parseInt(thisObj.getAttribute('y'));
            mSpouse.forEach(function(one){
                if (one.id === newObj.id)
                    return;
                let elm = document.getElementById('svg_cont_node_' + one.id);
                if(elm){
                    let x = parseInt(elm.getAttribute('x'));
                    if(x > maxX)
                        maxX = x;
                }
            })

            console.log("db2 maxX mSpouse " , maxX);

            //Tìm xem phía sau có phải di chuyển sang 1 bước không:
            let needMoveRight = 0;
            let that = treeIns
            //Ktr Nếu còn khoảng trống bên phải thì move sang luôn
            document.querySelectorAll(".svg_cont_node_cls[y='" + yOfmaxX + "']").forEach(function (oneChild) {
                let x = parseInt(oneChild.getAttribute("x"));
                if (Math.abs(x - maxX) < that.widthCell) {
                    needMoveRight = 1;
                }
            })

            //Tìm all Y cùng dòng, để đẩy sang phải 1 ô
            if (needMoveRight)
                document.querySelectorAll(".svg_cont_node_cls[y='" + yOfmaxX + "']").forEach(function (oneChild) {
                    let x = parseInt(oneChild.getAttribute("x"));
                    if (x > maxX)
                        if (oneChild.getAttribute("y") == yOfmaxX) {
                            oneChild.setAttribute('x', x + that.spaceBetweenCellX + that.widthCell)
                        }
                })

            let newX = maxX + parseInt(treeIns.spaceBetweenCellX) + treeIns.widthCell;
            console.log("db2 newx = ", newX);

            let minXRec = clsTreeTopDownCtrl.getMinX();
            let nx = clsTreeTopDownCtrl.getNxNyFromXY(treeIns, newX, minXRec)

            newObj.nx = nx;
            treeIns.createDrawOneNode(newObj, newX, yOfmaxX);

            for (let tmp of treeIns.dataPart)
            {
                treeIns.drawLineMarried(tmp)
                treeIns.drawLineToParent(tmp)
            }

            treeIns.updateSyncXyNodesToTreeAll();

        }
            // treeIns.moveObjToCenterOfViewPort(newObj)
    }

    static tester1() {

        test01()

    }

    static resetDefault(svgId) {
        let svg = clsTreeTopDownCtrl.getInstanceSvgById(svgId)
        svg.optDisableApiForTestLocalOnly = 0
        svg.optShowMarried = 1
        svg.optShowOnlyMan = 0
        svg.optRemoveImage = 0
        svg.clearResetAllSvgToReDraw()
        svg.reDrawTree()
        svg.updateBBox()
        svg.resize()
        svg.center()
    }


    static setOnlyMan(svgId) {
        let svg = clsTreeTopDownCtrl.getInstanceSvgById(svgId)
        svg.optShowOnlyMan = 1
        svg.optShowMarried = 0
        svg.clearResetAllSvgToReDraw()
        svg.reDrawTree()
        svg.updateBBox()
        svg.resize()
        svg.center()
    }

    static setDisableMarried(svgId) {
        let svg = clsTreeTopDownCtrl.getInstanceSvgById(svgId)
        svg.optShowMarried = 0
        svg.optShowOnlyMan = 0
        svg.clearResetAllSvgToReDraw()
        svg.reDrawTree()
        svg.updateBBox()
        svg.resize()
        svg.center()
    }

    static setRemoveImage(svgId) {
        let svg = clsTreeTopDownCtrl.getInstanceSvgById(svgId)
        svg.optRemoveImage = 1
        svg.clearResetAllSvgToReDraw()
        svg.reDrawTree()
        svg.updateBBox()
        svg.resize()
        svg.center()
    }

    static setDisableApiForTestLocal(svgId) {
        let svg = clsTreeTopDownCtrl.getInstanceSvgById(svgId)
        svg.optDisableApiForTestLocalOnly = 1
        svg.clearResetAllSvgToReDraw()
        svg.reDrawTree()
        svg.updateBBox()
        svg.resize()
        svg.center()
    }

    static createNewTree(svgId) {
        let name = $("#first_member_name_of_tree").val()
        if (!name || name.length < 2) {
            alert("Tên phải lớn hơn 1 ký tự");
            return
        }

        let tree = clsTreeTopDownCtrl.getInstanceSvgById(svgId)
        // let tree = new clsTreeTopDownCtrl()

        let objNew = {name: name, parent_id: 0, gender: 1}

        let ret
        if (ret = tree.nodeAddApi(objNew, 'add_child', 'add_new_root')) {
            let url = jctool.getUrlNotParam() + "?pid=" + ret
            window.location.href = url
        } else {
            alert("Có lỗi không thể tạo cây mới!");
        }
    }

    nodeDeleteApi(tree, obj) {

        let idItem = obj.id
        console.log("Delete item1..", idItem);

        let mm = tree.findGetAllChildsDeepOfObjAndMarried(obj)
        if (!mm)
            mm = [obj]
        else
            mm.push(obj)

        //Phải bỏ đi các OBJ ko thuộc user nay nếu có link:
        let strDelId = clsTreeTopDownCtrl.getStringIdOfNodeArraySeparateByComma(mm, 1)
        if (!strDelId)
            strDelId = idItem
        if (!tree.apiBearToken) {
            alert("Bạn chưa đăng nhập?")
            return;
        }

        if(obj.belong_other){
            alert("Có lỗi: Thành viên thuộc nhánh liên kết, không thuộc tài khoản của bạn nên không thể chỉnh sửa" );
            return;
        }

        if (tree.optDisableApiTreeText && tree.optDisableApiTreeText.length > 0) {
            alert("Có lỗi: " + tree.optDisableApiTreeText);
            return;
        }

        jQuery('.loader1').show();
        let ret = 0
        let urlAct = tree.apiDelete + "?id=" + strDelId
        $.ajax({
            url: urlAct,
            async: false,
            type: "GET",
            beforeSend: function (xhr) {
                xhr.setRequestHeader('Authorization', 'Bearer ' + tree.apiBearToken);
            },
            success: function (data, status) {
                jQuery('.loader1').hide();
                console.log("Data: ", data, " \nStatus: ", status);
                console.log("Delete item12..", idItem);

                ret = 1
            },
            error: function (jqXHR, exception) {
                jQuery('.loader1').hide();
                clsTreeTopDownCtrl.showError(jqXHR)
                console.log(" Error....");
                ret = 0
            },
        });
        return ret
    }

    static showError(jqXHR) {
        if (jqXHR.status != 200) {
            if (jqXHR.responseJSON && jqXHR.responseJSON.payload) {
                alert("Error " + jqXHR.status + " : " + jqXHR.responseJSON.payload)
            } else {
                alert("Error " + jqXHR.status + " : unknow error!")
            }
        } else
            alert("Error..." + jqXHR.status)
    }

    nodeAddApi(objNode, cmd, extraCmd) {
        let urlAct = this.apiAdd
        let type = "POST"
        let idRet = false
        let that = this
        let doingObj = clsTreeTopDownCtrl.doingNodeObj

        console.log(" Add Child nodeAddApi objNode = ", objNode);

        if (!this.apiBearToken) {
            alert("Bạn chưa đăng nhập?")
            return;
        }

        if(objNode.belong_other){
            alert("Có lỗi: Thành viên thuộc nhánh liên kết, không thuộc tài khoản của bạn nên không thể chỉnh sửa" );
            return;
        }

        if (this.optDisableApiTreeText && this.optDisableApiTreeText.length > 0) {
            alert("Có lỗi: " + this.optDisableApiTreeText);
            return;
        }

        if (cmd == 'add_parent')
            urlAct = jctool.setUrlParamString(urlAct, 'add_parent_to', doingObj.id);
        jQuery('.loader1').show();
        $.ajax({
            url: urlAct,
            async: false,
            type: type,
            beforeSend: function (xhr) {
                xhr.setRequestHeader('Authorization', 'Bearer ' + that.apiBearToken);
            },
            data: objNode,
            success: function (data, status) {
                jQuery('.loader1').hide();
                console.log("Data: ", data, " \nStatus: ", status);
                if (cmd == 'add_child' || cmd == 'add_married' || cmd == 'add_parent') {
                    if (!data.payload) {
                        alert("Error add item, not valid ?")
                        return false
                    }
                    idRet = data.payload
                    objNode.id = data.payload
                    if (cmd == 'add_parent') {
                        //Khi add được thì cần thêm setPid để redraw lấy lại PID mới
                        that.setPid = idRet
                        jctool.setCurrentUrlParamAndGo('pid', idRet)
                    }
                }

                if (extraCmd != 'add_new_root') {
                    clsTreeTopDownCtrl.nodeAction(
                        cmd,
                        objNode,
                        clsTreeTopDownCtrl.doingNodeObj
                    )
                }
            },
            error: function (jqXHR, exception) {
                jQuery('.loader1').hide();
                clsTreeTopDownCtrl.showError(jqXHR)

                console.log(" Error jqXHR....", jqXHR);
                console.log(" Error exception....", exception);
                idRet = false
            },
        });

        return idRet
    }

    nodeEditApi(objNode) {

        console.log(" nodeEditApi post: ", objNode);
        let dataPost2 = {
            name: objNode.name,
            birthday: objNode.birthday,
            title: objNode.title,
            phone_number: objNode.phone_number,
            email_address: objNode.email_address,
            home_address: objNode.home_address,
            link_remote: objNode.link_remote,
            set_nu_dinh: objNode.set_nu_dinh,

            place_heaven:  objNode.place_heaven,
            date_of_death: objNode.date_of_death,
            orders: objNode.orders,
            gender: objNode.gender,
            image_list: objNode.image_list,
            child_of_second_married: objNode.child_of_second_married,
            stepchild_of: objNode.stepchild_of
        }

        if (!objNode.name || objNode.name.length < 2) {
            alert("Tên phải lớn hơn 1 ký tự");
            return
        }

        if (!this.apiBearToken) {
            alert("Bạn chưa đăng nhập?")
            return;
        }

        if(objNode.belong_other){
            alert("Có lỗi: Thành viên thuộc nhánh liên kết, không thuộc tài khoản của bạn nên không thể chỉnh sửa" );
            return;
        }
        if (this.optDisableApiTreeText && this.optDisableApiTreeText.length > 0) {
            alert("Có lỗi: " + this.optDisableApiTreeText);
            return;
        }

        let ret = 0
        let that = this
        let urlAct = this.apiUpdate + "/" + objNode.id
        let type = "POST"
        jQuery('.loader1').show();
        $.ajax({
            url: urlAct,
            async: false,
            type: type,
            beforeSend: function (xhr) {
                xhr.setRequestHeader('Authorization', 'Bearer ' + that.apiBearToken);
            },
            data: dataPost2,
            success: function (data, status) {
                console.log("Data: ", data, " \nStatus: ", status);
                jQuery('.loader1').hide();


                clsTreeTopDownCtrl.nodeAction(
                    'edit_node',
                    objNode,
                    clsTreeTopDownCtrl.doingNodeObj
                )

                ret = 1

                $("#dialog-node-add").dialog("close");
            },
            error: function (jqXHR, exception) {
                jQuery('.loader1').hide();
                ret = 0
                clsTreeTopDownCtrl.showError(jqXHR)
                console.log(" Eror....");
            },
        });

        return ret
    }

    static showDebugIdOrders(svgId) {
        //let svg = clsTreeTopDownCtrl.getInstanceSvgById(svgId)

        $(".debug_id_orders").toggle();
        //    svg.optShowDebugIdAndOrders = 0

    }

    static setBackGroundManOrWoman(svgId, manOrWoman = 0) {
        let svg = clsTreeTopDownCtrl.getInstanceSvgById(svgId)
        svg.selectingManWomanBackGround = manOrWoman
        // console.log(" select bg for : " , manOrWoman)
        // if (manOrWoman == 2)
        //     $("#dialog-select-background").dialog('option', 'title', 'Chọn khung ảnh cho NỮ');
        // if (manOrWoman == 1)
        //     $("#dialog-select-background").dialog('option', 'title', 'Chọn khung ảnh cho NAM');
        // if (manOrWoman == 0)
        //     $("#dialog-select-background").dialog('option', 'title', 'Chọn khung ảnh cho tất cả Thành viên');
    }

    static selectBackGround(svgId, manOrWoman = 0) {
        $("#dialog-select-background").dialog('open')
    }

    static showConfigTree(svgId) {
        $("#dialog-show-config").dialog('open')
    }


    static selectBackGroundForBanner(svgId) {
        //let svg = clsTreeTopDownCtrl.getInstanceSvgById(svgId)
        // $('.node_cont').css('background-image', 'url("/public/images/khung-anh1.png")')
        $("#dialog-select-banner-background").dialog('open')
        $("#dialog-select-banner-background").dialog('option', 'title', 'Chọn khung ảnh cho Banner');
    }

    uploadFile(file_id = 'file_id') {

        let urlUpload = this.apiUploadImage
        let retUpload = 0

        if ($('#' + file_id)[0].files[0]) {

            console.log("Filesize: ", $('#' + file_id)[0].files[0].size);

            if ($('#' + file_id)[0].files[0].size > 1000000) {
                alert("Can not upload file, file is too big: " + byteSize($('#' + file_id)[0].files[0].size));
                return 0
            }

            // const config = {
            //     file: $('#' + file_id)[0].files[0],
            //     maxSize: 200
            // };
            //
            // const resizedImage = await resizeImage(config)

            // console.log("upload resized image", resizedImage)

            let formData = new FormData();
            formData.append('file_data',
                $('#' + file_id)[0].files[0]
                // resizedImage
            );

            let that = this
            if (!this.apiBearToken) {
                alert("Bạn chưa đăng nhập?")
                return;
            }

            if (this.optDisableApiTreeText && this.optDisableApiTreeText.length > 0) {
                alert("Có lỗi: " + this.optDisableApiTreeText);
                return;
            }
            jQuery('.loader1').show();
            //Upload image before:
            $.ajax({
                url: urlUpload,
                async: false,
                type: 'POST',
                processData: false,  // tell jQuery not to process the data
                contentType: false,  // tell jQuery not to set contentType
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('Authorization', 'Bearer ' + that.apiBearToken);
                },
                data: formData,
                success: function (data, status) {
                    jQuery('.loader1').hide();
                    console.log("DataUpload ret: ", data, " \nStatus: ", status);
                    if (!data || !data.payload || !(data.payload.id)) {
                        console.log("Error 1");
                        return
                    }
                    retUpload = data.payload
                },
                error: function (ret, exception) {
                    jQuery('.loader1').hide();
                    console.log(" Error upload file...." , ret);
                    if(ret.responseJSON){
                        if(!ret.responseJSON.payload)
                            ret.responseJSON.payload = '';
                        if(!ret.responseJSON.message)
                            ret.responseJSON.message = '';
                        if(ret.responseJSON.message == ret.responseJSON.payload )
                            ret.responseJSON.payload = '';
                        alert("Error upload:\n" + ret.responseJSON.message + '\n' + ret.responseJSON.payload)
                    }
                    else{
                        if(ret.responseText)
                            alert("Error upload file.." + ret.responseText)
                        else
                            alert("Error upload file!")
                    }

                },
            });
        }

        console.log("RetUpload ", retUpload);

        return retUpload

    }

    setBannerTree() {

        let grid = this.getRootSvgIfHavePanZoom();
        let newDiv1 = document.createElement('div');
        // let bgImg = ';background-size: 100% 100%;background-image: url("/images/tree-mng-banner1.png");';
        let bgImg = ';background-size: 100% 100%;background-image: url("/images/border-banner-bg1/banner10.png");';

        let objTop = this.dataPart[0]
        objTop = this.getTopNodeFirst()
        console.log(" objTop first = ", objTop);
        // objTop = this.getTopNodeRow0();
        // let objTop = this.getTopNodeRow0()
        // if(!objTop)
        //     return;

        // console.log(" objTop = ", objTop);
        let editIcon = " <div data-code-pos='ppp1676716377836' style='position: relative'> " +
            "<div style=''" +
            " class='node_edit_btn_banner' title='Edit banner' onclick='clickEditBanner()'>" +
            " &#9776; " +
            "</div> " +
            "</div>";

        let title = ''
        if (objTop.title)
            title = objTop.title;

        if (this.objBannerTop && this.objBannerTop._image_list)
            bgImg = ';background-size: 100% 100%;background-image: url("' + this.objBannerTop._image_list + '");';

        if (this.objBannerTop && this.objBannerTop.image_list && isNaN(this.objBannerTop.image_list) &&  this.objBannerTop.image_list.indexOf("/") >= 0)
            bgImg = ';background-size: 100% 100%;background-image: url("' + this.objBannerTop.image_list + '");';


        if (this.objBannerTop && this.objBannerTop.title)
            title = this.objBannerTop.title;
        let name = objTop.name
        if (this.objBannerTop && this.objBannerTop.name)
            name = this.objBannerTop.name;

        // "width: " + this.objBannerTop.banner_width +"px;" +
        // "height: " + this.objBannerTop.banner_height +"px;" +

        let bannerWH = '';
        if (this.objBannerTop.banner_width)
            bannerWH += ';width: ' + this.objBannerTop.banner_width + 'px;'
        if (this.objBannerTop.banner_height)
            bannerWH += ';height: ' + this.objBannerTop.banner_height + 'px;'
        if (this.objBannerTop.banner_margin_top)
            bannerWH += ';margin-top: ' + this.objBannerTop.banner_margin_top + 'px;'

        newDiv1.innerHTML = "<div class='banner_tree_div' id='banner_img_id' style='" + bannerWH + bgImg + " ' > " + editIcon
        if(this.optUseBannerCicleTypeJs)
            newDiv1.innerHTML += "<div id='banner_name_id' " +
            "class='" + this.objBannerTop.banner_text_shadow_name +"' " +
            "style='" +
            "font-weight: " + this.objBannerTop.banner_name_bold + "; " +
            "font-style: " + this.objBannerTop.banner_name_italic + ";" +
            "font-size: " + this.objBannerTop.fontsize_name + "px;" +
            ";margin-top: " + this.objBannerTop.banner_name_margin_top + "px;" +
            "color: " + this.objBannerTop.color_name + "; '> " + name +
            " </div> "
        if(this.optUseBannerCicleTypeJs)
            newDiv1.innerHTML += "<div data-code-pos='ppp1676716362556' id='banner_title_id' " +
            "class='" + this.objBannerTop.banner_text_shadow_title +"' " +
            "style='" +
            "font-weight: " + this.objBannerTop.banner_title_bold + "; " +
            "font-style: " + this.objBannerTop.banner_title_italic + ";" +
            "font-size: " + this.objBannerTop.fontsize_title + "px;" +
            ";margin-top: " + this.objBannerTop.banner_title_margin_top + "px;" +
            "color: " + this.objBannerTop.color_title + "; '> " + title + " </div> "

        newDiv1.innerHTML += "</div>";

        let maxCol = this.getMaxCol();


        let bannerW = this.bannerWidth
        let bannerH = this.bannerHeight
        //let xCenter = this.startX + maxCol * (this.spaceBetweenCellX + this.widthCell) / 2 + this.widthCell / 2 - bannerW / 2;
        let xCenter

        // console.log("maxColxxx / xCenter = ", maxCol , xCenter);

        let yBanner = 20;

        if (this._panZoomTiger) {
            let rateZoom = this._panZoomTiger.getSizes().realZoom
            xCenter *= rateZoom;
            yBanner *= rateZoom;
        }

        //Trường hợp Xác định xCenter là giữa các TopNode, chứ ko phải giữa all svg
        let maxCol0 = this.getMaxColInRow(0)
        let minCol0 = this.getMinColInRow(0)
        // console.log(" maxCol0 / minCol0 = ", maxCol0, minCol0);
        if (minCol0 < 0)
            minCol0 = 0;
        //thì gán lại xCenter khác:
        let xc0 = xCenter = this.startX + ((maxCol0 + minCol0) / 2) * (this.spaceBetweenCellX + this.widthCell) + this.widthCell / 2 - bannerW / 2;

        // let xOfTop = document.getElementById('svg_cont_node_' + objTop.id).getAttribute('x');

        //Tinh trung binh cac X, de chia 3
        let cc = 0
        let ttX = 0;
        this.getAllIdRow0().forEach(function(elm){
            ttX += parseInt(document.getElementById('svg_cont_node_' + elm.id).getAttribute('x'));
            cc++;
        })
        let xOfTop = ttX / cc + this.widthCell/2;
        console.log("xTop/xCenter / xc0 = ", xOfTop, xCenter, xc0);
        xCenter = xOfTop - bannerW / 2 ;

        //objTop
        // xOfTop = this.getXCenterOfTopRow()
        // xCenter = xOfTop + bannerW;

        console.log("maxColxxx / xCenter1 / xc0 = ", maxCol , xCenter, xc0);


        let objContSvg = document.createElementNS('http://www.w3.org/2000/svg', "foreignObject");
        //nếu ko tạo mới thì chỉ set lại thuộc tính:
        objContSvg.setAttribute('title', 'Top Banner');
        objContSvg.setAttribute('id', "svg_cont_node_banner_id");
        // objContSvg.setAttribute('data-svg-id-banner', obj.id);
        // objContSvg.setAttribute('class', "svg_cont_node_cls");

        // console.log("set svg_cont_node_banner_id xCenter = ", xCenter);

        objContSvg.setAttribute('x', xCenter);
        objContSvg.setAttribute('y', yBanner);
        objContSvg.setAttribute('width', bannerW);
        objContSvg.setAttribute('height', bannerH);
        objContSvg.appendChild(newDiv1);

        grid.appendChild(objContSvg);

        this.createNameBannerSvg(name, xCenter, bannerW)
        this.createNameBannerTitle(title, xCenter, bannerW)


        let baoDuong = document.createElement('div');
        baoDuong.innerHTML = "<div style='font-size: 30px; color: red'> Xin lỗi bạn! Hệ thống đang chỉnh sửa code Banner! </div>";
        let objContBaoDuong = document.createElementNS('http://www.w3.org/2000/svg', "foreignObject");
        objContBaoDuong.setAttribute('x', xCenter + 200);
        objContBaoDuong.setAttribute('y', yBanner - 50 );
        objContBaoDuong.setAttribute('width', 1000);
        objContBaoDuong.setAttribute('height', 200);
        objContBaoDuong.appendChild(baoDuong);
        // grid.appendChild(objContBaoDuong);

    }

    createNameBannerTitle(title, xCenter, bannerW){

        if(!this.objBannerTop.banner_title_margin_top)
            this.objBannerTop.banner_title_margin_top = 0
        if(!this.objBannerTop.banner_title_curver)
            this.objBannerTop.banner_title_curver = 0


        let startYBanner = 140
        xCenter = parseInt(xCenter);
        let grid = this.getRootSvgIfHavePanZoom();
        console.log("Create banner title...");
        let pathBannerTitle = document.createElementNS("http://www.w3.org/2000/svg","path");
        pathBannerTitle.setAttributeNS(null, "data-y", startYBanner);
        pathBannerTitle.setAttributeNS(null, "id", "svg_path_banner_title");
        pathBannerTitle.setAttributeNS(null, "d","M 10 180 Q 260 180 810 180");
        pathBannerTitle.setAttributeNS(null, "d",
            "M " + xCenter +
            " " + (startYBanner+ this.objBannerTop.banner_title_margin_top + this.objBannerTop.banner_title_curver ) +
            " Q " + (parseInt(bannerW/2) + xCenter) +
            " " + (startYBanner + this.objBannerTop.banner_title_margin_top - this.objBannerTop.banner_title_curver ) +
            " " + (parseInt(bannerW) + xCenter) +
            " " + (startYBanner + this.objBannerTop.banner_title_margin_top  + this.objBannerTop.banner_title_curver));
        pathBannerTitle.setAttributeNS(null,"fill", "none");
        // pathBannerTitle.setAttributeNS(null,"stroke","#ccc");
        pathBannerTitle.setAttributeNS(null, "data-y", startYBanner);

        grid.appendChild(pathBannerTitle);

        let textBannerTitle = document.createElementNS("http://www.w3.org/2000/svg", "text");
        textBannerTitle.setAttributeNS(null, "id", "svg_text_banner_title");
        textBannerTitle.setAttributeNS(null, "fill", this.objBannerTop.color_title);
        textBannerTitle.setAttributeNS(null,"font-size",this.objBannerTop.fontsize_title + "px");
        textBannerTitle.setAttributeNS(null,"font-family","Tahoma");
        textBannerTitle.setAttributeNS(null,"x", "0");
        textBannerTitle.setAttributeNS(null,"y", "0");

        let textPathBannerTitle = document.createElementNS("http://www.w3.org/2000/svg","textPath");
        textPathBannerTitle.setAttributeNS(null, "id", "svg_text_path_banner_title");
        textPathBannerTitle.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", "#svg_path_banner_title");
        textPathBannerTitle.setAttributeNS(null,"startOffset", "50%");
        textPathBannerTitle.setAttributeNS(null,"text-anchor", "middle");

        let textContBannerTitle = document.createTextNode(title);

        textContBannerTitle.id = "svg_text_cont_banner_title"

        textPathBannerTitle.appendChild(textContBannerTitle);
        textBannerTitle.appendChild(textPathBannerTitle);

        if(this.objBannerTop.banner_title_bold != 0 && this.objBannerTop.banner_title_bold)
            textBannerTitle.setAttribute("font-weight", 'bold');
        if(this.objBannerTop.banner_title_italic != 0 && this.objBannerTop.banner_title_italic)
            textBannerTitle.setAttribute("font-style", 'italic');
        if(this.objBannerTop.banner_text_shadow_title != 0 && this.objBannerTop.banner_text_shadow_title)
            textBannerTitle.setAttribute('filter', "url(#whiteOutlineEffect)");
        grid.appendChild(textBannerTitle);
    }

    createNameBannerSvg(name, xCenter, bannerW){

        console.log("createNameBannerSvg ... ");
        if(!this.objBannerTop.banner_name_curver)
            this.objBannerTop.banner_name_curver = 0
        if(!this.objBannerTop.banner_title_curver)
            this.objBannerTop.banner_title_curver = 0
        if(!this.objBannerTop.banner_name_margin_top)
            this.objBannerTop.banner_name_margin_top = 0;
        if(!this.objBannerTop.banner_title_margin_top)
            this.objBannerTop.banner_title_margin_top = 0;

        let startYBanner = 70;
        xCenter = parseInt(xCenter);
        let grid = this.getRootSvgIfHavePanZoom();
        let pathBannerName = document.createElementNS("http://www.w3.org/2000/svg","path");
        pathBannerName.setAttributeNS(null, "id", "svg_path_banner_name");

        pathBannerName.setAttributeNS(null, "d","M 10 80 Q 260 80 810 80");
        let path = "M " + xCenter +
            " " + (startYBanner+ this.objBannerTop.banner_name_margin_top + this.objBannerTop.banner_name_curver ) +
            " Q " + (parseInt(bannerW/2) + xCenter) +
            " " + (startYBanner + this.objBannerTop.banner_name_margin_top - this.objBannerTop.banner_name_curver ) +
            " " + (parseInt(bannerW) + xCenter) +
            " " + (startYBanner + this.objBannerTop.banner_name_margin_top  + this.objBannerTop.banner_name_curver)

        pathBannerName.setAttributeNS(null, "d", path);
        pathBannerName.setAttributeNS(null,"fill", "none");

        pathBannerName.setAttributeNS(null, "data-y", startYBanner);

        // pathBannerName.setAttributeNS(null,"stroke","#ccc");
        grid.appendChild(pathBannerName);

        let textBannerName = document.createElementNS("http://www.w3.org/2000/svg", "text");
        textBannerName.setAttributeNS(null, "id", "svg_text_banner_name");
        textBannerName.setAttributeNS(null, "fill", this.objBannerTop.color_name);
        textBannerName.setAttributeNS(null,"font-size",this.objBannerTop.fontsize_name + "px");
        textBannerName.setAttributeNS(null,"font-family","Tahoma");
        textBannerName.setAttributeNS(null,"x", "0");
        textBannerName.setAttributeNS(null,"y", "0");

        let textPathBannerName = document.createElementNS("http://www.w3.org/2000/svg","textPath");
        textPathBannerName.setAttributeNS(null, "id", "svg_text_path_banner_name");
        textPathBannerName.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", "#svg_path_banner_name");
        textPathBannerName.setAttributeNS(null,"startOffset", "50%");
        textPathBannerName.setAttributeNS(null,"text-anchor", "middle");


        let textContBannerName = document.createTextNode(name);
        textContBannerName.id = "svg_text_cont_banner_name"
        // if(this.objBannerTop.banner_name_bold)
        //     textContBannerName.style.fontWeight = this.objBannerTop.banner_name_bold
        textPathBannerName.appendChild(textContBannerName);
        textBannerName.appendChild(textPathBannerName);

        if(this.objBannerTop.banner_name_bold != 0 && this.objBannerTop.banner_name_bold)
            textBannerName.setAttribute("font-weight", 'bold');
        if(this.objBannerTop.banner_name_italic != 0 && this.objBannerTop.banner_name_italic)
            textBannerName.setAttribute("font-style", 'italic');
        if(this.objBannerTop.banner_text_shadow_name != 0 && this.objBannerTop.banner_text_shadow_name)
            textBannerName.setAttribute('filter', "url(#whiteOutlineEffect)");

        grid.appendChild(textBannerName);
    }

    getNodePositionOnViewPort(obj) {

        console.log(" move obj = ", obj);
        let startX = this.startX;
        let startY = this.startY + this.bannerHeight;
        let rectWidth = this.widthCell
        let rectHeight = this.heightCell
        if (this.optRemoveImage)
            rectHeight = this.heightCell - 30
        let horizontalPadding = this.spaceBetweenCellX;
        let verticalPadding = this.spaceBetweenCellY;

        let rateZoom = 1
        let px = startX + obj._col * (horizontalPadding + rectWidth);
        let py = startY + obj._row * (verticalPadding + rectHeight);
        if (this._panZoomTiger) {
            rateZoom = this._panZoomTiger.getSizes().realZoom
            console.log("Đã có _panZoom", rateZoom);
            // Resize the grid to fit its containing rectangles
            px *= rateZoom;
            py *= rateZoom;
        }

        let needMoveToX = window.innerWidth / 2
        let needMoveToY = window.innerHeight / 2

        //VỊ trí x,y của obj trên viewPort
        px += (this._panZoomTiger.getPan().x)
        py += (this._panZoomTiger.getPan().y)

        // let panX = needMoveToX - px - rectWidth * rateZoom/2
        // let panY = needMoveToY - py - rectHeight * rateZoom/2

        console.log("pos px py = ", px, py);
        return [px, py];

        // console.log("pos needMoveToX = ", needMoveToX, needMoveToY);
        // console.log("move panXY = ", panX, panY);
        // console.log("pos panXY = ", typeof(panX), typeof(panY));

        //this._panZoomTiger.panBy({x: 10 , y: 10})
        // this._panZoomTiger.panBy({x: panX , y: panY})
    }

    moveCenterSvgFirstLoad() {
        let px = (this._panZoomTiger.getPan().x)
        let py = (this._panZoomTiger.getPan().y)
        // console.log(" pan px, py 1= ", px, py);
        this.center()

        // console.log(" pan xxx max col = ", this.getMaxColInRow(0));
        // console.log(" pan xxx min col = ", this.getMinColInRow(0));

        // this.moveRow0ToCenterOfViewPort();

        this.moveObjToCenterOfViewPort(this.getTopNodeFirst(), -1 * (this.widthCell / 2 + this.spaceBetweenCellX / 2), 0)
        // if (this.getNodeInRow(0).length > 1)
        //     this.moveObjToCenterOfViewPort(this.getTopNodeRow0(), -1 * (this.widthCell / 2 + this.spaceBetweenCellX / 2), 0)
        // else
        //     this.moveObjToCenterOfViewPort(this.getCenterObjRow0(), 0, 0)

        px = (this._panZoomTiger.getPan().x)
        py = (this._panZoomTiger.getPan().y)
        // console.log(" pan px, py 2= ", px, py);
    }

    getXCenterOfTopRow(){

        let minX = 10000000;
        let maxX = -10000000;
        let rectWidth = this.widthCell
        let rectHeight = this.heightCell
        let minY = 10000000
        this.getAllIdRow0().forEach(function(elm){
            let id = elm.id;
            console.log("IDx = ",id);
            let node = document.getElementById("svg_cont_node_" + id);
            let x = node.getAttribute('x')
            let y = node.getAttribute('y')
            if(minY > y)
                minY = y;
            if(minX > x)
                minX = x
            if(maxX < x)
                maxX = x
        })

        console.log("Minx/maxx/minY = ", minX, maxX, minY);

        let xCenter = (maxX - minX) / 2
        return xCenter

    }

    moveRow0ToCenterOfViewPort() {
        //Tìm all elm row 0;
        //xxxxxx
        let minX = 10000000;
        let maxX = -10000000;
        let rectWidth = this.widthCell
        let rectHeight = this.heightCell
        let minY = 10000000
        this.getAllIdRow0().forEach(function(elm){
            let id = elm.id;
            console.log("IDx = ",id);
            let node = document.getElementById("svg_cont_node_" + id);
            let x = node.getAttribute('x')
            let y = node.getAttribute('y')
            if(minY > y)
                minY = y;
            if(minX > x)
                minX = x
            if(maxX < x)
                maxX = x
        })

        console.log("Minx/maxx/minY = ", minX, maxX, minY);

        let px = (maxX - minX) / 2 + this.widthCell
        let centerX = px

        console.log(" ");

        let rateZoom = 1
        if (this._panZoomTiger) {
            rateZoom = this._panZoomTiger.getSizes().realZoom
            console.log("Đã có _panZoom2", rateZoom);
            px *= rateZoom;
            minY *= rateZoom;
        }

        let needMoveToX = window.innerWidth / 2
        let needMoveToY = window.innerHeight / 2
        if(this.optFitWindowId){
            if(document.getElementById(this.optFitWindowId)){
                needMoveToX = document.getElementById(this.optFitWindowId).offsetWidth / 2;
            }
        }

        //VỊ trí x,y của obj trên viewPort
        px += (this._panZoomTiger.getPan().x)
        minY += (this._panZoomTiger.getPan().y)

        let panX = needMoveToX - px - rectWidth * rateZoom / 2
        let panY = needMoveToY - minY - rectHeight * rateZoom / 2

        console.log("panX = ", panX);

        this._panZoomTiger.panBy({x: panX, y: panY})


    }

    //Tìm vị trí của một NODE trong svg
    moveObjToCenterOfViewPort(obj, xPad = 0, yPad = 0) {

        if(!obj)
            return;

        console.log("moveObjToCenterOfViewPort  move obj1 = ", obj);
        let startX = this.startX;
        let startY = this.startY + this.bannerHeight;
        let rectWidth = this.widthCell
        let rectHeight = this.heightCell
        if (this.optRemoveImage)
            rectHeight = this.heightCell - 30
        let horizontalPadding = this.spaceBetweenCellX;
        let verticalPadding = this.spaceBetweenCellY;



        let rateZoom = 1
        let px = startX + obj._col * (horizontalPadding + rectWidth);
        let py = startY + obj._row * (verticalPadding + rectHeight);

        //26.05.24 px doi thanh vi tri x chinh xac
        px = document.getElementById('svg_cont_node_' + obj.id).getAttribute('x');

        if (this._panZoomTiger) {
            rateZoom = this._panZoomTiger.getSizes().realZoom
            console.log("Đã có _panZoom2", rateZoom);
            // Resize the grid to fit its containing rectangles
            px *= rateZoom;
            py *= rateZoom;
        }

        let needMoveToX = window.innerWidth / 2
        let needMoveToY = window.innerHeight / 2
        if(this.optFitWindowId){
            if(document.getElementById(this.optFitWindowId)){
                needMoveToX = document.getElementById(this.optFitWindowId).offsetWidth / 2;
                needMoveToY = document.getElementById(this.optFitWindowId).offsetHeight / 2;
            }
        }

        //VỊ trí x,y của obj trên viewPort
        px += (this._panZoomTiger.getPan().x)
        py += (this._panZoomTiger.getPan().y)

        let panX = needMoveToX - px - rectWidth * rateZoom / 2 + xPad
        let panY = needMoveToY - py - rectHeight * rateZoom / 2 + yPad

        // console.log("pan pos px py = ", px, this._panZoomTiger.getPan().y);
        // console.log("pos needMoveToX = ", needMoveToX, needMoveToY);
        // console.log("move panXY = ", panX, panY);
        // console.log("pos panXY = ", typeof(panX), typeof(panY));

        //this._panZoomTiger.panBy({x: 10 , y: 10})
        //Luôn cách Top 20px
        let toTop = 20
        // this._panZoomTiger.panBy({x: panX, y: toTop - this._panZoomTiger.getPan().y})
        this._panZoomTiger.panBy({x: panX, y: panY})
        console.log("this._panZoomTiger.getPan() = " , this._panZoomTiger.getPan(), needMoveToX);
        console.log("this._panZoomTiger.getZoom() = " , this._panZoomTiger.getZoom());
        var svg = document.getElementById('svg_grid');
        var offsetXY = svg.getBoundingClientRect();
        console.log("this.getBoundingClientRect() = " , offsetXY);


    }

    generateCSV(mdata, mDescField) {

        var csv = "Export by MyTree.vn \n\n"
        csv += mDescField.join(',') + "\n"
        // csv += "Mã số,Tên,Ngày sinh,Giới tính, Gốc (Cha/Mẹ), Kết hôn, (Cha/Mẹ), Email, Điện thoại, Nơi ở, NM, () \n"

        mdata.forEach(function(obj1) {
            // csv += obj1.join(",");
            let values = Object.values(obj1);
            csv += values.join(",");
            // csv += Object.values(obj).join(",");
            csv += "\n";
        });

        var hiddenElement = document.createElement('a');
        // hiddenElement.href = 'data:text/csv;' + (csv);
        hiddenElement.href = "data:text/csv;charset=utf-8,%EF%BB%BF" + encodeURI(csv);
        hiddenElement.target = '_blank';
        hiddenElement.download = "mytree.vn." + mdata[0].name + '.csv';
        hiddenElement.click();
    }

    downloadTreeAsExcel(obj, isWord = 0){

        let allChild
        if(obj.married_with)
            allChild = this.findGetAllChildsDeepOfObjAndMarried(obj.married_with);
        else
            allChild = this.findGetAllChildsDeepOfObjAndMarried(obj);

        //Chỉ lấy tu goc nay
        allChild = [obj,...allChild]

        console.log("Download allTree ", obj);

        let that = this
        let mmAll;
        mmAll = document.querySelectorAll('.svg_cont_node_cls');


        let mAll1 = [];
        mmAll.forEach(function(elm){
            elm._x = parseInt(elm.getAttribute('x'));
            elm._y = parseInt(elm.getAttribute('y'));
            let name = elm.querySelector('.node_name_one').innerHTML
            let idx = elm.id.replace("svg_cont_node_", '');
            mAll1.push({x: elm._x, y: elm._y , id: idx,name: name }, )

        })


        console.log("mmAll = ", mAll1);
        //
        mAll1.sort(function(a, b) {
            if (a.y === b.y) {
                // Nếu y giống nhau, sắp xếp theo x
                return a.x - b.x;
            } else {
                // Nếu không, sắp xếp theo y
                return a.y - b.y;
            }
        });
        //
        console.log("mAll1 = ", mAll1);
        let mmRet = [];
        let mmIdAll = [];
        mAll1.forEach(function(elm){
            allChild.forEach(function(one){
                if(one.id == elm.id){
                    mmRet.push(one);
                    mmIdAll.push(one.id);
                }
            })
        })

        let url = "/api/tree-mng/get_list_node_full_info";

        if(isWord) {
            url += '?isWord=' + obj.id;

            console.log("URL = ", url);

            //Mở cửa sổ moi với url trên
            window.open(url, '_blank');


            return;

        }

        $.ajax({
            url: url,
            type: 'POST',
            beforeSend: function (xhr) {
                xhr.setRequestHeader('Authorization', 'Bearer ' + that.apiBearToken);
            },
            data: {id_list: mmIdAll},
            success: function (data, status) {
                console.log("Data: \nStatus: ", status);
                if(data.code == -2){
                    alert("Không phải/không có dữ liệu của bạn?");
                    return;
                }else
                    if(isWord){

                    }else
                        that.generateCSV(data.payload, data.payloadEx);
            },
            error: function (ret) {
                console.log(" Eror....", ret);
            },
        });



    }

    static resizeByWindow(idSvg = 'svg_grid', elmId = null) {
        let gridRoot = document.getElementById(idSvg);
        let w1 = window.innerWidth - 2;
        let h1 = window.innerHeight - 100;
        if(elmId && document.getElementById(elmId)){
            w1 = document.getElementById(elmId).offsetWidth;
            h1 = document.getElementById(elmId).offsetHeight;
        }
        console.log("Set wh = ", w1, h1);
        gridRoot.setAttribute("width", w1);
        gridRoot.setAttribute("height", h1);
    }

    static showInformation(svgId = 'svg_grid') {
        let tree1 = clsTreeTopDownCtrl.getInstanceSvgById(svgId);

        let total = 0;



        let mmCountElm = [];

        let totalMan = 0;
        let totalFemale = 0
        for (let obj of tree1.dataPart) {
            if(tree1.checkIgnoreObj(obj))
                continue
            if(obj._row < 0)
                continue;
            total++
            if(obj.gender == 1)
                totalMan++;
            if(obj.gender == 2)
                totalFemale++;
            if (!mmCountElm[obj._row]) {
                mmCountElm[obj._row] = 1
            } else
                mmCountElm[obj._row]++
        }
        let str = "<b>Tổng số: " + total + ' thành viên </b>';

        console.log(" mmCountElm = ", mmCountElm);

        for (let r in mmCountElm) {
            if((Number.parseInt(r) + 1) > 0)
                str += '<br>- Hàng ' + (Number.parseInt(r) + 1) + " : " + mmCountElm[r] + " thành viên ";
        }

        str += '<hr><b>Số Nam + Nữ:</b> ' + totalMan +  ' + ' + totalFemale;





        $("#tree_info_1").html(str);

        $("#tree_info_").toggle();



    }

    static saveBannerInfo() {

        // alert("Đang thực hiện...");
        let svgDoing = clsTreeTopDownCtrl.allInstance[0];
        let objBanner = {}

        objBanner.tree_id = svgDoing.setPid

        objBanner.name = $('#banner_name1').val()
        objBanner.title = $('#banner_title1').val()
        objBanner.fontsize_name = $('#banner_fontsize_name').val()
        objBanner.fontsize_title = $('#banner_fontsize_title').val()
        objBanner.color_name = $('#banner_color_name').val()
        objBanner.color_title = $('#banner_color_title').val()

        objBanner.banner_name_margin_top = $('#banner_name_margin_top').val()
        objBanner.banner_name_margin_bottom = $('#banner_name_margin_bottom').val()
        objBanner.banner_title_margin_top = $('#banner_title_margin_top').val()
        objBanner.banner_title_margin_bottom = $('#banner_title_margin_bottom').val()

        objBanner.banner_name_curver = parseInt($('#banner_name_curver').val());
        objBanner.banner_title_curver = parseInt($('#banner_title_curver').val());

        objBanner.banner_width = $('#banner_width').val()
        objBanner.banner_height = $('#banner_height').val()
        objBanner.banner_margin_top = $('#banner_margin_top').val()

        if($("#banner_name_bold").is(":checked"))
            objBanner.banner_name_bold = 'bold'
        else
            objBanner.banner_name_bold = 0
        if($("#banner_title_bold").is(":checked"))
            objBanner.banner_title_bold = 'bold'
        else
            objBanner.banner_title_bold = ''

        if($("#banner_name_italic").is(":checked"))
            objBanner.banner_name_italic = 'italic'
        else
            objBanner.banner_name_italic = ''

        if($("#banner_title_italic").is(":checked"))
            objBanner.banner_title_italic = 'italic'
        else
            objBanner.banner_title_italic = ''

        if(!$("#banner_text_shadow_name").is(":checked"))
            objBanner.banner_text_shadow_name = ''
        else
            objBanner.banner_text_shadow_name = 'text_shadow1'
        if(!$("#banner_text_shadow_title").is(":checked"))
            objBanner.banner_text_shadow_title = ''
        else
            objBanner.banner_text_shadow_title = 'text_shadow1'

        if (!svgDoing.apiBearToken) {
            alert("Bạn chưa đăng nhập?")
            return;
        }

        if (!objBanner.name || objBanner.name.length < 5) {
            alert("Tên phải lớn hơn 4 ký tự");
            return
        }

        console.log(" svgDoing.objBannerTop = " , svgDoing.objBannerTop);

        let retUpload
        //Tạm thời chưa cho upload ảnh nền

        if ($('#file_id_banner')[0].files[0]) {
            retUpload = svgDoing.uploadFile('file_id_banner')
            if (!retUpload) {
                alert("Can not upload file!")
                return
            }
            objBanner.image_list = retUpload.id
            objBanner._image_list = retUpload

            console.log("Upload file: ", objBanner);

            $("#file_id_banner").val(null);

        } else {
            //image_list đã được set khi chọn xong ảnh nền
            if (svgDoing.objBannerTop.image_list) {
                objBanner.image_list = svgDoing.objBannerTop.image_list
            }
        }


        let that = this
        let urlAct = "/api/member-my-tree-info/add";
        if (svgDoing.objBannerTop && svgDoing.objBannerTop.id) {
            urlAct = "/api/member-my-tree-info/update/" + svgDoing.objBannerTop.id;
            objBanner.id = svgDoing.objBannerTop.id
            console.log("Delete objBanner._image_list ", objBanner._image_list);
            delete objBanner._image_list;
        }

        console.log("Url act = ", urlAct);

        jQuery('.loader1').show();
        $.ajax({
            url: urlAct,
            async: false,
            type: "POST",
            beforeSend: function (xhr) {
                xhr.setRequestHeader('Authorization', 'Bearer ' + svgDoing.apiBearToken);
            },
            data: objBanner,
            success: function (data, status) {
                jQuery('.loader1').hide();

                let oldImg = svgDoing.objBannerTop._image_list

                console.log("old img = " , oldImg);
                console.log("Data: ", data, " \nStatus: ", status);
                svgDoing.objBannerTop = objBanner
                if (data.payload && !svgDoing.objBannerTop.id) {
                    svgDoing.objBannerTop.id = data.payload
                }
                console.log("after update: objBanner = ", objBanner);
                //Việc đổi text sẽ bị thay đổi độ cong ko còn chính xác, nên lệnh này hạn chế đổi text
                if(objBanner.name.length != ($("#banner_name_id").text().length))
                    $("#banner_name_id").text(objBanner.name)

                $("#banner_name_id").css('fontSize', objBanner.fontsize_name + "px")
                $("#banner_name_id").css('color', objBanner.color_name)
                $("#banner_name_id").css('marginTop', objBanner.banner_name_margin_top + "px")
                $("#banner_name_id").css('marginBottom', objBanner.banner_name_margin_bottom + "px")

                //Việc đổi text sẽ bị thay đổi độ cong ko còn chính xác, nên lệnh này hạn chế đổi text
                if(objBanner.title.length != $("#banner_title_id").text().length)
                    $("#banner_title_id").text(objBanner.title)

                $("#banner_title_id").css('fontSize', objBanner.fontsize_title + "px")
                $("#banner_title_id").css('color', objBanner.color_title)
                $("#banner_title_id").css('marginTop', objBanner.banner_title_margin_top + "px")
                $("#banner_title_id").css('marginBottom', objBanner.banner_title_margin_bottom + "px")

                $("#banner_img_id").css('width', objBanner.banner_width + "px")
                $("#banner_img_id").css('height', objBanner.banner_height + "px")

                $("#banner_img_id").css('marginTop', objBanner.banner_margin_top + "px")

                //
                console.log("xxx1");

                changeValueBanner('banner_name_curver', objBanner.banner_name_curver);
                changeValueBanner('banner_title_curver', objBanner.banner_title_curver);

                if (retUpload && retUpload.thumb) {
                    console.log("change img xxx1");
                    let srcImg = retUpload.thumb
                    $("#banner_img_id").css('background-image', 'url("' + srcImg + '")')
                }
                else if (svgDoing.objBannerTop.image_list && isNaN(svgDoing.objBannerTop.image_list) &&  svgDoing.objBannerTop.image_list.indexOf("/") >= 0) {
                    console.log("change img xxx2: "  + svgDoing.objBannerTop.image_list);
                    $("#banner_img_id").css('background-image', 'url("' + svgDoing.objBannerTop.image_list + '")')
                }
                else if (oldImg && oldImg !== undefined) {
                    console.log("change img xxx3");
                    $("#banner_img_id").css('background-image', 'url("' + oldImg + '")')
                }


            },
            error: function (jqXHR, exception) {
                jQuery('.loader1').hide();
                clsTreeTopDownCtrl.showError(jqXHR)
                console.log(" Error jqXHR....", jqXHR);
                console.log(" Error exception....", exception);
            },
        });

        $("#dialog-edit-banner").dialog("close");

    }

    static viewContent() {

        window.location.href = "/member/tree-mng/edit/" + clsTreeTopDownCtrl.doingNodeObj.id
        // clsTreeTopDownCtrl.allInstance[0].doingNodeObj
    }

    static saveNewInfoNodeUI() {
        let nodeDoing = clsTreeTopDownCtrl.doingNodeObj
        let svgDoing = clsTreeTopDownCtrl.doingSvgObj
        let ret

        let objNodeSendToApi = null
        //Nếu thêm mới thì tạo node mới, nếu ko thì lấy node trong data
        if (clsTreeTopDownCtrl.doingCmd == 'add_married' ||
            clsTreeTopDownCtrl.doingCmd == 'add_child' ||
            clsTreeTopDownCtrl.doingCmd == 'add_parent'
        )
            objNodeSendToApi = {}
        else
            objNodeSendToApi = nodeDoing

        objNodeSendToApi.name = $('#new_name').val()
        objNodeSendToApi.title = $('#new_title').val()
        objNodeSendToApi.birthday = $('#new_birthday').val()
        objNodeSendToApi.orders = $('#new_orders').val()
        if(!objNodeSendToApi.orders)
            objNodeSendToApi.orders = 0;
        objNodeSendToApi.gender = $("input[name=new_gender]:checked").val()
        objNodeSendToApi.phone_number = $('#phone_number').val()
        objNodeSendToApi.email_address = $('#email_address').val()
        objNodeSendToApi.date_of_death = $('#date_of_death').val()
        objNodeSendToApi.place_heaven = $('#place_heaven').val()
        objNodeSendToApi.home_address = $('#home_address').val()
        objNodeSendToApi.link_remote = $('#link_remote').val()

        if($("#set_nu_dinh").is(":checked"))
            objNodeSendToApi.set_nu_dinh = 1
        else
            objNodeSendToApi.set_nu_dinh = 0

        if($("#child_of_second_sp").val()){
            objNodeSendToApi.child_of_second_married = $('#child_of_second_sp').val()

        }

        if ($('#stepchild_of').is(':checked')) {
            objNodeSendToApi.stepchild_of = objNodeSendToApi.child_of_second_married;
        }
        else
            objNodeSendToApi.stepchild_of = 0;

        console.log(" stepchild_of = " , objNodeSendToApi.stepchild_of);

        if (!objNodeSendToApi.name || objNodeSendToApi.name.length < 2) {
            alert("Tên phải lớn hơn 1 ký tự");
            return
        }

        if(objNodeSendToApi.orders == 'NaN')
            objNodeSendToApi.orders = null;

        if (isNaN(objNodeSendToApi.orders)) {
            alert("Thứ tự phải là số");
            return
        }

        if (svgDoing.optDisableApiForTestLocalOnly) {
            clsTreeTopDownCtrl.nodeAction(clsTreeTopDownCtrl.doingCmd,
                objNodeSendToApi,
                clsTreeTopDownCtrl.doingNodeObj
            )
            $("#dialog-node-add").dialog("close");
            return
        }

        console.log(" clsTreeTopDownCtrl.idAct = ", nodeDoing);

        if ($('#file_id')[0].files[0]) {

            let retUpload = svgDoing.uploadFile('file_id')
            if (!retUpload) {

                alert("Can not upload file!")
                return
            }
            objNodeSendToApi.image_list = retUpload.id
            objNodeSendToApi._image_list = retUpload.thumb
            console.log(" OBJ to update upload file: ", objNodeSendToApi);
        }

        if($("#remove_img_node").is(":checked")){
            objNodeSendToApi.image_list = null
            objNodeSendToApi._image_list = null
        }

        //Phai co chỗ này:
        if (clsTreeTopDownCtrl.doingCmd == 'add_married'
            || clsTreeTopDownCtrl.doingCmd == 'add_child'
            || clsTreeTopDownCtrl.doingCmd == 'add_parent'
        ) {

            if (clsTreeTopDownCtrl.doingCmd == 'add_married') {
                objNodeSendToApi.parent_id = nodeDoing.parent_id
                objNodeSendToApi.married_with = nodeDoing.id
            }

            if (clsTreeTopDownCtrl.doingCmd == 'add_child') {
                console.log(" add_child Doing node : ", nodeDoing);
                if (nodeDoing) {
                    objNodeSendToApi.parent_id = nodeDoing.id
                    //Nếu là thêm con cho vợ/chồng, thì phải gán parent về gốc
                    if (nodeDoing.married_with) {
                        let pObj = svgDoing.getObjFromId(nodeDoing.married_with)
                        objNodeSendToApi.parent_id = pObj.id
                        //Nếu như là vợ chồng 2 của bố mẹ, thì sẽ cần gán child_of_second_married
                        if (nodeDoing._col > pObj._col + 1) {
                            objNodeSendToApi.child_of_second_married = nodeDoing.id
                            console.log(" add_child Doing node1 : ", nodeDoing);
                        }
                    }
                } else {
                    objNodeSendToApi.parent_id = 0
                }
            }

            if (clsTreeTopDownCtrl.doingCmd == 'add_parent') {

                if (!nodeDoing) {
                    alert("Error: add parent, not doing node?")
                    return;
                }

                console.log(" add_parent Doing node : ", nodeDoing);
                objNodeSendToApi.parent_id = 0
                //Nếu là thêm cha, thì phải lấy id server trả về
            }

            ret = svgDoing.nodeAddApi(objNodeSendToApi, clsTreeTopDownCtrl.doingCmd)
            //không đóng dialog
            if (!ret)
                return
        }

        if (clsTreeTopDownCtrl.doingCmd == 'edit_node') {
            ret = svgDoing.nodeEditApi(objNodeSendToApi)
            //không đóng dialog
            if (!ret)
                return
        }

        $("#dialog-node-add").dialog("close");
    }

    moveObjAndChildToColOnUiAndRedraw(moveTreeTo){

        console.log(" Di chuyển trái phải cả cây");

        // let tree = clsTreeTopDownCtrl.getInstanceSvgById('svg_grid');

        if (!this.apiBearToken) {
            alert("Bạn chưa đăng nhập?")
            return;
        }

        if (this.optDisableApiTreeText && this.optDisableApiTreeText.length > 0) {
            alert("Có lỗi: " + this.optDisableApiTreeText);
            return;
        }

        let objMove = this.getObjFromId(this.tmp_mouse_enter_node_id)
        if(objMove.married_with)
            objMove = this.getObjFromId(objMove.married_with)

        if(objMove.belong_other){
            alert("Có lỗi: Thành viên thuộc nhánh liên kết, không thuộc tài khoản của bạn nên không thể chỉnh sửa" );
            return;
        }

        if(objMove.parent_id == 0){
            alert("Không di chuyển cả cây Gốc!");
            return;
        }

        let mm1 = this.findGetAllChildsDeepOfObjAndMarried(objMove);
        mm1.push(objMove);
        //Di chuyển cả cây và các con
        let maxMoveCol
        if(moveTreeTo > 0)
            maxMoveCol = this.countMaxCanMoveRightOfObjToEmptySpace(objMove, mm1, 1)
        else
            maxMoveCol = this.countMaxCanMoveLeftOfObjToEmptySpace(objMove,mm1)

        console.log(" maxMoveCol = " , maxMoveCol);

        if(!this.getNextOnRight(objMove) || (maxMoveCol > 0 )){

            let listId = ''
            let field_val = []
            let field_val2 = {} // Update kiểu này dễ hơn, chặn giữa bởi TreeMngControllerApi
            for(let any of mm1){
                listId += any.id + ',';
                field_val.push(any._col + moveTreeTo)


                //id mã hóa sẽ ko chính xác khi update nữa:
                //Đổi sang cách update chặn giữa ở controller thì có thể sẽ ok? như của giapha, change multi colfix
                field_val2[any.id] = any._col + moveTreeTo
            }


            let dataPost = {'pid_root': this.setPid, 'field_name_to_change2' : field_val2 };

            console.log(" dataPost = " , dataPost);

            let tree = this;

            let user_token = jctool.getCookie('_tglx863516839');
            let url = '/api/member-tree-mng' + "/update-multi"
            var jqXHR = $.ajax({
                url: url,
                type: 'POST',
                async: false,
                //data: {'pid_root': tree.setPid, 'id_list': listId, 'field_name_to_change': 'col_fix', 'field_val' : field_val},
                data: dataPost,
                headers: {
                    'Authorization': 'Bearer ' + user_token
                },
                success: function (result) {
                    console.log(" RET1 = ", result);
                    // let mm1 = tree.findGetAllChildsDeepOfObjAndMarried(objMove);
                    for(let any of mm1)
                        any._col = any._col + moveTreeTo;
                    clsTreeTopDownCtrl.tmpDisableCountingRowCol = 1
                    tree.reDrawTree();
                    clsTreeTopDownCtrl.tmpDisableCountingRowCol = 0;
                },
                error: function (result, status) {
                    if(result.status == 400){
                        if(result.responseJSON && result.responseJSON.message){
                            alert("Có lỗi xảy ra: " + result.responseJSON.message)
                            return;
                        }
                    }
                    alert("Có lỗi xảy ra!")
                    console.log(" RET2 = ", result);
                },
            });


        }
        else{
            alert("Không thể di chuyển vì không còn khoảng cách:\n- Có thành viên nhánh khác bên phải/trái cây\n- Hoặc đã sát mép trái");
            // showToastWarningTop("Không thể di chuyển vì không còn khoảng cách! Có thành viên bên phải/trái cây?", 5000)
        }

    }

    moveObjToColOnUiAndRedraw(dataId, deltaCol, withMarried = 0){

        let svgDoing = this;
        if (svgDoing.optDisableApiTreeText && svgDoing.optDisableApiTreeText.length > 0) {
            alert("Có lỗi: " + svgDoing.optDisableApiTreeText);
            return;
        }

        let urlAct = svgDoing.apiUpdate + "/" + dataId + "?with_pid=" + svgDoing.setPid;
        console.log(" node_move_right_btn ..." + dataId , urlAct);

        let obj = svgDoing.getObjFromId(dataId)

        //Kiểm tra xem cột gần nhất bên trái, phải, có bị đi quá ko
        if(deltaCol < 0){
            //Tìm trái
            let benTrai = this.getNextOnLeft(obj)
            console.log("xxx Left = " , benTrai);
            if(benTrai && obj._col + deltaCol <=  benTrai._col){
                console.log("xxx Khong the move vi trung ben trai...");
                // return
            }
        }
        else{
            let benPhai = this.getNextOnRight(obj)
            if(benPhai && obj._col + deltaCol >=  benPhai._col){
                console.log("xxx Khong the move vi trung ben phai ...");
                // return
            }
        }



        //Kiểm tra xem có vị trí nào trùng chưa, nếu trùng thì ko cho phép
        if(svgDoing.getObjByColRow(obj._col + deltaCol, obj._row)){
            console.log("... Không thể di chuyển, vì trùng vị trí với: " + svgDoing.getObjByColRow(obj._col + deltaCol, obj._row).name)
            // return;
        }
        if(obj._col + deltaCol < 0) {
            alert("Đã di chuyển tối đa!");
            return;
        }

        let postData = {'col_fix': obj._col + deltaCol};
        let that = this
        console.log(" OBJ - loader...", obj);

        $('.loader1').show();
        $('loader1').css('visibility','visible');

        $.ajax({
            url: urlAct,
            async: false,
            type: "POST",
            beforeSend: function (xhr) {
                xhr.setRequestHeader('Authorization', 'Bearer ' + svgDoing.apiBearToken);
            },
            data: postData,
            success: function (data, status) {
                jQuery('.loader1').hide();
                clsTreeTopDownCtrl.tmpDisableCountingRowCol = 1;

                obj._col += deltaCol
                obj.col_fix = obj._col

                //Vẽ lại với các vị trí hiện tại
                svgDoing.reDrawTree();
                clsTreeTopDownCtrl.tmpDisableCountingRowCol = 0;
                console.log("Data: ", data, " \nStatus: ", status);
            },
            error: function (jqXHR, exception) {
                jQuery('.loader1').hide();
                clsTreeTopDownCtrl.showError(jqXHR)
                console.log(" Error jqXHR....", jqXHR);
                console.log(" Error exception....", exception);
            },
        });
    }

    static setValueOneFieldTreeInfo(objInfo, callback){
        let svgDoing = clsTreeTopDownCtrl.allInstance[0];
        let treeId = svgDoing.objBannerTop.id;
        let urlAct = "/api/member-my-tree-info/update/" + treeId;
        jQuery('.loader1').show();
        $.ajax({
            url: urlAct,
            async: false,
            type: "POST",
            beforeSend: function (xhr) {
                xhr.setRequestHeader('Authorization', 'Bearer ' + svgDoing.apiBearToken);
            },
            data: objInfo,
            success: function (data, status) {
                jQuery('.loader1').hide();
                console.log("Done update...");
                // Gọi hàm callback
                if (callback) {
                    callback(data, status);
                }
            },
            error: function (jqXHR, exception) {
                jQuery('.loader1').hide();
                clsTreeTopDownCtrl.showError(jqXHR)
                console.log(" Error jqXHR....", jqXHR);
                console.log(" Error exception....", exception);
            },
        });
    }
    static show_node_image(){
        console.log("  show_node_image ");
        let objBanner = {}
        var checkedInputs = $('#show_node_image').is(':checked');
        objBanner.show_node_image = 0;
        if(checkedInputs)
            objBanner.show_node_image = 1;
        function do_show_node_image(){
            console.log(" Hide image now..", checkedInputs);
            // alert("DoNE1...")
        }
        clsTreeTopDownCtrl.setValueOneFieldTreeInfo(objBanner, do_show_node_image);
    }

    static show_node_name_one(){
        let objBanner = {}
        var checkedInputs = $('#show_node_name_one').is(':checked');
        objBanner.show_node_name_one = 0;
        if(checkedInputs)
            objBanner.show_node_name_one = 1;
        function do_show_node_name_one(){
            // alert("DoNE1...")
        }
        clsTreeTopDownCtrl.setValueOneFieldTreeInfo(objBanner, do_show_node_name_one);
    }
    static show_node_title(){

        console.log("  show_node_title ");

        let objBanner = {}
        var checkedInputs = $('#show_node_title').is(':checked');
        objBanner.show_node_title = 0;
        if(checkedInputs)
            objBanner.show_node_title = 1;
        function do_show_node_title(){
            // alert("DoNE1...")
        }
        clsTreeTopDownCtrl.setValueOneFieldTreeInfo(objBanner, do_show_node_title);
    }
    static show_node_birthday_one(){

        console.log("  show_node_birthday_one ");
        let objBanner = {}
        var checkedInputs = $('#show_node_birthday_one').is(':checked');
        objBanner.show_node_birthday_one = 0;
        if(checkedInputs)
            objBanner.show_node_birthday_one = 1;
        function do_show_node_birthday_one(){
            // alert("DoNE1...")
        }
        clsTreeTopDownCtrl.setValueOneFieldTreeInfo(objBanner, do_show_node_birthday_one);
    }
    static show_node_date_of_death(){
        console.log("  show_node_date_of_death ");
        let objBanner = {}
        var checkedInputs = $('#show_node_date_of_death').is(':checked');
        objBanner.show_node_date_of_death = 0;
        if(checkedInputs)
            objBanner.show_node_date_of_death = 1;
        function do_show_node_date_of_death(){
            // alert("DoNE1...")
        }
        clsTreeTopDownCtrl.setValueOneFieldTreeInfo(objBanner, do_show_node_date_of_death);
    }
}


$(function () {




    $("#set_limit_tree_level").on("change", function (){
        let changeTo = $(this).val() ;
        console.log(" set_limit_tree_level ", changeTo);
        // if(changeTo == 0)
        //     jctool.setCurrentUrlParamAndGo("level", null)
        // else
            jctool.setCurrentUrlParamAndGo("level", changeTo)
        location.reload();
    })

    $("#svg_cont_node_banner_id").hover(function(){
        console.log("hover...");
    });

    $("#svg_cont_node_banner_id").on('click', function(){
        // console.log("svg_cont_node_banner_id...");
    });

    $("#svg_text_banner_name").hover(function(){
        // console.log("hover...");
    });
    $("#svg_text_banner_name").on('click', function(){
        console.log("svg_text_banner_name...");
    });

    $(document).on("mouseenter", '.node_cont', function (){
        // console.log(" id mouseenter = ",$(this).attr('data-id'));

        //Nếu phím ctrl baams

        let dataId = $(this).attr('data-id');
        let tree = clsTreeTopDownCtrl.getInstanceSvgById('svg_grid');
        tree.toggleLineToChildWhenHoverParent(dataId,1);

        let objP = tree.getObjFromId(dataId)
        if(objP.link_remote)
            $(".is_node_link[data-id="+ dataId +"]").show()

        tree.tmp_mouse_enter_node_id = dataId
        if(tree.optEnableMoveBtn) {
            $(".node_move_right_btn").hide()
            $(".node_move_left_btn").hide()
            $("#id_node_move_right_" + dataId).show()
            $("#id_node_move_left_" + dataId).show()
        }

    })
    $(document).on("mouseleave", '.node_cont', function (){
        // console.log(" id mouseleave = ",$(this).attr('id'));
        let dataId = $(this).attr('data-id');
        let tree = clsTreeTopDownCtrl.getInstanceSvgById('svg_grid');
        tree.toggleLineToChildWhenHoverParent(dataId,0);
        tree.tmp_mouse_enter_node_id = 0

        let objP = tree.getObjFromId(dataId)
        if(objP.link_remote)
            $(".is_node_link[data-id="+ dataId +"]").hide()

        //if(tree.optEnableMoveBtn)
        {
            $(".node_move_right_btn").hide()
            $(".node_move_left_btn").hide()
            // $("#id_node_move_right_" + dataId).hide()
            // $("#id_node_move_left_" + dataId).hide()
        }
    })

    $(document).keydown(function(event) {

        if (event.key === "Delete" && event.shiftKey) {
            console.log("Delete...");
            let svgDoing = clsTreeTopDownCtrl.allInstance[0];
            let obj = svgDoing.getObjFromId(svgDoing.tmp_mouse_enter_node_id);

            let mm = svgDoing.findGetAllChildsDeepOfObjAndMarried(obj)
            if (!mm)
                mm = [obj]
            else
                mm.push(obj)

            //nếu dùng API thì mới cần phải hỏi...
            if (!svgDoing.optDisableApiForTestLocalOnly) {
                if (mm.length > 1) {
                    let ans = prompt('Cảnh báo: bạn đang xóa một cây nhiều hơn một phần tử\nĐể chắc chắn, hãy nhập từ: "ok" vào ô sau');

                    if (ans.toLowerCase() == 'ok' || ans == '1')
                        console.log("Đồng ý xóa");
                    else {
                        console.log("Không Đồng ý xóa");
                        return
                    }
                } else {
                    let conf = confirm("Bấm vào nút OK để tiếp tục\n(Sau khi xóa, Bạn có thể vào phần quản trị phục hồi lại mục đã xóa nếu cần)");
                    if (conf)
                        console.log("Đồng ý xóa");
                    else {
                        console.log("Không Đồng ý xóa");
                        return
                    }
                }
            }

            clsTreeTopDownCtrl.showLoader()
            if (svgDoing.nodeDeleteApi(svgDoing, obj)) {
                svgDoing.deleteObjAndAllChildAndMarried(obj)
                svgDoing.reDrawTree()
                clsTreeTopDownCtrl.hideLoader()
            }
        }
    })

    $(document).keydown(function(event) {
        let moveTreeTo = 0
        if ((event.ctrlKey || event.metaKey) && event.keyCode == 37)
            moveTreeTo = -1

        if ((event.ctrlKey || event.metaKey) && event.keyCode == 39)
            moveTreeTo = 1

        let tree = clsTreeTopDownCtrl.getInstanceSvgById('svg_grid');

        //Trường hợp di chuyển cả node và CÁC CON...
        if(tree.tmp_mouse_enter_node_id)
        if(moveTreeTo){
            tree.moveObjAndChildToColOnUiAndRedraw(moveTreeTo)
            //Return để không dính vào case chỉ phím phải, trái
            return;
        }

        if(tree.tmp_mouse_enter_node_id)
        if (event.keyCode == 37 || event.keyCode == 39) {
            if (!tree.apiBearToken) {
                alert("Bạn chưa đăng nhập?")
                return;
            }
            if(!tree.optEnableMoveBtn)
                return;
            let moveRightLeft = 1
            if (event.keyCode == 37)
                moveRightLeft = -1

            let actTime = actionTimeOut.getInstance()
            if(!actTime.lastId)
                actTime.lastId = tree.tmp_mouse_enter_node_id
            if(actTime.lastId != tree.tmp_mouse_enter_node_id)
                actTime.reset()

            let delta = 1;
            if(!actTime.lastTimeAct){
                actTime.lastTimeAct = Date.now()
                //Thực hiện ngay lần đầu
            }
            else{
                //Click gần nhau quá thì ko thực hiện gì, để lần click tiếp theo mới thực  hiện với id đó, sau đó reset về ban đầu
                //Nếu time last gần quá thì tích lũy không thực hiện gì, hoặc quá N lần mới thực hiện
                if(Date.now() - actTime.lastTimeAct < 500) {
                    console.log("... tích lũy ", actTime.countAct);
                    actTime.lastTimeAct = Date.now()
                    //tích lũy delta thêm
                    actTime.countAct++;
                    // return;

                    //Dưới 5 thì tích lũy, ko thì cho đi tiếp
                    if(actTime.countAct < 5)
                        return;
                    //Quá 5 thì thực hiện move va reset tích lũy về 0
                    delta = actTime.countAct;
                    actTime.reset()
                }
                else{
                    // console.log(" xxx4 ");
                    actTime.countAct++
                    delta = actTime.countAct;
                    actTime.reset()
                }
            }
            let objMove = tree.getObjFromId(tree.tmp_mouse_enter_node_id)
            //Tìm gần nhất bên phải để set Max có thể move
            let objNext
            if(moveRightLeft > 0)
                objNext = tree.getNextOnRight(objMove)
            else
                objNext = tree.getNextOnLeft(objMove)

            if(objNext)
                if(delta >= Math.abs(objNext._col - objMove._col))
                    delta = Math.abs(objNext._col - objMove._col) - 1

            if(delta == 0)
                return;

            tree.moveObjToColOnUiAndRedraw(tree.tmp_mouse_enter_node_id, delta * moveRightLeft)
            actTime.lastTimeAct = Date.now()
        }
    });


    $.contextMenu({
        selector: '.context-menu-one',
        trigger: 'left',
        callback: function (key, options) {
            let idItem = options.$trigger.attr("data-id");
            console.log(" options idItem = ", idItem, key, options.$trigger);

            $("#title_dialog_node").html("")

            let idSvgRoot = options.$trigger.closest('.root_svg').attr('id')
            clsTreeTopDownCtrl.doingNodeObj = clsTreeTopDownCtrl.getInstanceSvgById(idSvgRoot).getObjFromId(idItem)
            // let treeIns = new clsTreeTopDownCtrl()
            let tree1 = clsTreeTopDownCtrl.doingSvgObj = clsTreeTopDownCtrl.getInstanceSvgById(idSvgRoot)

            clsTreeTopDownCtrl.doingCmd = key

            console.log(" clsTreeTopDownCtrl.doingNodeObj = ", clsTreeTopDownCtrl.doingNodeObj);

            $('#child_of_second_sp').empty();
            $(".cls_child_of_second_sp").hide();
            //Xem có nhiều vợ chồng thì mở option vợ chồng:
            if(clsTreeTopDownCtrl.doingNodeObj.parent_id && !clsTreeTopDownCtrl.doingNodeObj.married_with){

                //Tìm xem có mấy kết hôn
                //nếu mà Edit thì mới cần, add child thì ko cần show list vợ chồng 2:
                if(key == 'edit_node'){
                    let mMarried = tree1.findGetMariedOfObj(tree1.getObjFromId(clsTreeTopDownCtrl.doingNodeObj.parent_id))
                    if(mMarried && mMarried.length){

                        // if(mMarried.length > 1)
                        $(".cls_child_of_second_sp").show();

                        let pObj = clsTreeTopDownCtrl.getInstanceSvgById().findGetParentOfObj(clsTreeTopDownCtrl.doingNodeObj)

                        $("#child_of_second_sp").append($('<option>', {
                            value: pObj.id,
                            text: pObj.name
                        }));

                        for(let any of mMarried){
                            $("#child_of_second_sp").append($('<option>', {
                                value: any.id,
                                text: any.name
                            }));
                        }
                        if(clsTreeTopDownCtrl.doingNodeObj.child_of_second_married)
                            $("#child_of_second_sp").val(clsTreeTopDownCtrl.doingNodeObj.child_of_second_married);
                    }
                }
            }
            else{

            }


            //Clear all Input before edit, add
            $("#dialog-node-add").find("input[type=text]").each(function () {
                $(this).val("")
            });
            $("#dialog-node-add").find("input[type=file]").each(function () {
                $(this).val("")
            });

            // var m = "clicked: " + key;
            //window.console && console.log(m) || alert(m);
            if (key == 'edit_node') {

                // if(clsTreeTopDownCtrl.doingNodeObj.belong_other){
                //     alert("Có lỗi: Thành viên thuộc nhánh liên kết, không thuộc tài khoản của bạn nên không thể chỉnh sửa" );
                //     return;
                // }

                $("#dialog-node-add").dialog('open')
                $("#new_name").val(clsTreeTopDownCtrl.doingNodeObj.name)
                $("#new_title").val(clsTreeTopDownCtrl.doingNodeObj.title)
                $("#new_birthday").val(clsTreeTopDownCtrl.doingNodeObj.birthday)
                $("#new_orders").val(clsTreeTopDownCtrl.doingNodeObj.orders)
                $("#phone_number").val(clsTreeTopDownCtrl.doingNodeObj.phone_number)
                $("#email_address").val(clsTreeTopDownCtrl.doingNodeObj.email_address)
                $("#date_of_death").val(clsTreeTopDownCtrl.doingNodeObj.date_of_death)
                $("#place_heaven").val(clsTreeTopDownCtrl.doingNodeObj.place_heaven)
                $("#home_address").val(clsTreeTopDownCtrl.doingNodeObj.home_address)
                $("#link_remote").val(clsTreeTopDownCtrl.doingNodeObj.link_remote)
                $("#set_nu_dinh").val(clsTreeTopDownCtrl.doingNodeObj.set_nu_dinh)

                $("input[name=new_gender][value=" + clsTreeTopDownCtrl.doingNodeObj.gender + "]").prop('checked', true);


                if(clsTreeTopDownCtrl.doingNodeObj.gender == 2)
                    $(".set_nu_dinh").show();
                else
                    $(".set_nu_dinh").hide();

                if(clsTreeTopDownCtrl.doingNodeObj.set_nu_dinh)
                    $("#set_nu_dinh").prop('checked', true);
                else
                    $("#set_nu_dinh").prop('checked', false);

                if(clsTreeTopDownCtrl.doingNodeObj.stepchild_of)
                    $("#stepchild_of").prop('checked', true);
                else
                    $("#stepchild_of").prop('checked', false);

                $("#title_dialog_node").html("<p>Thành viên: <b>" + clsTreeTopDownCtrl.doingNodeObj.name + "</b></p>");
            }

            if (key == 'add_child') {
                if(clsTreeTopDownCtrl.doingNodeObj.belong_other){
                    alert("Có lỗi: Thành viên thuộc nhánh liên kết, không thuộc tài khoản của bạn nên không thể chỉnh sửa" );
                    return;
                }
                $("#dialog-node-add").dialog('open')

                $("#title_dialog_node").html("Thêm con cho: <b> " + clsTreeTopDownCtrl.doingNodeObj.name + "</b>")
            }

            if (key == 'view_list_child') {
                if (clsTreeTopDownCtrl.doingNodeObj.married_with)
                    window.location.href = '/member/tree-mng?seby_s2=' + clsTreeTopDownCtrl.doingNodeObj.married_with;
                else
                    window.location.href = '/member/tree-mng?seby_s2=' + idItem;
            }

            if (key == 'view_content') {
                if(clsTreeTopDownCtrl.doingNodeObj)
                    window.location.href= '/my-tree-info/' + clsTreeTopDownCtrl.doingNodeObj.id;
            }

            if (key == 'download_excel_this_tree') {

                if (!tree1.apiBearToken) {
                    alert("Bạn chưa đăng nhập?")
                    return;
                }

                tree1.downloadTreeAsExcel(clsTreeTopDownCtrl.doingNodeObj)
            }


            if (key == 'test_extra_draw') {
                //Làm sao mở window tab mới?
                console.log(" clsTreeTopDownCtrl.doingNodeObj = " , clsTreeTopDownCtrl.doingNodeObj);

                window.open("/tool/site/mytree/chế-bản-in.php?idf=" + clsTreeTopDownCtrl.doingNodeObj.id, '_blank');
                return;
            }

            if (key == 'download_word_this_tree') {

                if (!tree1.apiBearToken) {
                    alert("Bạn chưa đăng nhập?")
                    return;
                }

                if(!tree1.isVip){
                    alert("Do việc tải toàn bộ dữ liệu gồm thành viên gồm Ảnh, Tiểu sử... tốn nhiều tài nguyên hệ thống, nên tài khoản chưa nạp phí chỉ có thể tải File word chứa 10 thành viên của một cây.\n\nTài khoản đã nạp phí có thể tải toàn bộ cây.");
                }

                tree1.downloadTreeAsExcel(clsTreeTopDownCtrl.doingNodeObj, 1)

            }

            if (key == 'view_list_brother') {
                if (clsTreeTopDownCtrl.doingNodeObj)
                    window.location.href = '/member/tree-mng?seby_s2=' + clsTreeTopDownCtrl.doingNodeObj.parent_id;
            }

            if (key == 'add_parent') {
                if(clsTreeTopDownCtrl.doingNodeObj.belong_other){
                    alert("Có lỗi: Thành viên thuộc nhánh liên kết, không thuộc tài khoản của bạn nên không thể chỉnh sửa" );
                    return;
                }
                if (clsTreeTopDownCtrl.doingNodeObj.married_with) {
                    alert("Không thể thêm cha/mẹ cho râu/dể!")
                    return;
                }
                if (clsTreeTopDownCtrl.doingNodeObj.parent_id > 0) {
                    alert("Không thể thêm cha, vì Thành viên đã có cha! ID Cha = " + clsTreeTopDownCtrl.doingNodeObj.parent_id)
                    return;
                }

                $("#dialog-node-add").dialog('open')
                $("#title_dialog_node").html("Thêm cha mẹ cho: <b> " + clsTreeTopDownCtrl.doingNodeObj.name + "</b>")
            }

            if (key == 'add_married') {
                if(clsTreeTopDownCtrl.doingNodeObj.belong_other){
                    alert("Có lỗi: Thành viên thuộc nhánh liên kết, không thuộc tài khoản của bạn nên không thể chỉnh sửa" );
                    return;
                }

                if (clsTreeTopDownCtrl.doingNodeObj.married_with) {
                    alert(clsTreeTopDownCtrl.doingNodeObj.name + ": là Dâu-Rể, nên không thể thêm kết hôn!")
                    return
                } else {
                    $("#dialog-node-add").dialog('open')
                    if (clsTreeTopDownCtrl.doingNodeObj.gender == 2)
                        $("#title_dialog_node").html("Thêm chồng cho: <b>" + clsTreeTopDownCtrl.doingNodeObj.name + "</b>")
                    else
                        $("#title_dialog_node").html("Thêm vợ cho: <b>" + clsTreeTopDownCtrl.doingNodeObj.name + "</b>")
                }
            }

            if (key == 'set_bg_img') {
                clsTreeTopDownCtrl.selectBackGround('svg_grid', 0)
            }

            if (key == 'edit_detail') {
                window.open('/member/tree-mng/edit/' + clsTreeTopDownCtrl.doingNodeObj.id, '_blank').focus();
                // window.location.href = "/member/tree-mng/edit/" + clsTreeTopDownCtrl.doingNodeObj.id
            }

            if (key == 'move_member') {

                if(clsTreeTopDownCtrl.doingNodeObj.belong_other){
                    alert("Có lỗi: Thành viên thuộc nhánh liên kết, không thuộc tài khoản của bạn nên không thể chỉnh sửa" );
                    return;
                }

                if (!tree1.apiBearToken) {
                    alert("Bạn chưa đăng nhập?")
                    return;
                }
                if(tree1.optDisableApiTreeText){
                    alert(tree1.optDisableApiTreeText)
                    return;
                }

                $("#div_move_item_gp_to_folder").dialog("open");
            }

            if (key == 'view_this_node') {
                let url = jctool.setCurrentUrlParamAndGo("pid", idItem, 1);
                if (clsTreeTopDownCtrl.doingNodeObj.married_with)
                    url = jctool.setCurrentUrlParamAndGo("pid", clsTreeTopDownCtrl.doingNodeObj.married_with, 1);
                // window.location.href = url
                window.open(url, '_blank').focus();
            }

            if (key == 'delete_node') {

                if (!tree1.apiBearToken) {
                    alert("Bạn chưa đăng nhập?")
                    return;
                }

                if(clsTreeTopDownCtrl.doingNodeObj.belong_other){
                    alert("Có lỗi: Thành viên thuộc nhánh liên kết, không thuộc tài khoản của bạn nên không thể chỉnh sửa" );
                    return;
                }

                let tree = clsTreeTopDownCtrl.doingSvgObj
                let obj = clsTreeTopDownCtrl.doingNodeObj

                if (tree.optDisableApiForTestLocalOnly) {
                    tree.deleteObjAndAllChildAndMarried(obj)
                    tree.reDrawTree()
                    return
                }

                let mm = tree.findGetAllChildsDeepOfObjAndMarried(obj)
                if (!mm)
                    mm = [obj]
                else
                    mm.push(obj)

                //nếu dùng API thì mới cần phải hỏi...
                if (!tree.optDisableApiForTestLocalOnly) {
                    if (mm.length > 1) {
                        let ans = prompt('Cảnh báo: bạn đang xóa một cây nhiều hơn một phần tử\nĐể chắc chắn, hãy nhập từ: "ok" vào ô sau \n(Sau khi xóa, Bạn có thể vào phần quản trị phục hồi lại mục đã xóa nếu cần)');

                        if (ans.toLowerCase() == 'ok' || ans == '1')
                            console.log("Đồng ý xóa");
                        else {
                            console.log("Không Đồng ý xóa");
                            return
                        }
                    } else {
                        let conf = confirm("Bấm vào nút OK để tiếp tục\n(Sau khi xóa, Bạn có thể vào phần quản trị phục hồi lại mục đã xóa nếu cần)");
                        if (conf)
                            console.log("Đồng ý xóa");
                        else {
                            console.log("Không Đồng ý xóa");
                            return
                        }
                    }
                }
                if (clsTreeTopDownCtrl.doingSvgObj.nodeDeleteApi(tree, obj)) {
                    tree.deleteObjAndAllChildAndMarried(obj)
                    tree.reDrawTree()
                }
            }
        },
        items: {
            "edit_node": {name: "Sửa", icon: "edit"},
            "view_content": {name: "Xem tiểu sử", icon: "edit"},
            "add_child": {name: "Thêm con", icon: "add"},
            'add_married': {name: "Thêm vợ chồng", icon: "add"},
            'view_this_node': {name: "Xem riêng nhánh này", icon: "add"},
            'move_member': {name: "Di chuyển", icon: "add"},
            "sep2": "---------",
            // 'folder_1': {
            //     name: "Mở rộng",
            //     items:
            //     {
            //
            //     },
            // },
            'add_parent': {name: "Thêm bố mẹ", icon: "add"},
            'view_list_child': {name: "Xem danh sách con", icon: "add"},
            'view_list_brother': {name: "Xem danh sách anh em, vợ chồng", icon: "add"},
            'edit_detail': {name: "Sửa chi tiết, tiểu sử", icon: "edit"},
            // 'set_bg_img': {name: "Chọn khung ảnh thành viên", icon: "add"},
            'download_excel_this_tree': {name: "Tải xuống dạng Excel nhánh này", icon: "add"},
            'download_word_this_tree': {name: "Tải xuống dạng Word nhánh này", icon: "add"},
            "sep1": "---------",
            "test_extra_draw": {name: "Chế bản In Ấn", icon: "add"},
            "sep1": "---------",
            "delete_node": {name: "Xóa", icon: "delete"},
            "sep11": "---------",
            "quit": {
                name: "Bỏ qua", icon: function () {
                    return 'context-menu-icon context-menu-icon-quit';
                }
            }
        }
    });

    $('.context-menu-one').on('click', function (e) {
        console.log('clicked', this);
    })
});

function closeAddDialog(id = null) {
    if (id)
        $("#" + id).dialog('close')
    else
        $("#dialog-node-add").dialog('close')
}

function clickEditBanner() {
    $("#dialog-edit-banner").dialog('open')
}

function changePath_Q_SvgToY(id, y1,y2,y3){

    console.log(" changePath_Q_SvgToY ... ");

    let d1 = $("#"  + id).attr('d')
    let m1 = d1.split(" ");
    m1[2] =  parseInt(y1)
    m1[5] =  parseInt(y2)
    m1[7] =  parseInt(y3)
    $("#" + id).attr('d', m1.join(" "));
}

function changeValueBanner(id, val) {

    // val = parseInt(val);

    // console.log("changeValueBanner ", id, val);

    // let tree1 = clsTreeTopDownCtrl.getInstanceSvgById('svg_grid')
    let tree1 = clsTreeTopDownCtrl.allInstance[0]

    if(id == 'banner_text_shadow_name'){
        if(!tree1.optUseBannerCicleTypeJs) {
            if($("#banner_text_shadow_name").is(":checked"))
                $("#svg_text_banner_name").attr('filter', "url(#whiteOutlineEffect)");
            else
                $("#svg_text_banner_name").attr('filter', "");
            return;
        }

        $("#banner_name_id").toggleClass('text_shadow1');
    }

    if(id == 'banner_text_shadow_title'){
        if(!tree1.optUseBannerCicleTypeJs) {
            if($("#banner_text_shadow_title").is(":checked"))
                $("#svg_text_banner_title").attr('filter', "url(#whiteOutlineEffect)");
            else
                $("#svg_text_banner_title").attr('filter', "");
            return;
        }

        $("#banner_title_id").toggleClass('text_shadow1');
    }

    // console.log(" changeValueBanner ", id, val);


    if (id == 'banner_name_bold'){
        if(!tree1.optUseBannerCicleTypeJs) {
            if($("#banner_name_bold").is(":checked"))
                $("#svg_text_banner_name").attr('font-weight', "bold");
            else
                $("#svg_text_banner_name").attr('font-weight', "");
            return;
        }

        if($("#banner_name_bold").is(":checked"))
            $("#banner_name_id").css("font-weight", "bold")
        else
            $("#banner_name_id").css("font-weight", "normal")
    }

    if (id == 'banner_title_bold'){
        if(!tree1.optUseBannerCicleTypeJs) {
            if($("#banner_title_bold").is(":checked"))
                $("#svg_text_banner_title").attr('font-weight', "bold");
            else
                $("#svg_text_banner_title").attr('font-weight', "");
            return;
        }
        if($("#banner_title_bold").is(":checked"))
            $("#banner_title_id").css("font-weight", "bold")
        else
            $("#banner_title_id").css("font-weight", "normal")
    }

    if (id == 'banner_name_italic'){
        if(!tree1.optUseBannerCicleTypeJs) {
            if($("#banner_name_italic").is(":checked"))
                $("#svg_text_banner_name").attr("font-style", 'italic');
            else
                $("#svg_text_banner_name").attr('font-style', "");
            return;
        }

        if($("#banner_name_italic").is(":checked"))
            $("#banner_name_id").css("font-style", "italic")
        else
            $("#banner_name_id").css("font-style", "normal")
    }

    if (id == 'banner_title_italic'){
        if(!tree1.optUseBannerCicleTypeJs) {
            if($("#banner_title_italic").is(":checked"))
                $("#svg_text_banner_title").attr("font-style", 'italic');
            else
                $("#svg_text_banner_title").attr('font-style', "");
            return;
        }

        if($("#banner_title_italic").is(":checked"))
            $("#banner_title_id").css("font-style", "italic")
        else
            $("#banner_title_id").css("font-style", "normal")
    }

    if (id == 'banner_name_margin_top'){
        if(!tree1.optUseBannerCicleTypeJs) {
            tree1.objBannerTop.banner_name_margin_top = parseInt(val);
            let startYBanner = parseInt($("#svg_path_banner_name").attr('data-y'))
            let y1 = startYBanner+ tree1.objBannerTop.banner_name_margin_top + tree1.objBannerTop.banner_name_curver
            let y2 = startYBanner+ tree1.objBannerTop.banner_name_margin_top - tree1.objBannerTop.banner_name_curver
            let y3 = startYBanner+ tree1.objBannerTop.banner_name_margin_top + tree1.objBannerTop.banner_name_curver
            changePath_Q_SvgToY('svg_path_banner_name', y1,y2,y3)
        }else
            $("#banner_name_id").css("margin-top", val + "px")
    }
    if (id == 'banner_color_name') {

        if(!tree1.optUseBannerCicleTypeJs) {
            $("#svg_text_banner_name").attr('fill', val);
            return;
        }

        $("#banner_name_id").css("color", val)
    }

    if (id == 'banner_fontsize_name') {

        if(!tree1.optUseBannerCicleTypeJs) {
            $("#svg_text_banner_name").attr('font-size', val + 'px');
            return;
        }

        $("#banner_name_id").css("font-size", val + "px")
    }

    if (id == 'banner_name1') {
        if(!tree1.optUseBannerCicleTypeJs) {
            $("#svg_text_path_banner_name").html(val);
            return;
        }

        $("#banner_name_id").text(val)
    }

    if (id == 'banner_title_margin_top') {
        if(!tree1.optUseBannerCicleTypeJs) {
            tree1.objBannerTop.banner_title_margin_top = parseInt(val);
            let startYBanner = parseInt($("#svg_path_banner_title").attr('data-y'))
            let y1 = startYBanner+ tree1.objBannerTop.banner_title_margin_top + tree1.objBannerTop.banner_title_curver
            let y2 = startYBanner+ tree1.objBannerTop.banner_title_margin_top - tree1.objBannerTop.banner_title_curver
            let y3 = startYBanner+ tree1.objBannerTop.banner_title_margin_top + tree1.objBannerTop.banner_title_curver
            changePath_Q_SvgToY('svg_path_banner_title', y1,y2,y3)
        }else
            $("#banner_title_id").css("margin-top", val + "px")
    }

    if (id == 'banner_title_margin_bottom')
        $("#banner_title_id").css("margin-bottom", val + "px")

    if (id == 'banner_color_title'){

        if(!tree1.optUseBannerCicleTypeJs) {
            $("#svg_text_banner_title").attr('fill', val);
            return;
        }


        $("#banner_title_id").css("color", val)
    }

    if (id == 'banner_fontsize_title'){

        if(!tree1.optUseBannerCicleTypeJs) {
            $("#svg_text_banner_title").attr('font-size', val + 'px');
            return;
        }

        $("#banner_title_id").css("font-size", val + "px")
    }
    if (id == 'banner_title1'){
        if(!tree1.optUseBannerCicleTypeJs) {
            $("#svg_text_path_banner_title").html(val);
            return;
        }
        $("#banner_title_id").text(val)
    }


    if (id == 'banner_width')
        $("#banner_img_id").css("width", val + "px")
    if (id == 'banner_height')
        $("#banner_img_id").css("height", val + "px")

    if (id == 'banner_margin_top'){
        $("#banner_img_id").css("marginTop", val + "px")
    }

    if (id == 'banner_name_curver') {
        if(!tree1.optUseBannerCicleTypeJs) {
            if(!tree1.objBannerTop.name)
                return;
            if(tree1.objBannerTop.banner_name_curver !==0 && !tree1.objBannerTop.banner_name_curver)
                return;

            tree1.objBannerTop.banner_name_curver = parseInt(val);
            // console.log(" objBannerTop1 = " , tree1.objBannerTop);
            //val;
            //svg_path_banner_title
            let d1 = $("#svg_path_banner_name").attr('d')
            let startYBanner = parseInt($("#svg_path_banner_name").attr('data-y'))
            // console.log("D1 = ", d1);
            if(!d1)
                return;
            let m1 = d1.split(" ");
            // console.log("M1 = ", m1);
            val = parseInt(val);
            // console.log(" val = " , val);
            m1[2] = startYBanner + parseInt(tree1.objBannerTop.banner_name_margin_top) + parseInt(tree1.objBannerTop.banner_name_curver)
            m1[5] = startYBanner + parseInt(tree1.objBannerTop.banner_name_margin_top) - parseInt(tree1.objBannerTop.banner_name_curver)
            m1[7] = startYBanner + parseInt(tree1.objBannerTop.banner_name_margin_top) + parseInt(tree1.objBannerTop.banner_name_curver)
            // console.log("M1+ = ", m1);
            // console.log("M12 + = ", m1);
            $("#svg_path_banner_name").attr('d', m1.join(" "));
            return;
        }

        if (!tree1.tmp_banner_name_curver) {
            // console.log(" Chưa có tree1.tmp_banner_name_curver");

                tree1.tmp_banner_name_curver = new CircleType(document.getElementById('banner_name_id'))
        } else {
            // console.log("Đã có tree1.tmp_banner_name_curver");
            // tree1.tmp_banner_name_curver.destroy()
        }
        tree1.tmp_banner_name_curver.refresh();

        if (val > 0)
            tree1.tmp_banner_name_curver.dir(1);
        else
            tree1.tmp_banner_name_curver.dir(-1);

        if(val >-100 && val < 100)
            val = 1000000
        else
            val = 1800 - Math.abs(val)
        tree1.tmp_banner_name_curver.radius(val);
        if (val == 0 || val >= 1800) {
            // tree1.tmp_banner_name_curver.destroy()
            // tree1.tmp_banner_name_curver = null
        }
    }

    if (id == 'banner_title_curver') {
        if(!tree1.optUseBannerCicleTypeJs) {
            tree1.objBannerTop.banner_title_curver = parseInt(val);
            // console.log(" objBannerTop2 = " , tree1.objBannerTop);
            // if(!tree1.objBannerTop.title)
            //     return;
            if(tree1.objBannerTop.banner_title_curver !==0 && !tree1.objBannerTop.banner_title_curver)
                return

            if(!tree1.objBannerTop.banner_title_margin_top)
                tree1.objBannerTop.banner_title_margin_top = 0;
            if(!tree1.objBannerTop.banner_title_curver)
                tree1.objBannerTop.banner_title_curver = 0;

            //val;
            //svg_path_banner_title
            let d1 = $("#svg_path_banner_title").attr('d')
            let startYBanner = parseInt($("#svg_path_banner_title").attr('data-y'))
            if(!d1)
                return;
            // console.log("D1 = ", d1);
            let m1 = d1.split(" ");
            // console.log("M1 = ", m1);
            val = parseInt(val);
            // console.log(" val = " , val);
            m1[2] = startYBanner + parseInt(tree1.objBannerTop.banner_title_margin_top) + parseInt(tree1.objBannerTop.banner_title_curver)
            m1[5] = startYBanner + parseInt(tree1.objBannerTop.banner_title_margin_top) - parseInt(tree1.objBannerTop.banner_title_curver)
            m1[7] = startYBanner + parseInt(tree1.objBannerTop.banner_title_margin_top) + parseInt(tree1.objBannerTop.banner_title_curver)

            // console.log("M11 + = ", m1);

            $("#svg_path_banner_title").attr('d', m1.join(" "));
            return;
        }



        if (!tree1.tmp_banner_title_curver) {
            // console.log(" Chưa có tree1.tmp_banner_title_curver");
            if(tree1.optUseBannerCicleTypeJs)
                tree1.tmp_banner_title_curver = new CircleType(document.getElementById('banner_title_id'))
        } else {
            // console.log("Đã có tree1.tmp_banner_title_curver");
            // tree1.tmp_banner_title_curver.destroy()
        }
        if(tree1.optUseBannerCicleTypeJs)
            tree1.tmp_banner_title_curver.refresh();
        // tree1.tmp_banner_title_curver = new CircleType(document.getElementById('banner_title_id'))
        if (val > 0)
            tree1.tmp_banner_title_curver.dir(1);
        else
            tree1.tmp_banner_title_curver.dir(-1);

        if(val >-100 && val < 100)
            val = 1000000
        else
            val = 1800 - Math.abs(val)
        tree1.tmp_banner_title_curver.radius(val);
        if (val == 0 || val >= 1800) {
            // console.log(" Destroy 2...");
            // tree1.tmp_banner_title_curver.destroy()
            // tree1.tmp_banner_title_curver = null
        }
    }
}

$(function () {

    $("#clear_col_fix_tree").on('click', function (){
        console.log(" clear_col_fix_tree ...");

        let svgDoing = clsTreeTopDownCtrl.allInstance[0];
        let urlAct = "/api/member-tree-mng/update/" + svgDoing.setPid;

        if (svgDoing.optDisableApiTreeText && svgDoing.optDisableApiTreeText.length > 0) {
            alert("Có lỗi: " + svgDoing.optDisableApiTreeText);
            return;
        }

        //Kiểm tra xem có bao nhiêu vị trí đã được di chuyển tay, và cảnh báo
        let total = 0
        let strAll = '\n- Một số vị trí đã di chuyển:\n';

        for(let any of svgDoing.dataPart){
            if(any.col_fix === 0 || any.col_fix > 0){
                total++;
                if(total < 10)
                    strAll += "" + any.name + ', ';
            }
        }
        strAll+='...';

        if(total <= 0){
            // alert("Không có vị trí nào được di chuyển bằng tay trên cây!");
            // return;
            strAll = '';
        }

        let text = "Có " + total + " vị trí đã được di chuyển tay, bạn có chắc chắn muốn đặt về vị trí mặc định?" + strAll;
        if (confirm(text) == true) {
        } else {
            return
        }

        jQuery('.loader1').show();

        $.ajax({
            url: urlAct,
            async: false,
            type: "POST",
            beforeSend: function (xhr) {
                xhr.setRequestHeader('Authorization', 'Bearer ' + svgDoing.apiBearToken);
            },
            data: {clear_col_fix_all: 1, id: svgDoing.setPid},
            success: function (data, status) {
                jQuery('.loader1').hide();
                console.log("Data: ", data, " \nStatus: ", status);
                if (data.code && data.code == 1){
                    for(let any of svgDoing.dataPart)
                        any.col_fix = null;
                    alert("Đặt mặc định thành công các vị trí!");
                }
                else{
                    alert("Có lỗi xảy ra 1?");
                }

            },
            error: function (jqXHR, exception) {
                jQuery('.loader1').hide();
                clsTreeTopDownCtrl.showError(jqXHR)
                console.log(" Error jqXHR....", jqXHR);
                console.log(" Error exception....", exception);
            },
        });
    })

    $("#clear_cache_tree").on('click', function (){
        console.log(" clear_cache_tree ...");

        let svgDoing = clsTreeTopDownCtrl.allInstance[0];
        let urlAct = "/api/member-tree-mng/update/" + svgDoing.setPid;

        if (svgDoing.optDisableApiTreeText && svgDoing.optDisableApiTreeText.length > 0) {
            alert("Có lỗi: " + svgDoing.optDisableApiTreeText);
            return;
        }

        jQuery('.loader1').show();

        $.ajax({
            url: urlAct,
            async: false,
            type: "POST",
            beforeSend: function (xhr) {
                xhr.setRequestHeader('Authorization', 'Bearer ' + svgDoing.apiBearToken);
            },
            data: {clear_cache: 1},
            success: function (data, status) {
                jQuery('.loader1').hide();
                console.log("Data: ", data, " \nStatus: ", status);
                if (data.code && data.code == 1){
                    for(let any of svgDoing.dataPart)
                        any.col_fix = null;
                    alert("Đã xóa cache thành công!");
                }
                else{
                    alert("Có lỗi xảy ra 2?");
                }

            },
            error: function (jqXHR, exception) {
                jQuery('.loader1').hide();
                clsTreeTopDownCtrl.showError(jqXHR)
                console.log(" Error jqXHR....", jqXHR);
                console.log(" Error exception....", exception);
            },
        });
    })


    $("#title_before_or_after_name").on("click", function (){

        let objBannerPost = {title_before_or_after_name: 0}
        if($(this).is(":checked"))
            objBannerPost = {title_before_or_after_name: 1}

        let svgDoing = clsTreeTopDownCtrl.allInstance[0];
        let urlAct = "/api/member-my-tree-info/update/" + svgDoing.objBannerTop.id;

        if (svgDoing.optDisableApiTreeText && svgDoing.optDisableApiTreeText.length > 0) {
            $(".node_cont").each(function (){
                console.log(" $(this).find('.node_name_one').id = " + $(this).find('.node_name_one').attr('id'));
                swapElement($(this).find('.node_name_one'), $(this).find('.node_title'));
            })
            alert("Có lỗi: " + svgDoing.optDisableApiTreeText);
            return;
        }

        jQuery('.loader1').show();

        function swapElement(a, b) {
            var aNext = $('<div>').insertAfter(a);
            a.insertAfter(b);
            b.insertBefore(aNext);
            aNext.remove();
        }

        $.ajax({
            url: urlAct,
            async: false,
            type: "POST",
            beforeSend: function (xhr) {
                xhr.setRequestHeader('Authorization', 'Bearer ' + svgDoing.apiBearToken);
            },
            data: objBannerPost,
            success: function (data, status) {
                jQuery('.loader1').hide();
                console.log("Data: ", data, " \nStatus: ", status);

                // var a = $('.node_cont .node_name_one');
                // var b = $('.node_cont .node_title');

                $(".node_cont").each(function (){
                    console.log(" $(this).find('.node_name_one').id = " + $(this).find('.node_name_one').attr('id'));
                    swapElement($(this).find('.node_name_one'), $(this).find('.node_title'));
                })
            },
            error: function (jqXHR, exception) {
                jQuery('.loader1').hide();
                clsTreeTopDownCtrl.showError(jqXHR)
                console.log(" Error jqXHR....", jqXHR);
                console.log(" Error exception....", exception);
            },
        });
    })

    $(document).on('click',".node_move_right_btn , .node_move_left_btn", function (ev){


        console.log("  node_move_left_btn node_move_right_btn...");


        let dataId = $(this).attr('data-id');
        let delta = 1
        if($(this).hasClass('node_move_left_btn'))
            delta = -1
        let svgDoing = clsTreeTopDownCtrl.allInstance[0];
        if (!svgDoing.apiBearToken) {
            alert("Bạn chưa đăng nhập?")
            return;
        }

        alert("Bạn đang dùng Phiên bản 2,  để di chuyển thành viên, có thể dùng Ctrl + Chuột click vào thành viên để kéo di chuyển, \nCó thể dùng Ctrl  + Click Chuột chọn nhiều thành viên" +
            "\nHoặc Ctrl + Chọn một Vùng nhiều thành viên để kéo di chuyển thành viên!" +
            "\nBấm Esc để Bỏ lệnh chọn " +
            "\nXem thêm Video hướng dẫn mới")
        return;

        if(svgDoing.dataPart.length <= 1)
            return
        //Nếu có ctrl:
        if(event.ctrlKey || event.metaKey){
            console.log("Ctrl key ...");
            svgDoing.moveObjAndChildToColOnUiAndRedraw(delta)
            return;
        }

        svgDoing.moveObjToColOnUiAndRedraw(dataId, delta);
    })


    $(document).on('keyup', "#dialog-edit-banner input", function () {
        // do stuff with things
        console.log(" Change input ...", $(this).attr('id'), $(this).val());
        changeValueBanner($(this).attr('id'), $(this).val())
    });

    $(document).on('change', "#dialog-edit-banner input,#dialog-edit-banner select", function () {
        // do stuff with things
        console.log(" Change input ...", $(this).attr('id'), $(this).val());
        changeValueBanner($(this).attr('id'), $(this).val())
    });


    $("#dialog-edit-banner").dialog({
        autoOpen: false,
        resizable: true,
        // height: 400,
        width: 350,
        modal: true,
        create: function (event, ui) {
            // Set maxWidth

        },
        open: function (event, ui) {
            // Height setter has no effect after init either
            // $(this).dialog("option", "height", auto );

            // Width setter works after initialization too
            // $(this).dialog("option", "width", 300 );
            let treeDoing = clsTreeTopDownCtrl.allInstance[0]
            console.log("Open..." , treeDoing.objBannerTop);
            if (treeDoing.objBannerTop && treeDoing.objBannerTop.name) {
                $('#banner_name1').val(treeDoing.objBannerTop.name)
                $('#banner_title1').val(treeDoing.objBannerTop.title)
            }

        },
    });

    $("#dialog-node-add").dialog({
        autoOpen: false,
        resizable: true,
        // height: 400,
        width: 300,
        modal: true,
        create: function (event, ui) {
            // Set maxWidth

        },
        open: function (event, ui) {
            // Height setter has no effect after init either
            // $(this).dialog("option", "height", auto );
            console.log("Open... dialog-node-add");

            // Width setter works after initialization too
            // $(this).dialog("option", "width", 300 );
        },
        // buttons: {
        //     "Ghi lại": function () {
        //

        //
        //     },
        //     "Bỏ qua": function () {
        //         $(this).dialog("close");
        //     }
        // }
    });

    $("#open_move_dialog").on("click", function (){
        $("#div_move_item_gp_to_folder").dialog("open");
    })

    $("#dialog-show-config").dialog({
        autoOpen: false,
        resizable: false,
        height: 600,
        width: 300,
        modal: true,
        open: function (event, ui) {

            let svgDoing = clsTreeTopDownCtrl.allInstance[0];
            let total = 0
            for(let any of svgDoing.dataPart) {
                if (any.col_fix === 0 || any.col_fix > 0) {
                    total++;
                }
            }
            if(total)
                $("#title_change_col_fix").text("Có " + total + " vị trí thay đổi so với mặc định");
            else
                $("#title_change_col_fix").text("Không có vị trí thay đổi so với mặc định");

        },
        buttons: [
            {
                text: "Đóng lại",
                class: 'btn btn-default pull-left btn_x2',
                click: function () {
                    $(this).dialog("close");

                    if (confirm("Trang sẽ được tải lại để cập nhật Thay đổi nếu có?")) {
                        location.reload();
                    }
                }
            },
        ]
    })

    $("#dialog-select-background").dialog({
        autoOpen: false,
        resizable: false,
        height: 600,
        width: 300,
        modal: true,
        buttons: [
            {
                text: "Đóng lại",
                class: 'btn btn-default pull-left btn_x1' ,
                click: function (){
                    $(this).dialog("close");
                }
            },
            {
                text: "Ghi lại",
                class: 'btn btn-info',
            // "Ghi lại": function () {
            //     console.log(" Chọn ");
            //     $(this).dialog("close");
            // },
            click: function () {
                console.log(" Ghi lai1...");

                $(this).dialog("close");
                let svgDoing = clsTreeTopDownCtrl.allInstance[0];
                //treeDoing.objBannerTop.member_background_img
                if (1) {

                    if (!svgDoing.apiBearToken) {
                        alert("Bạn chưa đăng nhập?")
                        return;
                    }
                    if (svgDoing.optDisableApiTreeText && svgDoing.optDisableApiTreeText.length > 0) {
                        alert("Có lỗi: " + svgDoing.optDisableApiTreeText);
                        return;
                    }

                    let objBannerPost = {...svgDoing.objBannerTop};
                    console.log(" objBannerPost = " , objBannerPost);
                    let urlAct = "/api/member-my-tree-info/add";
                    if (svgDoing.objBannerTop && svgDoing.objBannerTop.id) {
                        urlAct = "/api/member-my-tree-info/update/" + svgDoing.objBannerTop.id;
                        objBannerPost.id = svgDoing.objBannerTop.id
                    }
                    if (!objBannerPost.name)
                        objBannerPost.name = svgDoing.getTopNodeFirst().name
                    if (!objBannerPost.tree_id)
                        objBannerPost.tree_id = svgDoing.setPid;

                    delete objBannerPost._image_list;
                    delete objBannerPost.created_at;
                    delete objBannerPost.updated_at;
                    delete objBannerPost.deleted_at;
                    delete objBannerPost.user_id;
                    delete objBannerPost.status;



                    jQuery('.loader1').show();
                    $.ajax({
                        url: urlAct,
                        async: false,
                        type: "POST",
                        beforeSend: function (xhr) {
                            xhr.setRequestHeader('Authorization', 'Bearer ' + svgDoing.apiBearToken);
                        },
                        data: objBannerPost,
                        success: function (data, status) {
                            jQuery('.loader1').hide();
                            console.log("Data: ", data, " \nStatus: ", status);
                        },
                        error: function (jqXHR, exception) {
                            jQuery('.loader1').hide();
                            clsTreeTopDownCtrl.showError(jqXHR)
                            console.log(" Error jqXHR....", jqXHR);
                            console.log(" Error exception....", exception);
                        },
                    });
                }

            }
        }]
    });


    $("#dialog-select-banner-background").dialog({
        autoOpen: false,
        resizable: false,
        height: "500",
        width: 330,
        modal: true,
        buttons: {
            // "Ghi lại": function () {
            //     console.log(" Chọn ");
            //     $(this).dialog("close");
            // },
            "Đóng lại..": function () {
                console.log(" Ghi lai2...");
                $(this).dialog("close");
            }
        }
    });

    $("div.dialogButtons div").addClass("btn btn info");

    $(".img_bg_banner img").on('click', function () {
        let srcImg = $(this).attr('data-src')
        console.log("Datasrc img banner = ", srcImg);
        let tree = clsTreeTopDownCtrl.allInstance[0]
        tree.objBannerTop.image_list = srcImg;
        $("#banner_img_id").css("background-image", 'url("' + srcImg + '")')
        // $("#banner_img_id").css("background-image", srcImg)
    });

    $(".img_bg_node_svg img").on('click', function () {

        let svg = clsTreeTopDownCtrl.allInstance[0]
        //alert("click to: " + $(this).attr('src'))
        let srcImg = $(this).attr('data-src')
        console.log("Datasrc img = ", srcImg);
        console.log(" svg.selectingManWomanBackGround =... ", svg.selectingManWomanBackGround);

        if(!svg.selectingManWomanBackGround){
            clsTreeTopDownCtrl.allInstance[0].objBannerTop.member_background_img = srcImg
            clsTreeTopDownCtrl.allInstance[0].objBannerTop.member_background_img2 = srcImg
        }
        if(svg.selectingManWomanBackGround == 1)
            clsTreeTopDownCtrl.allInstance[0].objBannerTop.member_background_img = srcImg
        if(svg.selectingManWomanBackGround == 2)
            clsTreeTopDownCtrl.allInstance[0].objBannerTop.member_background_img2 = srcImg

        $('.node_cont').each(function () {
            console.log(" Node ... ", $(this).prop('id'), $(this).attr('id'), $(this).attr('data-gender'));
            if (!$(this).attr('data-gender')
                || $(this).attr('data-gender') == 'undefined'
                || $(this).attr('data-gender') == 'null'
                || $(this).attr('data-gender') == svg.selectingManWomanBackGround) {
                // console.log("xxx");
                $(this).css('background-image', 'url("' + srcImg + '")')
            }
            //Nếu ko có gì thì chọn cho all thành viên
            if (!svg.selectingManWomanBackGround)
                $(this).css('background-image', 'url("' + srcImg + '")')
        })




    })

    // dlg.dialog( "open" );


    $('#file_id').imageUploadResizer({
        max_width: 800, // Defaults 1000
        max_height: 800, // Defaults 1000
        quality: 0.9, // Defaults 1
        do_not_resize: ['gif', 'svg'], // Defaults []
    });

    $('#file_id_banner').imageUploadResizer({
        max_width: 800, // Defaults 1000
        max_height: 800, // Defaults 1000
        quality: 0.9, // Defaults 1
        do_not_resize: ['gif', 'svg'], // Defaults []
    });


    window.onresize = function () {
        console.log("window.onresize... ");
        clsTreeTopDownCtrl.resizeByWindow()
    };

    $("head").append($("<script></script>").attr("src", "/tool1/lad_tree_vn/tester.js?v=1"));

    $("#showInformation_close").on("click", function () {
        $("#tree_info_").hide();
    })

    $("#select_banner_img").on('click', function () {

    })

    $(".change_number_btn").on("click", function () {
        let idChange = $(this).attr('data-id');
        console.log(".. change_number_btn; ", idChange, $(this).attr('data-cmd'));

        let dataStep = parseInt($(this).attr('data-step'));
        if (!dataStep)
            dataStep = 1

        if (!$("#" + idChange).val())
            $("#" + idChange).val(0);

        let newVal
        if ($(this).attr('data-cmd') == '+') {

            newVal = parseInt($("#" + idChange).val()) + dataStep;
            if ($(this).attr('data-max') !== undefined)
                if (newVal <= parseInt($(this).attr('data-max')))
                    $("#" + idChange).val(newVal);
                else
                    newVal -= dataStep
        }
        if ($(this).attr('data-cmd') == '-') {
            newVal = parseInt($("#" + idChange).val()) - dataStep;
            if ($(this).attr('data-min') !== undefined)
                if (newVal >= parseInt($(this).attr('data-min')))
                    $("#" + idChange).val(newVal);
                else
                    newVal += dataStep
            else
                $("#" + idChange).val(newVal);
        }
        changeValueBanner(idChange, newVal)
    })


});

function setDefaultBannerInfo(){
    $('#banner_fontsize_name').val(30);
    $('#banner_fontsize_title').val(20);
    $('#banner_name_margin_top').val(20);
    $('#banner_title_margin_top').val(10);
    $('#banner_name_curver').val(0);
    $('#banner_title_curver').val(0);
    $('#banner_margin_top').val(0);
    // banner_width
    // banner_height
    $('#banner_width').val(800);
    $('#banner_height').val(150);
    $('#banner_color_name').val('#ff0000');
    $('#banner_color_title').val('#ff0000');

    $('#banner_text_shadow_name').prop('checked', true);
    $('#banner_text_shadow_title').prop('checked', true);

    $("input[id^=banner_]").each(function (){
        changeValueBanner(this.id, this.value)
    })
    $("select[id^=banner_]").each(function (){
        changeValueBanner(this.id, this.value)
    })

}

var resizeImage = function (settings) {
    var file = settings.file;
    var maxSize = settings.maxSize;
    var reader = new FileReader();
    var image = new Image();
    var canvas = document.createElement('canvas');
    var dataURItoBlob = function (dataURI) {
        var bytes = dataURI.split(',')[0].indexOf('base64') >= 0 ?
            atob(dataURI.split(',')[1]) :
            unescape(dataURI.split(',')[1]);
        var mime = dataURI.split(',')[0].split(':')[1].split(';')[0];
        var max = bytes.length;
        var ia = new Uint8Array(max);
        for (var i = 0; i < max; i++)
            ia[i] = bytes.charCodeAt(i);
        return new Blob([ia], {type: mime});
    };
    var resize = function () {
        var width = image.width;
        var height = image.height;
        if (width > height) {
            if (width > maxSize) {
                height *= maxSize / width;
                width = maxSize;
            }
        } else {
            if (height > maxSize) {
                width *= maxSize / height;
                height = maxSize;
            }
        }
        canvas.width = width;
        canvas.height = height;
        canvas.getContext('2d').drawImage(image, 0, 0, width, height);
        var dataUrl = canvas.toDataURL('image/jpeg');
        return dataURItoBlob(dataUrl);
    };
    return new Promise(function (ok, no) {
        if (!file.type.match(/image.*/)) {
            no(new Error("Not an image"));
            return;
        }
        reader.onload = function (readerEvent) {
            image.onload = function () {
                return ok(resize());
            };
            image.src = readerEvent.target.result;
        };
        reader.readAsDataURL(file);
    });


};


$(function () {
    let user_token = jctool.getCookie('_tglx863516839');

    $("input[name=new_gender]").on("change", function (){
        console.log(" Change new_gender ", $(this).val());
        if($(this).val() == 2)
            $(".set_nu_dinh").show();
        else{
            $(".set_nu_dinh").hide();
            $("#set_nu_dinh").prop('checked', false);
        }
    })

    $("#div_dialog_support").dialog({
        width: 320,
        height: 300,
        position: {my: "center top+50", at: "center top+50", of: window},
        autoOpen: false,
        modal: true,
        open: function (event, ui) {
            $('.ui-widget-overlay').bind('click', function () {
                $("#div_dialog_support").dialog('close');
            });
        }
    });

    $("#div_move_item_gp_to_folder").dialog({
        width: 320,
        height: 600,
        position: {my: "center top+50", at: "center top+50", of: window},
        autoOpen: false,
        modal: true,
        open: function (event, ui) {
            $('.ui-widget-overlay').bind('click', function () {
                $("#div_move_item_gp_to_folder").dialog('close');
            });
            let svgDoing = clsTreeTopDownCtrl.allInstance[0];
            $(".root_tree_cls_span").text(svgDoing.getTopNodeRow0().name);
        }
    });
    $("#btn_close_move_tree").click(function () {
        $("#div_move_item_gp_to_folder").dialog("close");
    })

    $("#btn_move_file").click(function () {
        console.log(" Move file ...");

        let nodeId = '';
        let elm = $("#tree_root_move_item input.radio_box_node1:checked")[0]
        if (elm) {
            console.log(" Found elm ... parent: ", elm);
            nodeId = $(elm).parent(".real_node_item").attr('data-tree-node-id');
        }

        console.log("Move to Node ID = ", nodeId);

        if(!nodeId && nodeId !== 0){
            alert("Bạn cần chọn một nhánh để chuyển đến!")
            return;
        }
        let svgDoing = clsTreeTopDownCtrl.allInstance[0];

        let objNodeMoveTo = svgDoing.getObjFromId(nodeId);
        if(objNodeMoveTo.married_with){
            objNodeMoveTo = svgDoing.getObjFromId(objNodeMoveTo.married_with);
            if(!objNodeMoveTo){
                alert("Error not found married!")
                return;
            }
            nodeId = objNodeMoveTo.id;
        }

        console.log("Move to Node ID1 = ", nodeId);
        console.log(" clsTreeTopDownCtrl.doingNodeObj.id = " , clsTreeTopDownCtrl.doingNodeObj.id);
        if(clsTreeTopDownCtrl.doingNodeObj.married_with)
            clsTreeTopDownCtrl.doingNodeObj = svgDoing.getObjFromId(clsTreeTopDownCtrl.doingNodeObj.married_with)

        if(clsTreeTopDownCtrl.doingNodeObj.belong_other){
            alert("Có lỗi: Thành viên thuộc nhánh liên kết, không thuộc tài khoản của bạn nên không thể chỉnh sửa" );
            return;
        }

        if(svgDoing.checkObjIsChildOfOther(objNodeMoveTo, clsTreeTopDownCtrl.doingNodeObj)){
            alert("Không thể di chuyển đến con!")
            return;
        }

        // id_list
        // move_to_parent_id
        let listId = clsTreeTopDownCtrl.doingNodeObj.id

        let mMaried = tree1.findGetMariedOfObj(listId);
        if(mMaried){
            for(let obj1 of mMaried){
                listId += ',' + obj1.id;
            }
        }

        console.log(" ListID = " , listId);
        // return

        let url = '/api/member-tree-mng' + "/update-multi"
        var jqXHR = $.ajax({
            url: url,
            type: 'POST',
            async: false,
            data: {'id_list': listId, 'move_to_parent_id': nodeId},
            headers: {
                'Authorization': 'Bearer ' + user_token
            },
            success: function (result) {
                console.log(" RET1 = ", result);
                // return mRet  = result
                $("#div_move_item_gp_to_folder").dialog("close");

                clsTreeTopDownCtrl.doingNodeObj.parent_id = nodeId;
                if(mMaried)
                    for(let obj1 of mMaried)
                        obj1.parent_id = nodeId;

                svgDoing.reDrawTree();
                svgDoing.moveObjToCenterOfViewPort(clsTreeTopDownCtrl.doingNodeObj)
                console.log("Blink me...2");
                $(".node_cont").find(".img_new_node_blink").css("display", 'none')
                $(".node_cont[data-id='" + clsTreeTopDownCtrl.doingNodeObj.id + "']").find(".img_new_node_blink").css("display", 'block')
                // showToastInfoTop("DONE move file!")
            },
            error: function (result, status) {
                if(result.status == 400){
                    if(result.responseJSON && result.responseJSON.message){
                        alert("Có lỗi xảy ra: " + result.responseJSON.message)
                        return;
                    }
                }
                alert("Có lỗi xảy ra!")
                console.log(" RET2 = ", result);
            },
        });

    })

    $("#move_item_multi").click(function () {
        console.log("MOVE...");
        $("#div_move_item_gp_to_folder").dialog("open");
        $("#show_action_multi_item").hide();
    });
})

function openMoreAttr() {
    $("#open_more").toggle()
}

function setManOnly(){
    if($("#showonlyman").is(":checked"))
        clsTreeTopDownCtrl.setOnlyMan('svg_grid')
    else
        clsTreeTopDownCtrl.resetDefault('svg_grid')
}

function setHuyetThongOnly(){
    if($("#huyethongonly").is(":checked"))
        clsTreeTopDownCtrl.setDisableMarried('svg_grid')
    else
        clsTreeTopDownCtrl.resetDefault('svg_grid')
}

function showHelpDgl(){
    $("#div_dialog_support").dialog('open');
}


$(function () {
    // if(0)
})

$(function(){

})

class clsTreeNode {
    id
    name
    parent_id
    married_with
    married_with2
    birthday
    child_of_second_married
    child_type
    gender
    has_child
    last_name
    orders
    set_nu_dinh
    link_remote

    status
    sur_name
    image_list
    _image_list
    _mark_add_new
    _row = -1
    _col = -1
    _divCont
}


